//
//  TxtView+Extension.swift


import Foundation
import UIKit

extension UITextView {
    
    func displayFromStarting() {
        self.scrollRangeToVisible(NSMakeRange(0, 0))
    }
}
