//
//  DatePicker+Extension.swift


import Foundation
import UIKit

extension UIDatePicker {
    
    func setMinDateMaxDate(minYear: Int, maxYear: Int) {
        
        let calendar = Calendar(identifier: .gregorian)
        var comps = DateComponents()
        comps.year = maxYear
        let maxDate = calendar.date(byAdding: comps, to: Date())
        comps.year = minYear
        let minDate = calendar.date(byAdding: comps, to: Date())
        self.maximumDate = maxDate
        self.minimumDate = minDate
    }
}
