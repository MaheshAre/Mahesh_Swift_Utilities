//
//  WebView+Extension.swift


import Foundation
import UIKit

extension UIWebView {
    
    func marqueeLabel(string: String, direction: Enum_Direction) {
        
        self.backgroundColor = .lightGray
        self.isOpaque = false
        self.loadHTMLString("<html><body><marquee style = 'color: white' direction='\(direction.rawValue)' SCROLLDELAY=300>\(string)</marquee></body></html>", baseURL: nil)
    }
}

enum Enum_Direction: String {
    case left = "LEFT"
    case right = "RIGHT"
}
