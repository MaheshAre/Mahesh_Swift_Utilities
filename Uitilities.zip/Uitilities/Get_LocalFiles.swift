//
//  Get_LocalFiles.swift


import Foundation
import UIKit

struct Get_LocalFiles {
    
    static let shared = Get_LocalFiles()
    private init() { }
    
    func get_localFile_URLStr(name: String, withExtension: String) -> URLRequest? {
        
        if let pdf = Bundle.main.url(forResource: name, withExtension: withExtension, subdirectory: nil, localization: nil)  {
            let req = URLRequest(url: pdf)
            
            return req
        }else {
            return nil
        }
    }
}
