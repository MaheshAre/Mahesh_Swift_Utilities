//
//  Constants.swift

import Foundation
import UIKit

let appTitle = "Moukai"
let user_Defaults = UserDefaults.standard

let rupeeSymbol = "₹"

//MARK:- APIs

let BaseURL = "http://appilabz.com/moukai/api/" //"http://moukai.in/moukai/api/"
let BaseURL_Image = "http://appilabz.com/moukai/"//"http://moukai.in/moukai/"


let api_login = "user_login"
let api_resendOTP = "resend_otp"
let api_userUpdate = "user_update"
let api_mainPage = "main_page"
let api_getProducts = "get_products"
let api_addCart = "add_cart"
let api_getCart = "get_cart"
let api_deleteCart = "delete_cart"
let api_deleteCompleteCart = "complete_delete_cart"
let api_getPickupAddress = "get_pickup_address"
let api_addPickupAddress = "add_pickup_address"
let api_placeOrder = "place_order"
let api_getProfile = "get_profile"
let api_updateProfile = "user_update"
let api_myOrders = "my_orders"
let api_myOrderDetails = "my_orders_details"
let api_repeatOrder = "repeat_order"
let api_cancelOrderList = "cancel_order_list"
let api_cancelOrder = "cancel_order"
let api_customerSupport = "customer_support"
/**
 For Promo Apply
 */
let api_getPromoCode = "get_promocode"
let api_promoApply = "promo_apply"
let api_giveRating = "give_ratings"
let api_notofications = "user_push_notifications"
let api_searchProducts = "search_products"
let api_deletePickUpAddress = "delete_pickup_address"
let api_returnOrderList = "return_order_list"
let api_returnOrder = "return_order"

let api_cart_increament = "cart_increment"
let api_updateDeviceToken = "update_device_token"
