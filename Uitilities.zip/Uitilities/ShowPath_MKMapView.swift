
//
//  ShowPath_MKMapView.swift

import Foundation

/*
// Declarations
 @IBOutlet weak var mapkitView: MKMapView!

 // ViewDidLoad
 
 self.mapkitView.delegate = self
 
 */


/*

extension OfferTripViewController: MKMapViewDelegate {
    
    func showRouteOnMap(pickupCoordinate: CLLocationCoordinate2D, destinationCoordinate: CLLocationCoordinate2D) {
        
        let sourcePlacemark = MKPlacemark(coordinate: pickupCoordinate, addressDictionary: nil)
        let destinationPlacemark = MKPlacemark(coordinate: destinationCoordinate, addressDictionary: nil)
        
        let sourceMapItem = MKMapItem(placemark: sourcePlacemark)
        let destinationMapItem = MKMapItem(placemark: destinationPlacemark)
        
        //        let sourceAnnotation = MKPointAnnotation()
        //
        //        if let location = sourcePlacemark.location {
        //            sourceAnnotation.coordinate = location.coordinate
        //        }
        //
        //        let destinationAnnotation = MKPointAnnotation()
        //
        //        if let location = destinationPlacemark.location {
        //            destinationAnnotation.coordinate = location.coordinate
        //        }
        //
        //        self.mapkitView.showAnnotations([sourceAnnotation,destinationAnnotation], animated: true )
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = sourceMapItem
        directionRequest.destination = destinationMapItem
        directionRequest.transportType = .automobile
        
        // Calculate the direction
        let directions = MKDirections(request: directionRequest)
        
        directions.calculate {
            (response, error) -> Void in
            
            guard let response = response else {
                if let error = error {
                    print("Error: \(error)")
                }
                
                return
            }
            
            let route = response.routes[0]
            
            self.mapkitView.addOverlay((route.polyline), level: MKOverlayLevel.aboveRoads)
            
            let span = MKCoordinateSpan(latitudeDelta: 0.07, longitudeDelta: 0.07)
            let region = MKCoordinateRegion(center: pickupCoordinate, span: span)
            self.mapkitView.setRegion(region, animated: true)
            self.mapkitView.showsUserLocation = true
            
            // For Images
            let info1 = CustomPointAnnotation()
            info1.coordinate = CLLocationCoordinate2DMake(self.from_lat, self.from_long)
            //            info1.title = "Info1"
            //            info1.subtitle = "Subtitle"
            info1.image = #imageLiteral(resourceName: "icon_location_pin_black")
            
            let info2 = CustomPointAnnotation()
            info2.coordinate = CLLocationCoordinate2DMake(self.to_lat, self.to_long)
            //            info2.title = "Info2"
            //            info2.subtitle = "Subtitle"
            info2.image = #imageLiteral(resourceName: "icon_location")
            
            self.mapkitView.addAnnotation(info1)
            self.mapkitView.addAnnotation(info2)
            
            //            let rect = route.polyline.boundingMapRect
            //            self.mapkitView.setRegion(MKCoordinateRegion(rect), animated: true)
            
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        
        if !(annotation is CustomPointAnnotation) {
            return nil
        }
        
        let reuseId = "test"
        
        var anView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId)
        if anView == nil {
            anView = MKAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            anView!.canShowCallout = true
        }
        else {
            anView!.annotation = annotation
        }
        
        //Set annotation-specific properties **AFTER**
        //the view is dequeued or created...
        
        let cpa = annotation as! CustomPointAnnotation
        anView!.image = cpa.image //UIImage(named:cpa.imageName)
        
        return anView!
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        
        let renderer = MKPolylineRenderer(overlay: overlay)
        
        renderer.strokeColor = UIColor(red: 17.0/255.0, green: 147.0/255.0, blue: 255.0/255.0, alpha: 1)
        
        renderer.lineWidth = 3.0
        
        return renderer
    }
    
}


*/
//MARK:- Live Tracking

// Calling

/*
self.mapKitView.delegate = self
 
self.mapKitView.setVisibleMapRect(MKMapRect(x: 0, y: 0, width: 0, height: 0), animated: true)
self.showRouteOnMap(pickupCoordinate: CLLocationCoordinate2D(latitude: self.from_lat, longitude: self.from_long), destinationCoordinate: CLLocationCoordinate2D(latitude: self.to_lat, longitude: self.to_long))

self.show_DriverLocations(coordinates: [CLLocationCoordinate2D(latitude: self.driver_lat, longitude: self.driver_long)])

*/

/*

extension DestinationViewController: MKMapViewDelegate {
    
    func showLoaction(coordintes: CLLocationCoordinate2D) {
        
//        self.zoomFormap(coordinates: CLLocationCoordinate2D(latitude: self.from_lat, longitude: self.from_long), latDelta: 10, longDelta: 10)
        
        
        let sourcePlacemark = MKPlacemark(coordinate: coordintes, addressDictionary: nil)
        
        let sourceMapItem = MKMapItem(placemark: sourcePlacemark)
        
                let sourceAnnotation = MKPointAnnotation()
        
                if let location = sourcePlacemark.location {
                    sourceAnnotation.coordinate = location.coordinate
                }
        //
        //        let destinationAnnotation = MKPointAnnotation()
        //
        //        if let location = destinationPlacemark.location {
        //            destinationAnnotation.coordinate = location.coordinate
        //        }
        //
                self.mapKitView.showAnnotations([sourceAnnotation], animated: true )
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = sourceMapItem
        
        // Calculate the direction
        let directions = MKDirections(request: directionRequest)
        
        directions.calculate {
            (response, error) -> Void in
            
            guard let response = response else {
                if let error = error {
                    print("Error: \(error)")
                }
                
                return
            }
            
            let route = response.routes[0]
            
            self.mapKitView.addOverlay((route.polyline), level: MKOverlayLevel.aboveRoads)
            
            let span = MKCoordinateSpan(latitudeDelta: 0.07, longitudeDelta: 0.07)
            let region = MKCoordinateRegion(center: coordintes, span: span)
            self.mapKitView.setRegion(region, animated: true)
            self.mapKitView.showsUserLocation = true
            
            // For Images
            let info1 = CustomPointAnnotation()
            info1.coordinate = CLLocationCoordinate2DMake(coordintes.latitude, coordintes.longitude)
            //            info1.title = "Info1"
            //            info1.subtitle = "Subtitle"
            info1.image = #imageLiteral(resourceName: "icon_location_pin_black")
            
            self.mapKitView.addAnnotation(info1)
            
            
            //            let rect = route.polyline.boundingMapRect
            //            self.mapkitView.setRegion(MKCoordinateRegion(rect), animated: true)
            
        }
    }
    
    func showRouteOnMap(pickupCoordinate: CLLocationCoordinate2D, destinationCoordinate: CLLocationCoordinate2D) {
        
        let sourcePlacemark = MKPlacemark(coordinate: pickupCoordinate, addressDictionary: nil)
        let destinationPlacemark = MKPlacemark(coordinate: destinationCoordinate, addressDictionary: nil)
        
        let sourceMapItem = MKMapItem(placemark: sourcePlacemark)
        let destinationMapItem = MKMapItem(placemark: destinationPlacemark)
        
        //        let sourceAnnotation = MKPointAnnotation()
        //
        //        if let location = sourcePlacemark.location {
        //            sourceAnnotation.coordinate = location.coordinate
        //        }
        //
        //        let destinationAnnotation = MKPointAnnotation()
        //
        //        if let location = destinationPlacemark.location {
        //            destinationAnnotation.coordinate = location.coordinate
        //        }
        //
        //        self.mapkitView.showAnnotations([sourceAnnotation,destinationAnnotation], animated: true )
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = sourceMapItem
        directionRequest.destination = destinationMapItem
        directionRequest.transportType = .automobile
        
        // Calculate the direction
        let directions = MKDirections(request: directionRequest)
        
        directions.calculate {
            (response, error) -> Void in
            
            guard let response = response else {
                if let error = error {
                    print("Error: \(error)")
                }
                
                return
            }
            
            let route = response.routes[0]
            
            self.mapKitView.addOverlay((route.polyline), level: MKOverlayLevel.aboveRoads)
            
//            let span = MKCoordinateSpan(latitudeDelta: 0.07, longitudeDelta: 0.07)
            let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)

            let region = MKCoordinateRegion(center: pickupCoordinate, span: span)
            self.mapKitView.setRegion(region, animated: true)
            self.mapKitView.showsUserLocation = true
            
            // For Images
            let info1 = CustomPointAnnotation()
            info1.coordinate = CLLocationCoordinate2DMake(pickupCoordinate.latitude, pickupCoordinate.longitude)
//                        info1.title = "Info1"
            //            info1.subtitle = "Subtitle"
            info1.image = #imageLiteral(resourceName: "Icon-App-60x60-64")
                //#imageLiteral(resourceName: "icon_location_pin_black")
            
            let info2 = CustomPointAnnotation()
            info2.coordinate = CLLocationCoordinate2DMake(destinationCoordinate.latitude, destinationCoordinate.longitude)
            //            info2.title = "Info2"
            //            info2.subtitle = "Subtitle"
            info2.image = #imageLiteral(resourceName: "Icon-App-60x60-63")
            
            self.mapKitView.addAnnotation(info1)
            self.mapKitView.addAnnotation(info2)
            
            //            let rect = route.polyline.boundingMapRect
            //            self.mapkitView.setRegion(MKCoordinateRegion(rect), animated: true)
            
        }
    }
    
    func show_DriverLocations(coordinates: [CLLocationCoordinate2D]) {
        
        // For Images
        let info1 = CustomPointAnnotation()
        info1.coordinate = CLLocationCoordinate2DMake(coordinates[0].latitude, coordinates[0].longitude)
        info1.title = self.driver_time + " Arriving"
        //            info1.subtitle = "Subtitle"
        
        if self.placeOrderAccpetResp.vehicle_type == "bike" {
            info1.image = #imageLiteral(resourceName: "icon_DriverBike")
        }else {
            info1.image = #imageLiteral(resourceName: "icon_driverCar")
        }
        
        self.mapKitView.addAnnotation(info1)
        self.mapKitView.selectAnnotation(info1, animated: true)
        //        }
    }
        
        func zoomFormap(coordinates: CLLocationCoordinate2D, latDelta: Double, longDelta: Double) {
            
            let span = MKCoordinateSpan(latitudeDelta: latDelta, longitudeDelta: longDelta)
            let region = MKCoordinateRegion(center: coordinates, span: span)
            self.mapKitView.setRegion(region, animated: true)
        }
        
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            
            
            if !(annotation is CustomPointAnnotation) {
                return nil
            }
            
            let reuseId = "test"
            
            var anView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId)
            if anView == nil {
                anView = MKAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
                anView!.canShowCallout = true
            }
            else {
                anView!.annotation = annotation
            }
            
            //Set annotation-specific properties **AFTER**
            //the view is dequeued or created...
            
            let cpa = annotation as! CustomPointAnnotation
            anView!.image = cpa.image //UIImage(named:cpa.imageName)
            
            return anView!
        }
        
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            
            let renderer = MKPolylineRenderer(overlay: overlay)
            
            renderer.strokeColor = UIColor(red: 17.0/255.0, green: 147.0/255.0, blue: 255.0/255.0, alpha: 1)
            
            renderer.lineWidth = 3.0
            
            return renderer
        }
        
    }

*/

//MARK:- CustomPointAnnotation

/*

class CustomPointAnnotation: MKPointAnnotation {
    var image: UIImage!
}
*/
