//
//  TripDetailsVC.swift


import UIKit
import MFSDK
import SDWebImage

// In APPDelegate
// Pod Name :     pod 'MyFatoorah'

let directPaymentToken = "7Sv7S92WS4mKNxVQOnj9TUUmjQkaGTEY6m_DCTQX9EV_BFL3XbtHds-qF4QMd43yfhZwgFjecPZMr3SYRqjYRhv0aUW8cQeZTtt7hKBljsP6CH-3SKyT0nT9vmTGfIAUfo_4blK4qAI3tH1TKY-RYQzmZMKtGYYeCwJy-futYmegXf0yy7kvNc3fid4m06rRU34zkvioyHBVssW-Id6RrQ00uVXD9tDRBuAJgIR-r6usB-7t0wN1Ofr7G5USvdTH3ZfEjOytULrqqLA6CuQbt5KWa429OXJLQEOJWdFghqEa_zNsty9jbzwP3-v4HcTjeDsUvLg9bXWLjJVpUobiyQknQFVl71zNMzFN7ZEQ0gtRKnDXSSCjaGsCNyZ02OGuhh-WFleClfDp9EQ7tHkCr6RQHiOQJdx3XroM-UrSVQEIE6L1zIx3yLiCQlZQiuJFm4yCMNwOS9QlBoSIkw5uV7Gaw87Hg1SkQHiWDQShbFL50U4C1NAVnTSsbR5UQITvau8YoaP7wO3TQkPaqoAJYCJD1uNHnnuUyjJapyo1teKDaG_UaP98rGJl8Gi1qzzd2kQ-02MSNpJPxUgPXQ61cM3tNi1yWtPbgJARP4XwjQqpJ5G6HGA7PHSHfLd2x0MjZ9UN_kTNc2PtrYM3xnAacRDmc0iH-nEJTRa5Mt0BSy_IXDWV"
            
//        "fVysyHHk25iQP4clu6_wb9qjV3kEq_DTc1LBVvIwL9kXo9ncZhB8iuAMqUHsw-vRyxr3_jcq5-bFy8IN-C1YlEVCe5TR2iCju75AeO-aSm1ymhs3NQPSQuh6gweBUlm0nhiACCBZT09XIXi1rX30No0T4eHWPMLo8gDfCwhwkbLlqxBHtS26Yb-9sx2WxHH-2imFsVHKXO0axxCNjTbo4xAHNyScC9GyroSnoz9Jm9iueC16ecWPjs4XrEoVROfk335mS33PJh7ZteJv9OXYvHnsGDL58NXM8lT7fqyGpQ8KKnfDIGx-R_t9Q9285_A4yL0J9lWKj_7x3NAhXvBvmrOclWvKaiI0_scPtISDuZLjLGls7x9WWtnpyQPNJSoN7lmQuouqa2uCrZRlveChQYTJmOr0OP4JNd58dtS8ar_8rSqEPChQtukEZGO3urUfMVughCd9kcwx5CtUg2EpeP878SWIUdXPEYDL1eaRDw-xF5yPUz-G0IaLH5oVCTpfC0HKxW-nGhp3XudBf3Tc7FFq4gOeiHDDfS_I8q2vUEqHI1NviZY_ts7M97tN2rdt1yhxwMSQiXRmSQterwZWiICuQ64PQjj3z40uQF-VHZC38QG0BVtl-bkn0P3IjPTsTsl7WBaaOSilp4Qhe12T0SRnv8abXcRwW3_HyVnuxQly_OsZzZry4ElxuXCSfFP2b4D2-Q"
        
        let baseURL = "https://api.myfatoorah.com/"
        // "https://apitest.myfatoorah.com"
        MFSettings.shared.configure(token: directPaymentToken, baseURL: baseURL)
        
        // you can change color and title of navigation bar
        let them = MFTheme(navigationTintColor: .white, navigationBarTintColor: .lightGray, navigationTitle: "Payment", cancelButtonTitle: "Cancel")
        MFSettings.shared.setTheme(theme: them)





class TripDetailsVC: UIViewController {
    
    @IBOutlet weak var lbl_bookingID: UILabel!
    @IBOutlet weak var lbl_waitDuration: UILabel!
    @IBOutlet weak var lbl_tripDuration: UILabel!
    @IBOutlet weak var lbl_waitDurationAmount: UILabel!
    @IBOutlet weak var lbl_tripDurAmount: UILabel!
    @IBOutlet weak var lbl_totalFare: UILabel!
    @IBOutlet weak var btn_PayNowOutlet: UIButton!
    @IBOutlet weak var view_totalFare: UIView!
    
    @IBOutlet weak var view_bg: UIView!
    
    @IBOutlet weak var height_pendingDetails: NSLayoutConstraint!
    
    @IBOutlet weak var view_paidThrough: UIView!
    @IBOutlet weak var lbl_paidCash: UILabel!
    @IBOutlet weak var view_paidThroughSwipe: UIView!
    @IBOutlet weak var lbl_paidSwipe: UILabel!
    @IBOutlet weak var view_pendingAmount: UIView!
    @IBOutlet weak var lbl_pendingAmount: UILabel!
    @IBOutlet weak var CV_paymentMethods: UICollectionView!
    @IBOutlet weak var height_CVPaymentMethods: NSLayoutConstraint!
    @IBOutlet weak var lbl_previousPending: UILabel!
    
    
    var order_id = 0
    var model_ride_u_details = Model_RideUDetails()
    
    var isComingFrom: Enum_commingFrom?
    
    // Payment
    var payment_methods_array = [MFPaymentMethod]()
    var invoiceValue = 1.0
    var selected_id = 1
    var invoice_id = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.initiate_Payment()
        self.height_CVPaymentMethods.constant = 0
        
        btn_PayNowOutlet.layer.cornerRadius = 8
        
        self.view_totalFare.cornerRadius(radius: 8, bwidth: 1.2, bColor: .black)
        self.view_paidThrough.cornerRadius(radius: 8, bwidth: 1.2, bColor: .black)
        self.view_paidThroughSwipe.cornerRadius(radius: 8, bwidth: 1.2, bColor: .black)
        self.view_pendingAmount.cornerRadius(radius: 8, bwidth: 1.2, bColor: .black)
        
        self.view_bg.cornerRadius(radius: 8, bwidth: 0.5, bColor: .lightGray)
        
        self.CV_paymentMethods.delegate = self
        self.CV_paymentMethods.dataSource = self
        
        self.collectionViewFlowLayout()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.service_get_ride_u_details(order_id: self.order_id)
    }
    
    //MARK:- Buttons Actions
    
    @IBAction func btn_payNowAction(_ sender: Any) {
        
        
        self.execute_payment(method: self.selected_id)
        
    }
    
    @IBAction func back_Action(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func btn_homeAction(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    //MARK:- Functions
    func service_get_ride_u_details(order_id: Int) {
        
        let params = ["order_id": order_id]
        
        APIManager.shared.requestPOSTURL(api_ride_u_details, params: params, headers: nil, success: { (response) in
            do {
                let jsonData = try JSONDecoder().decode(Model_RideUDetails.self, from: response!.data!)
                if jsonData.result != nil {
                    self.model_ride_u_details = jsonData
                    
                }
                self.setUp_data()
            }catch {
                print(error)
            }
        }) { (msg) in
            self.showToastSwift(msg: msg)
        }
    }
    
    func collectionViewFlowLayout() {
        
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        
        layout.itemSize = CGSize(width: 70, height: 45)
        layout.minimumInteritemSpacing = 5
        layout.minimumLineSpacing = 5
        
        self.CV_paymentMethods.collectionViewLayout = layout
        
    }
    
    func initiate_Payment()  {
        
        // initiatePayment
        
        self.invoiceValue = 1.0
        
        let initiatePayment = MFInitiatePaymentRequest(invoiceAmount: Decimal(invoiceValue), currencyIso: .kuwait_KWD)
        MFPaymentRequest.shared.initiatePayment(request: initiatePayment, apiLanguage: .english) { [weak self] (response) in
            switch response {
            case .success(let initiatePaymentResponse):
                _ = initiatePaymentResponse.paymentMethods
                if let paymentMethods = initiatePaymentResponse.paymentMethods, !paymentMethods.isEmpty {
                    self?.payment_methods_array = paymentMethods
                    
                    //                        print(self!.selectedPaymentMethod)
                    
                    self?.CV_paymentMethods.reloadData()
                    self?.CV_paymentMethods.performBatchUpdates(nil, completion: { (isSuccess) in
                        if isSuccess {
                            self?.height_CVPaymentMethods.constant = (self?.CV_paymentMethods.contentSize.height)! + 30
                        }
                    })
                }
            case .failure(let failError):
                print(failError)
            }
        }
        
    }
    
    func execute_payment(method: Int) {
        
        // executePayment
        let request = MFExecutePaymentRequest(invoiceValue: Decimal(invoiceValue), paymentMethod: method)
        
                request.customerName = user_Defaults.value(forKey: Enum_userData.name.rawValue)! as! String
                request.customerMobile = user_Defaults.value(forKey: Enum_userData.mobile.rawValue)! as! String
                request.mobileCountryCode = user_Defaults.value(forKey: Enum_userData.country_code.rawValue)! as! String
                if let email = user_Defaults.value(forKey: Enum_userData.email.rawValue) as? String {
                    request.customerEmail = email
                }
        
//                 var productList = [MFProduct]()
//                let product = MFProduct(name: user_Defaults.value(forKey: Enum_userData.name.rawValue)! as! String, unitPrice: 1, quantity: 1)
//                 productList.append(product)
//                 request.invoiceItems = productList
        
        MFPaymentRequest.shared.executePayment(request: request, apiLanguage: .english) { [weak self] (response,invoiceId) in
            switch response {
            case .success(let executePaymentResponse):
                
                print(invoiceId!)
                print("\(executePaymentResponse.invoiceStatus ?? "")")
                
                self?.invoice_id = invoiceId!
                
                self?.service_paymentUpdate()
                
            case .failure(let failError):
                print(failError)
            }
        }
    }
    
    func service_paymentUpdate() {
        
        let params = ["order_id": self.order_id,
                      "user_id": user_Defaults.value(forKey: Enum_userData.user_id.rawValue)!,
                      "payment_status":"paid",
                      "transaction_id": self.invoice_id]
        
        APIManager.shared.requestPOSTURL(api_paymentUpdate, params: params, headers: nil, success: { (response) in
            do {
                let jsonData = try JSONDecoder().decode(Model_CommonMsgStatus.self, from: response!.data!)
                self.showToastSwift(msg: jsonData.message)
                
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+1.2) {
                    
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "FeedBackVC") as! FeedBackVC
                    vc.order_id = self.order_id
                    vc.driver_id = self.model_ride_u_details.result!.driver_id!
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                
            }catch {
                print(error)
            }
        }) { (msg) in
            self.showToastSwift(msg: msg)
        }
    }
    
    func setUp_data() {
        
        self.lbl_bookingID.text = "Booking ID: \(self.model_ride_u_details.result?.booking_id ?? "")"
        self.lbl_waitDuration.text = self.model_ride_u_details.result!.waiting_time
        self.lbl_waitDurationAmount.text = (self.model_ride_u_details.result!.waiting_time_amount ?? "0") + " KWD"
        
        self.lbl_tripDuration.text = self.model_ride_u_details.result!.total_ride_time
        self.lbl_tripDurAmount.text = (self.model_ride_u_details.result!.time_amount ?? "0") + " KWD"
        
        self.lbl_totalFare.text = "\(self.model_ride_u_details.result!.final_price ?? 1.0)" + " KWD"
        
        if self.isComingFrom == .some(.searchRide) {
            
            self.lbl_previousPending.text = "Your previous ride paymentpending, Please pay to book new ride."
            
            let cachAmount = self.model_ride_u_details.result?.cash_amount ?? "0.0"
            let knitAmount = self.model_ride_u_details.result?.knit_amount ?? "0.0"
            let pending_amount = Double(self.model_ride_u_details.result?.not_paid_amount ?? "0.0")!
            
            self.lbl_paidCash.text = "\(cachAmount) KWD"
            self.lbl_paidSwipe.text = "\(knitAmount) KWD"
            
            if pending_amount > 0.0 {
                self.invoiceValue = pending_amount
                self.lbl_pendingAmount.text = "\(pending_amount) KWD"
            }else {
                self.invoiceValue = self.model_ride_u_details.result!.final_price ?? 1.0
                self.lbl_pendingAmount.text = "\(invoiceValue) KWD"
            }
            
        }else {
            
            self.lbl_previousPending.text = ""
            
            self.height_pendingDetails.constant = 0
            self.invoiceValue = self.model_ride_u_details.result!.final_price ?? 1.0
        }
        
    }
    
}


extension TripDetailsVC: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.payment_methods_array.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CVCell_paymentMethods", for: indexPath) as! CVCell_paymentMethods
        
        cell.imgViewPaymentMethod.sd_setImage(with: URL(string: self.payment_methods_array[indexPath.row].imageUrl!), completed: nil)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let cell = self.CV_paymentMethods.cellForItem(at: indexPath) as! CVCell_paymentMethods
        cell.view_BG.cornerRadius(radius: 8, bwidth: 1.5, bColor: .black)
        
        self.selected_id = self.payment_methods_array[indexPath.row].paymentMethodId
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        
        let cell = self.CV_paymentMethods.cellForItem(at: indexPath) as! CVCell_paymentMethods
        cell.view_BG.cornerRadius(radius: 8, bwidth: 0, bColor: .black)
    }
}


extension TripDetailsVC: UICollectionViewDelegateFlowLayout {
    // Collection view flow layout setup
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: 70, height: 45)
        
    }
    
    //    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
    //        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    //    }
    //
    //    // This is for space between cells in row
    //    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
    //        return 0
    //    }
    //
    //    // This is for space between 1 row to another
    //    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
    //        return 5
    //    }
}
