//
//  UIView+Localizations.swift

import Foundation
import UIKit

extension UITextField {

    func localizeTF() {

        if selected_language == .ar {
            if self.textAlignment == .left {
                self.textAlignment = .right
            }else {
                self.textAlignment = .right
            }

        }

    }

}

extension UILabel {
    
    func localize_lbl() {
        
        if selected_language == .ar {
            if self.textAlignment == .left {
                self.textAlignment = .right
            }else {
                self.textAlignment = .left
            }
            
        }
        
    }
    
}

extension UITextView {
    
    func localizeTxtView() {
        
        if selected_language == .ar {
            if self.textAlignment == .left {
                self.textAlignment = .right
            }else if self.textAlignment == .right {
                self.textAlignment = .left
            }
            
        }
        
    }
    
}
