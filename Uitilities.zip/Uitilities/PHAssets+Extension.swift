//
//  PHAssets+Extension.swift


import Foundation
import Photos
import MobileCoreServices
import UIKit

extension PHAsset {
    
    var get_fileName: String {
        
        var fname:String?
        
        if #available(iOS 9.0, *) {
            let resources = PHAssetResource.assetResources(for: self)
            if let resource = resources.first {
                fname = resource.originalFilename
            }
        }
        
        if fname == nil {
            // this is an undocumented workaround that works as of iOS 9.1
            fname = self.value(forKey: "filename") as? String
        }
        
        return fname ?? "FileName"
    }
    
    func get_extension() -> String {
    
        if let name = self.get_fileName.components(separatedBy: "/").last {
            return name
        }else {
            debugPrint("No Extension Found")
            return ""
        }
        
    }
    
    func getFileType(onCompletion: @escaping(_ type: Enum_FileTypes)-> Void) {
        
        var enum_type = Enum_FileTypes(rawValue: "")
        
        if self.mediaType == .image {
            enum_type = Enum_FileTypes(rawValue: Enum_FileTypes.photo.rawValue)
            onCompletion(enum_type!)
        }else if self.mediaType == .audio {
            enum_type = Enum_FileTypes(rawValue: Enum_FileTypes.audio.rawValue)
            onCompletion(enum_type!)
        }else if self.mediaType == .video {
            enum_type = Enum_FileTypes(rawValue: Enum_FileTypes.video.rawValue)
            onCompletion(enum_type!)
        }else {
            onCompletion(Enum_FileTypes(rawValue: Enum_FileTypes.none.rawValue)!)
        }
        
        /*
         
         guard let ext = self.originalFilename?.components(separatedBy: ".").last else {
         debugPrint("No Type Found")
         return
         }
         
         if ext.caseInsensitiveCompare(Enum_FileTypes.mp4.rawValue) == .orderedSame ||
         ext.caseInsensitiveCompare(Enum_FileTypes.m4a.rawValue) == .orderedSame ||
         ext.caseInsensitiveCompare("3GP") == .orderedSame {
         
         enum_type = Enum_FileTypes(rawValue: Enum_FileTypes.video.rawValue)
         onCompletion(enum_type!)
         }else if ext.caseInsensitiveCompare(Enum_FileTypes.MP3.rawValue) == .orderedSame ||
         ext.caseInsensitiveCompare(Enum_FileTypes.AAC.rawValue) == .orderedSame ||
         ext.caseInsensitiveCompare(Enum_FileTypes.wma.rawValue) == .orderedSame {
         
         enum_type = Enum_FileTypes(rawValue: Enum_FileTypes.audio.rawValue)
         onCompletion(enum_type!)
         }else if ext.caseInsensitiveCompare(Enum_FileTypes.JPG.rawValue) == .orderedSame ||
         ext.caseInsensitiveCompare(Enum_FileTypes.JPEG.rawValue) == .orderedSame ||
         ext.caseInsensitiveCompare(Enum_FileTypes.PNG.rawValue) == .orderedSame {
         
         enum_type = Enum_FileTypes(rawValue: Enum_FileTypes.photo.rawValue)
         onCompletion(enum_type!)
         }
         
         */
        
    }
    
    /**
     Getting max 4 images
     */
    
    func get_image_original(onCompletion: @escaping(_ image: UIImage)->Void) {
        
        var image = UIImage()
        let manager = PHImageManager.default()
        let options = PHImageRequestOptions()
        options.version = .original
        options.isSynchronous = true
        manager.requestImageData(for: self, options: options) { (data, string, orientation, info) in
            
            DispatchQueue.global(qos: .userInteractive).async {
                
                if let data = data {
                    if let img = UIImage(data: data) {
                        image = img
                        onCompletion(img)
                    }
                }
            }
        }
    }
    
    /**
     Get All Images
     */
    func get_imageWithSize(width: CGFloat, height: CGFloat) -> UIImage {
        
        let manager = PHImageManager.default()
        let option = PHImageRequestOptions()
        var thumbnail = UIImage()
        option.isSynchronous = true
        
        manager.requestImage(for: self, targetSize: CGSize(width: width, height: height), contentMode: .aspectFit, options: option, resultHandler: {(result, info)->Void in
            thumbnail = result!
        })
        return thumbnail
    }
    
    func get_video (onCompetion: @escaping (_ videoURL: URL)-> Void) {
        
        guard (self.mediaType == .video) else {
            print("Not a valid video media type")
            return
        }
        
        PHCachingImageManager().requestAVAsset(forVideo: self, options: nil) { (avasset, avaudioMix, info) in
            
            let asset = avasset as! AVURLAsset
            onCompetion(asset.url)
            
        }
    }
}

enum Enum_FileTypes: String {
    
    // Videos
    case mp4
    case m4a
    case mov
    case ThreeGP
    case wmv
    case wma
    case WAV
    case video
    
    // Audio
    case MP3
    case AAC
    case WMA
    case audio
    
    // Photos
    
    case JPEG
    case GIF
    case PNG
    case JPG
    case photo
    
    case none
    
}
