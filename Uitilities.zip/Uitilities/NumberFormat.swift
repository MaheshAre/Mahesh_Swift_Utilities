//
//  NumberFormat.swift

import Foundation

extension Double {
    /// Rounds the double to decimal places value
    func decimal_format(decimalPoints:Int) -> Double {
        let divisor = pow(10.0, Double(decimalPoints))
        return (self * divisor).rounded() / divisor
    }
}

extension Float {
    /// Rounds the double to decimal places value
    func decimal_format(decimalPoints:Int) -> Float {
        let divisor = pow(10.0, Float(decimalPoints))
        return (self * divisor).rounded() / divisor
    }
}
