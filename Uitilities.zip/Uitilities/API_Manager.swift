//
//  APIHandler.swift

import Foundation
import Alamofire
import UIKit


/*
 
 pod 'Alamofire'
 
 */

struct APIManager {
    
    static let shared = APIManager()
    private init() { }
    
    //MARK:- Service Hitting Functions
    
    public func postRequest(urlStr: String, params: [String:Any], viewController: UIViewController?, onCompletion: @escaping(_ result: DataResponse<Any>?, _ _success: Bool)->Void) {
        
        if Connectivity.isConnectedToInternet {
            
//            SKActivityIndicator.show()
//            Loader.shared.showLoder()
            
            Utitlities.shared.showProgressLoading(title: "Loading...")
                        
            guard let url = URL.init(string: BaseURL + urlStr) else { return }
            
//                        print("Service ---> \(url)")
            //            print("Parameters ---> \(params)")
            

            
            Alamofire.request(url, method: .post, parameters: params, encoding: JSONEncoding.default).validate().responseJSON { response in
                
                //                print(response.result.value!)
                //                print(response.value!)
                var errorStr = ""
                if response.error == nil, response.data != nil {
                    
                    if let respDict = response.result.value as? [String: Any] {
                        
                        if let status = respDict["status"] as? Bool, let message = respDict["message"] as? String {
                            
                            Utitlities.shared.dismissProgressLoading()
                            
                            if status {
                                errorStr = message
                                onCompletion(response, true)
                            }else {
                                errorStr = message
                                onCompletion(nil, false)
                            }
                        } else {
                            errorStr = response.error?.localizedDescription ?? "Error"
                            onCompletion(nil, false)
                        }
                    }else {
                        errorStr = response.error?.localizedDescription ?? "Error"
                        onCompletion(nil, false)
                    }
                    
                }else {
                    
//                    Loader.shared.hideLoader()
                    viewController!.view.makeToast(errorStr)
                    errorStr = response.error?.localizedDescription ?? "Error"
                    Utitlities.shared.dismissProgressLoadingWithError(message: errorStr)
                    print(response.error!)
                    onCompletion(nil, false)
                    return
                }
                
                Utitlities.shared.dismissProgressLoading()
//                Loader.shared.hideLoader()
//                viewController?.showToast(message: errorStr, duration: 3.0)
            }
            
        }else {
            Utitlities.shared.dismissProgressLoading()
//            Loader.shared.hideLoader()
            viewController!.view.makeToast("Please check your Internet connection")
            return
        }
        
    }
    
    public func postRequestWithoutLoader(urlStr: String, params: [String:Any], viewController: UIViewController?, onCompletion: @escaping(_ result: DataResponse<Any>?, _ _success: Bool)->Void) {
        
        if Connectivity.isConnectedToInternet {
            
            guard let url = URL.init(string: BaseURL + urlStr) else { return }
            //            print("Service ---> \(url)")
            //            print("Parameters ---> \(params)")
            
            
            Alamofire.request(url, method: .post, parameters: params, encoding: JSONEncoding.default).validate().responseJSON { response in
                
                //                print(response.result.value!)
                //                print(response.value!)
                var errorStr = ""
                if response.error == nil, response.data != nil {
                    
                    if let respDict = response.result.value as? [String: Any] {
                        
                        if let status = respDict["status"] as? Bool, let message = respDict["message"] as? String {
                            
                            if status {
                                errorStr = message
                                onCompletion(response, true)
                            }else {
                                errorStr = message
                                onCompletion(nil, false)
                            }
                        } else {
                            errorStr = response.error?.localizedDescription ?? "Error"
                            onCompletion(nil, false)
                        }
                    }else {
                        errorStr = response.error?.localizedDescription ?? "Error"
                        onCompletion(nil, false)
                    }
                    
                }else {
                    
                    viewController!.view.makeToast(errorStr)
                    errorStr = response.error?.localizedDescription ?? "Error"
                    print(response.error!)
                    onCompletion(nil, false)
                    return
                }
                if let vc = viewController {
                    vc.view.makeToast(errorStr)
                }
                
            }
            
        }else {
            viewController!.view.makeToast("Please check your Internet connection")
            return
        }
        
    }
    
    
    func requestPOSTURL(_ strURL : String, params : [String : Any]?, headers : [String : String]?, success:@escaping (DataResponse<Any>) -> Void, failure:@escaping (String) -> Void) {
        
        if Connectivity.isConnectedToInternet {
            
            DispatchQueue.global(qos: .userInteractive).async {
                
               Utitlities.shared.showProgressLoading(title: "Loading...")
                
                let manager = Alamofire.SessionManager.default
                manager.session.configuration.timeoutIntervalForRequest = 300
                manager.request(BaseURL + strURL, method: .post, parameters: params, encoding: JSONEncoding.default, headers: headers).responseJSON { (responseObject) -> Void in
                    
                    if responseObject.result.isSuccess {
                        success(responseObject)
                    }
                    if responseObject.result.isFailure {
                        let error : Error = responseObject.result.error!
                        failure("\(error)")
                    }
                    
                    Utitlities.shared.dismissProgressLoading()
                }
            }
            
        }else {
            failure("Please check Internet Connection")
        }
        
        
    }
    
    func requestGETURL(_ strURL : String, params : [String : Any]?, headers : [String : String]?, success:@escaping (DataResponse<Any>) -> Void, failure:@escaping (String) -> Void) {
        
        if Connectivity.isConnectedToInternet {
            
            Utitlities.shared.showProgressLoading(title: "Loading...")
            
            Alamofire.request(BaseURL + strURL, method: .get, parameters: params, encoding: JSONEncoding.default, headers: headers).responseJSON { (responseObject) -> Void in
                
                if responseObject.result.isSuccess {
                    success(responseObject)
                }
                if responseObject.result.isFailure {
                    let error : Error = responseObject.result.error!
                    failure("\(error)")
                }
                
                Utitlities.shared.dismissProgressLoading()
            }
            
        }else {
            
            failure("Please check Internet Connection")
        }
        
        
    }
    
    func requestPOSTURL_withoudLoader(_ strURL : String, params : [String : Any]?, headers : [String : String]?, success:@escaping (DataResponse<Any>) -> Void, failure:@escaping (String) -> Void) {
        
        if Connectivity.isConnectedToInternet {
            
            DispatchQueue.global(qos: .userInteractive).async {
                
                let manager = Alamofire.SessionManager.default
                manager.session.configuration.timeoutIntervalForRequest = 300
                manager.request(BaseURL + strURL, method: .post, parameters: params, encoding: JSONEncoding.default, headers: headers).responseJSON { (responseObject) -> Void in
                    
                    if responseObject.result.isSuccess {
                        success(responseObject)
                    }
                    if responseObject.result.isFailure {
                        let error : Error = responseObject.result.error!
                        failure("\(error)")
                    }
                    
                }
            }
            
            
        }else {
            
            failure("Please check Internet Connection")
        }
        
        
    }
    
    func POSTDataUsingFormData(apiStr: String, parameters: [String: Any]?, image_array: [String:[ImageNameWithURL]]?, imagesArray_key: String, mimeType: String, headers : [String : String]?, success:@escaping (DataResponse<Any>) -> Void, failure:@escaping (String) -> Void) {
        
    if Connectivity.isConnectedToInternet {
        
        Loader.shared.showLoder()
        
        guard let url = URL.init(string: BaseURL + apiStr) else { return }
        
        let parameters: [String:Any] = parameters ?? [:]
        
        //             let headers: HTTPHeaders = ["Authorization":"Bearer hm0UVOF7KSMgTQBHxrpj9MC6KnN3JVoN3KDXSDoZ_u1ji2v91Fd90H0VWzCw6iEgillmw7nDU5qjbs9bK40o9kdJ9AH8cwcG6mMkwentwNax8bMOPqYd90Io6KE_knHfX8a3vD6ucqhlVtnoIqEV445usB-GkpBjWGI_PQos4I-2KGycRGv4YhuRqIQVUDowj5hc0NT44uv4f4bPa-Tes4fcAF2fiS8xO8ovnCbUwAO3tlj449x5Qc3Bhc-x734uceCxEDh6_5OV0A8QkaDobPdSES9UgzcCFGdF6CB0ckjJupyljBsJxTobrtnMlfn3RU_KyktqJgIjJBSzSDMfpaozK1ZaPiIu9GNZvvecSsLQdy3DtARCoZCLR6ku8kmBizz_Qu51ryRyAB992D0JmZIPIxLfqngaUs7SG_gfGkM_QRYV-bfDtU2f6W2z0dJgdZjFgyODI0gU4DD4umJAF3I62y-GWpOKM5joq_XRaEqIElZCxqETfT9ay7T5eKfWCFp9_FcC7es11EMlVGEKZ7YFsFzg_9bq_lRRcWRCS1cDXGYOwYOCFzyxOPnPDLipK_JH94qHKF_KwiDwAJS5XgEBbbynMffooKofUMNK1zDTxskayFgkpvdbpdqkha70CEAk5YRkA0fo3fLGgjDNIxiKx3XcO6biFhsHNw749Bg"]//user.value(forKey:"token") as! String]
        
        
        Alamofire.upload(multipartFormData: { multipartFormData in
            
            //Parameter for Upload files
            
            // "image.jpeg"
            
            if let imagesDict = image_array {
                if let images_array = imagesDict[imagesArray_key] {
                    // For Images
                    for image in images_array {
                        if let imgData = image.image.jpegData(compressionQuality:Enum_JPEGQuality.high.rawValue) {
                            multipartFormData.append(imgData, withName:imagesArray_key,fileName: image.name, mimeType:mimeType)
                        }
                        // For Videos
                        if let videoFilePath = image.videoURL {
                            multipartFormData.append(videoFilePath, withName: imagesArray_key)
                        }
                    }
                    // For Parameters
                    for (key, value) in parameters {
                        
                        if let tagsArray = value as? [String] {
                            
                            for i in 0..<tagsArray.count {
                                
                                let value = tagsArray[i] //as! Int
                                let valueObj = String(value)
                                
                                let keyObj = key + "[" + String(i) + "]"
                                multipartFormData.append(valueObj.description.data(using: .utf8)!, withName: keyObj)
                                //                            multipartFormData.append(valueObj.data(using: .utf8)!, withName: keyObj)
                                
                            }
                            
                            
                            
                        }else if let stringValue = value as? String {
                            
                            multipartFormData.append(stringValue.data(using: .utf8)!, withName: key)
                            
                        }
                        
//                        multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
                    }
                }
            }
            
        }, usingThreshold:UInt64.init(),
           
           to: url
            
            /*APiStr.upload_image.urlStr*/, //URL Here
            
            method: .post,
            headers: headers, //pass header dictionary here
            encodingCompletion: { (result) in
                                    
                switch result {
                    
                case .success(let upload, _, _):
                    
                    upload.responseJSON { response in
                        Loader.shared.hideLoader()
                        if response.response?.statusCode == 200 {
                            
                            print("MY RESPONSE == \(response)")
                            success(response)
                        }else {
                            
                        }
                        
                    }
                case .failure(let encodingErr):
                    print(encodingErr)
                    Loader.shared.hideLoader()
                    failure("\(encodingErr)")
                    break
                }
                
        })
        
    }
        
        
    }
    

    func POSTRequestWithX_www_form_urlEncoded(apiStr: String, params: [String: Any], success:@escaping (DataResponse<Any>) -> Void, failure:@escaping (String) -> Void) {

            if Connectivity.isConnectedToInternet {

                Utitlities.shared.showProgressLoading(title: "Loading...")
                
                let headers = ["Content-Type": "application/x-www-form-urlencoded"]

                Alamofire.request(BaseURL+apiStr, method: .post, parameters: params, encoding:  URLEncoding.httpBody, headers: headers).responseJSON { (response:DataResponse<Any>) in

                    switch(response.result) {

                    case.success:

                        Utitlities.shared.dismissProgressLoading()
                        success(response)

                    case.failure(let error):

                        Utitlities.shared.dismissProgressLoading()
                        failure("\(error)")

                    }
                }

            }else {

                Utitlities.shared.dismissProgressLoading()
                failure("Please check your Internet Connection")
            }
        }


    
}

//MARK:- Internet Checking
struct Connectivity {
    
    static let sharedInstance = NetworkReachabilityManager()!
    static var isConnectedToInternet:Bool {
        return self.sharedInstance.isReachable
    }
}

struct NullHandling {
    
    static let shared = NullHandling()
    private init() { }
    
    func nullToNil(value : AnyObject?) -> AnyObject? {
        if value is NSNull {
            return nil
        } else {
            return value
        }
    }
}


struct ImageNameWithURL {
    
    var name = String()
    var image = UIImage()
    var videoURL = URL(string: "")
    var type: Enum_mimeTypes?
    var key = String()
}

enum Enum_mimeTypes: String {
    
    case file = "file"
    case jpg = "image/jpeg"
    case png = "image/png"
    case mp4 = "video/mp4"
    case mov = "video/mov"
    
    // For Identify in api hitting function
    case image
    case video
}

struct API_Handler {
    
    static let shared = API_Handler()
    private init() { }
    
    //MARK:- Service Hitting Functions
    
    public func postRequest(urlStr: String, params: [String:Any], viewController: UIViewController?, onCompletion: @escaping(_ result: Any?, _ _success: Bool)->Void) {
        
        if Connectivity.isConnectedToInternet {
            
            CustomSKIndicator.shared.showSKIndicatorSpinner(statusMessage: "Loading...")
//            Loader.shared.showLoder()
                                    
            guard let url = URL.init(string: BaseURL + urlStr) else { return }
            
//                        print("Service ---> \(url)")
            //            print("Parameters ---> \(params)")
            
            AF.request(url, method: .post, parameters: params, encoding: JSONEncoding.default).validate().responseJSON { response in
                
                //                print(response.result.value!)
                //                print(response.value!)
                var errorStr = ""
                if response.error == nil, response.data != nil {
                    
                    if let respDict = response.value as? [String: Any] {
                        
                        if let status = respDict["status"] as? Bool, let message = respDict["message"] as? String {
                            
                            SKActivityIndicator.dismiss()
                            
                            if status {
                                errorStr = message
                                onCompletion(response.result, true)
                                onCompletion(response, true)
                            }else {
                                errorStr = message
                                onCompletion(nil, false)
                            }
                        } else {
                            errorStr = response.error?.localizedDescription ?? "Error"
                            onCompletion(nil, false)
                        }
                    }else {
                        errorStr = response.error?.localizedDescription ?? "Error"
                        onCompletion(nil, false)
                    }
                    
                }else {
                    SKActivityIndicator.dismiss()
//                    Loader.shared.hideLoader()
                    viewController!.view.makeToast(errorStr)
                    errorStr = response.error?.localizedDescription ?? "Error"
                    print(response.error!)
                    onCompletion(nil, false)
                    return
                }
                
                SKActivityIndicator.dismiss()
//                Loader.shared.hideLoader()
//                viewController?.showToast(message: errorStr, duration: 3.0)
            }
            
        }else {
            SKActivityIndicator.dismiss()
//            Loader.shared.hideLoader()
            viewController!.view.makeToast("Please check your Internet connection")
            return
        }
        
    }
    
    public func postRequestWithoutLoader(urlStr: String, params: [String:Any], viewController: UIViewController?, onCompletion: @escaping(_ result: Any?, _ _success: Bool)->Void) {
        
        if Connectivity.isConnectedToInternet {
            
            guard let url = URL.init(string: BaseURL + urlStr) else { return }
            //            print("Service ---> \(url)")
            //            print("Parameters ---> \(params)")
            
            
            AF.request(url, method: .post, parameters: params, encoding: JSONEncoding.default).validate().responseJSON { response in
                
                //                print(response.result.value!)
                //                print(response.value!)
                var errorStr = ""
                if response.error == nil, response.data != nil {
                    
                    if let respDict = response.value as? [String: Any] {
                        
                        if let status = respDict["status"] as? Bool, let message = respDict["message"] as? String {
                            
                            if status {
                                errorStr = message
                                onCompletion(response, true)
                            }else {
                                errorStr = message
                                onCompletion(nil, false)
                            }
                        } else {
                            errorStr = response.error?.localizedDescription ?? "Error"
                            onCompletion(nil, false)
                        }
                    }else {
                        errorStr = response.error?.localizedDescription ?? "Error"
                        onCompletion(nil, false)
                    }
                    
                }else {
                    
                    viewController!.view.makeToast(errorStr)
                    errorStr = response.error?.localizedDescription ?? "Error"
                    print(response.error!)
                    onCompletion(nil, false)
                    return
                }
                if let vc = viewController {
                    vc.view.makeToast(errorStr)
                }
                
            }
            
        }else {
            viewController!.view.makeToast("Please check your Internet connection")
            return
        }
        
    }
    
    
    func requestPOSTURL(_ strURL : String, params : [String : Any]?, headers : HTTPHeaders?, success:@escaping (AFDataResponse<Any>?) -> Void, failure:@escaping (String) -> Void) {
        
        if Connectivity.isConnectedToInternet {
            
            DispatchQueue.global(qos: .userInteractive).async {
                
               CustomSKIndicator.shared.showSKIndicatorSpinner(statusMessage: "Loading...")
                
                let manager = AF
                manager.session.configuration.timeoutIntervalForRequest = 300
                
                manager.request(BaseURL + strURL, method: .post, parameters: params, encoding: JSONEncoding.default, headers: headers).responseJSON { (responseObject) -> Void in
                    
                    switch responseObject.result {
                    case .success:
                        success(responseObject)
                        break
                        
                    case let .failure(error):
                        failure("\(error)")
                    }
                    
                    SKActivityIndicator.dismiss()
                }
            }
            
        }else {
            failure("Please check Internet Connection")
        }
        
        
    }
    
    func requestGETURL(_ strURL : String, params : [String : Any]?, headers : HTTPHeaders?, success:@escaping (AFDataResponse<Any>?) -> Void, failure:@escaping (String) -> Void) {
        
        if Connectivity.isConnectedToInternet {
            
            CustomSKIndicator.shared.showSKIndicatorSpinner(statusMessage: "Loading...")
            
            let manager = AF
            manager.session.configuration.timeoutIntervalForRequest = 300
            
            manager.request(BaseURL + strURL, method: .get, parameters: params, encoding: JSONEncoding.default, headers: headers).responseJSON { (responseObject) -> Void in
                
                switch responseObject.result {
                case .success:
                    success(responseObject)
                    break
                    
                case let .failure(error):
                    failure("\(error)")
                }
                
                SKActivityIndicator.dismiss()
            }
            
        }else {
            
            failure("Please check Internet Connection")
        }
        
        
    }
    
    func requestPOSTURL_withoudLoader(_ strURL : String, params : [String : Any]?, headers : HTTPHeaders?, success:@escaping (AFDataResponse<Any>?) -> Void, failure:@escaping (String) -> Void) {
        
        if Connectivity.isConnectedToInternet {
            
            DispatchQueue.global(qos: .userInteractive).async {
                
                let manager = AF
                manager.session.configuration.timeoutIntervalForRequest = 300
                manager.request(BaseURL + strURL, method: .post, parameters: params, encoding: JSONEncoding.default, headers: headers).responseJSON { (responseObject) -> Void in
                    
                    switch responseObject.result {
                    case .success:
                        success(responseObject)
                        break
                        
                    case let .failure(error):
                        failure("\(error)")
                    }
                }
            }
            
            
        }else {
            
            failure("Please check Internet Connection")
        }
        
        
    }
    
    func POST_FormData(apiStr: String, parameters: [String: Any]?, image_array: [String:[ImageNameWithURL]]?, imagesArray_key: String?, mimeType: Enum_mimeTypes?, headers: HTTPHeaders?, success:@escaping (AFDataResponse<Any>?) -> Void, failure:@escaping (String) -> Void) {
        
        if Connectivity.isConnectedToInternet {
            
            //        Loader.shared.showLoder()
            CustomSKIndicator.shared.showSKIndicatorSpinner(statusMessage: "Loading...")
            
            guard let url = URL.init(string: BaseURL + apiStr) else { return }
            
            let parameters: [String:Any] = parameters ?? [:]
            
            //             let headers: HTTPHeaders = ["Authorization":"Bearer hm0UVOF7KSMgTQBHxrpj9MC6KnN3JVoN3KDXSDoZ_u1ji2v91Fd90H0VWzCw6iEgillmw7nDU5qjbs9bK40o9kdJ9AH8cwcG6mMkwentwNax8bMOPqYd90Io6KE_knHfX8a3vD6ucqhlVtnoIqEV445usB-GkpBjWGI_PQos4I-2KGycRGv4YhuRqIQVUDowj5hc0NT44uv4f4bPa-Tes4fcAF2fiS8xO8ovnCbUwAO3tlj449x5Qc3Bhc-x734uceCxEDh6_5OV0A8QkaDobPdSES9UgzcCFGdF6CB0ckjJupyljBsJxTobrtnMlfn3RU_KyktqJgIjJBSzSDMfpaozK1ZaPiIu9GNZvvecSsLQdy3DtARCoZCLR6ku8kmBizz_Qu51ryRyAB992D0JmZIPIxLfqngaUs7SG_gfGkM_QRYV-bfDtU2f6W2z0dJgdZjFgyODI0gU4DD4umJAF3I62y-GWpOKM5joq_XRaEqIElZCxqETfT9ay7T5eKfWCFp9_FcC7es11EMlVGEKZ7YFsFzg_9bq_lRRcWRCS1cDXGYOwYOCFzyxOPnPDLipK_JH94qHKF_KwiDwAJS5XgEBbbynMffooKofUMNK1zDTxskayFgkpvdbpdqkha70CEAk5YRkA0fo3fLGgjDNIxiKx3XcO6biFhsHNw749Bg"]//user.value(forKey:"token") as! String]
            
            AF.upload(multipartFormData: { multipartFormData in
                
                if let imagesDict = image_array {
                    
                    if let images_array = imagesDict[imagesArray_key ?? ""] {
                        
                        // For Images
                        for image in images_array {
                        
                            if let imgData = image.image.jpegData(compressionQuality: Enum_JPEGQuality.high.rawValue) {
                                multipartFormData.append(imgData, withName:imagesArray_key!,fileName: image.name, mimeType:mimeType?.rawValue)
                            }
                            
                            // For Videos
                            if let videoFilePath = image.videoURL {
                                multipartFormData.append(videoFilePath, withName: imagesArray_key!)
                            }
                        }
                    }
                }
                
                // For Parameters
                for (key, value) in parameters {
                    
                    if let tagsArray = value as? [String] {
                        
                        for i in 0..<tagsArray.count {
                            
                            let value = tagsArray[i] //as! Int
                            let valueObj = String(value)
                            
                            let keyObj = key + "[" + String(i) + "]"
                            multipartFormData.append(valueObj.description.data(using: .utf8)!, withName: keyObj)
                            //                            multipartFormData.append(valueObj.data(using: .utf8)!, withName: keyObj)
                            
                        }
                        
                    }else if let stringValue = value as? String {
                        
                        multipartFormData.append(stringValue.data(using: .utf8)!, withName: key)
                        
                    }
                    
                    //                            multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
                }
            },to: url, method: .post , headers: headers)
                .validate(statusCode: 200..<300)
                .responseJSON(completionHandler: { (responseObject) in
                    
                    SKActivityIndicator.dismiss()
                    
                    switch responseObject.result {
                    case .success:
                        success(responseObject)
                        break
                        
                    case let .failure(error):
                        failure("\(error)")
                    }
                })
        }
        
    }
    
    /**
        Usage:
        
        var params = ["user_id": user_Defaults.value(forKey: Enum_UserData.user_id.rawValue)!,
                      "first_name": self.TF_firstName.text!,
                      "last_name": self.TF_lastName.text!,
                      "date_of_birth": self.TF_dob.text!,
                      "gender": self.TF_gender.text!.lowercased(),
                      "email": self.TF_email.text!,
                      "mobile": self.TF_mobile.text!,
                      "address": self.TF_address.text!,
                      "device_type": "ios",
                      "device_token": Custom_UDID.get_UDID()]
        
        
        if let profileChageImage = self.profileImage {
            
            params.updateValue([Enum_mimeTypes.image.rawValue:[ImageNameWithURL(name: user_Defaults.value(forKey: Enum_UserData.first_name.rawValue)! as! String, image: profileChageImage, videoURL: nil, type: .jpg, key: "user_image")]], forKey: Enum_mimeTypes.image.rawValue)
        }
        
        */
    
    func POST_FormData1(apiStr: String, parameters: [String: Any]?, headers: HTTPHeaders?, success:@escaping (AFDataResponse<Any>?) -> Void, failure:@escaping (String) -> Void) {
        
        if Connectivity.isConnectedToInternet {
            
            //        Loader.shared.showLoder()
            CustomSKIndicator.shared.showSKIndicatorSpinner(statusMessage: "Loading...")
            
            guard let url = URL.init(string: BaseURL + apiStr) else { return }
            
            let parameters: [String:Any] = parameters ?? [:]
            
            //             let headers: HTTPHeaders = ["Authorization":"Bearer hm0UVOF7KSMgTQBHxrpj9MC6KnN3JVoN3KDXSDoZ_u1ji2v91Fd90H0VWzCw6iEgillmw7nDU5qjbs9bK40o9kdJ9AH8cwcG6mMkwentwNax8bMOPqYd90Io6KE_knHfX8a3vD6ucqhlVtnoIqEV445usB-GkpBjWGI_PQos4I-2KGycRGv4YhuRqIQVUDowj5hc0NT44uv4f4bPa-Tes4fcAF2fiS8xO8ovnCbUwAO3tlj449x5Qc3Bhc-x734uceCxEDh6_5OV0A8QkaDobPdSES9UgzcCFGdF6CB0ckjJupyljBsJxTobrtnMlfn3RU_KyktqJgIjJBSzSDMfpaozK1ZaPiIu9GNZvvecSsLQdy3DtARCoZCLR6ku8kmBizz_Qu51ryRyAB992D0JmZIPIxLfqngaUs7SG_gfGkM_QRYV-bfDtU2f6W2z0dJgdZjFgyODI0gU4DD4umJAF3I62y-GWpOKM5joq_XRaEqIElZCxqETfT9ay7T5eKfWCFp9_FcC7es11EMlVGEKZ7YFsFzg_9bq_lRRcWRCS1cDXGYOwYOCFzyxOPnPDLipK_JH94qHKF_KwiDwAJS5XgEBbbynMffooKofUMNK1zDTxskayFgkpvdbpdqkha70CEAk5YRkA0fo3fLGgjDNIxiKx3XcO6biFhsHNw749Bg"]//user.value(forKey:"token") as! String]
            
            AF.upload(multipartFormData: { multipartFormData in
                
                // For Parameters
                for (key, value) in parameters {
                    
                    // For Images
                    
                    if key == Enum_mimeTypes.image.rawValue {
                        // parameters[Enum_mimeTypes.image.rawValue]
                        if let images_array = value as? [String: [ImageNameWithURL]] {
                                                        
                            if let finaleImages_array = images_array[key] {
                                
                                for image in finaleImages_array {

                                    if let imgData = image.image.jpegData(compressionQuality: Enum_JPEGQuality.high.rawValue) {
                                        multipartFormData.append(imgData, withName:image.key,fileName: image.name, mimeType: image.type?.rawValue)
                                    }
                                }
                            }
                            
                        }
                    }else if key == Enum_mimeTypes.video.rawValue {
                        
                        // For Videos
                        if let videos_array = value as? [String: [ImageNameWithURL]] {
                                                        
                            if let FinalVideos_array = videos_array[key] {
                                
                                for video in FinalVideos_array {

                                    if let videoFilePath = video.videoURL {
                                        multipartFormData.append(videoFilePath, withName: video.key)
                                    }
                                }
                            }
                            
                        }
                        
                    }
                    
                    if let tagsArray = value as? [String] {
                        
                        for i in 0..<tagsArray.count {
                            
                            let value = tagsArray[i] //as! Int
                            let valueObj = String(value)
                            
                            let keyObj = key + "[" + String(i) + "]"
                            multipartFormData.append(valueObj.description.data(using: .utf8)!, withName: keyObj)
                            //                            multipartFormData.append(valueObj.data(using: .utf8)!, withName: keyObj)
                        }
                        
                    }else if let stringValue = value as? String {
                        
                        multipartFormData.append(stringValue.data(using: .utf8)!, withName: key)
                        
                    }
                    
                    //                            multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
                }
            },to: url, method: .post , headers: headers)
                .validate(statusCode: 200..<300)
                .responseJSON(completionHandler: { (responseObject) in
                    
                    SKActivityIndicator.dismiss()
                    
                    switch responseObject.result {
                    case .success:
                        success(responseObject)
                        break
                        
                    case let .failure(error):
                        failure("\(error)")
                    }
                })
        }
        
    }
    

    func POSTRequestWithX_www_form_urlEncoded(apiStr: String, params: [String: Any], success:@escaping (AFDataResponse<Any>?) -> Void, failure:@escaping (String) -> Void) {

            if Connectivity.isConnectedToInternet {

                CustomSKIndicator.shared.showSKIndicatorSpinner(statusMessage: "Loading...")
                
                let headers: HTTPHeaders = ["Content-Type": "application/x-www-form-urlencoded"]

                AF.request(BaseURL+apiStr, method: .post, parameters: params, encoding:  URLEncoding.httpBody, headers: headers).responseJSON { responseObject in

                    switch(responseObject.result) {

                    case.success:

                        SKActivityIndicator.dismiss()
                        success(responseObject)

                    case.failure(let error):

                        SKActivityIndicator.dismiss()
                        failure("\(error)")

                    }
                }

            }else {

                SKActivityIndicator.dismiss()
                failure("Please check your Internet Connection")
            }
        }

}


extension Dictionary where Value: Equatable {
    func key(forValue val: Value) -> Key? {
        return first(where: { $1 == val })?.key
    }
}

enum Enum_JPEGQuality: CGFloat {
    
    case lowest  = 0
    case low     = 0.25
    case medium  = 0.5
    case high    = 0.75
    case highest = 1
}
