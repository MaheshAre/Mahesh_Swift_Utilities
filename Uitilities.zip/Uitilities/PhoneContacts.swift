//
//  Conatcts+Extension.swift


import Foundation
import ContactsUI


struct PhoneContacts {
    
    static let shared = PhoneContacts()
    private init() { }
    
    func get_contacts(onCompletion: @escaping (_ contactsArray: [ContactStruct])->Void) {
        
        let contactStore = CNContactStore()
        var contacts = [ContactStruct]()
        let keys = [CNContactGivenNameKey,CNContactFamilyNameKey, CNContactPhoneNumbersKey] as [CNKeyDescriptor]
        
        //[CNContactFormatter.descriptorForRequiredKeys(for: .fullName)]
        let request = CNContactFetchRequest(keysToFetch: keys)
        
        do {
            try contactStore.enumerateContacts(with: request) {
                (contact, stop) in
                
                let name = contact.givenName
                let familyName = contact.familyName
                var mobileNumber = ""
                if let number = contact.phoneNumbers.first?.value.stringValue {
                    mobileNumber = number
                }
                
                contacts.append(ContactStruct(name: name, familyName: familyName, mobileNumber: mobileNumber))
            }
            
            onCompletion(contacts)

        }
        catch {
            print("unable to fetch contacts")
        }
    }
}

struct ContactStruct {
    
    let name: String
    let familyName: String
    let mobileNumber: String
}
