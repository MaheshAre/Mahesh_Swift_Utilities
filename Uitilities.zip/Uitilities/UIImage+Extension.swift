//
//  UIImage+Extension.swift


import Foundation
import UIKit

public enum ImageFormat {
    case PNG
    case JPEG(CGFloat)
}



extension UIImage {
    
    func defaultStoreImg() -> UIImage {
        return UIImage(named: "Group 613")!
    }
    
    func default_user() -> UIImage {
        return #imageLiteral(resourceName: "icon_defaultUser")
    }
    
    func no_image() -> UIImage {
        return UIImage(named: "no_image.png")!
    }
    
    func get_Base64WithCompression(value: CGFloat = 0.5) -> String {
        
        return (self.jpegData(compressionQuality: value)?.base64EncodedString())!
    }
    
}

extension UIImage {
    
    func fixOrientation() -> UIImage {
        if self.imageOrientation == UIImage.Orientation.up {
            return self
        }
        UIGraphicsBeginImageContextWithOptions(self.size, false, self.scale)
        self.draw(in: CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height))
        if let normalizedImage: UIImage = UIGraphicsGetImageFromCurrentImageContext() {
            UIGraphicsEndImageContext()
            return normalizedImage
        } else {
            return self
        }
    }
    
    /**
            let rotatedImage = image.rotate(radians: .pi)
     */
    
    func rotate(radians: CGFloat) -> UIImage {
        let rotatedSize = CGRect(origin: .zero, size: size)
            .applying(CGAffineTransform(rotationAngle: CGFloat(radians)))
            .integral.size
        UIGraphicsBeginImageContext(rotatedSize)
        if let context = UIGraphicsGetCurrentContext() {
            let origin = CGPoint(x: rotatedSize.width / 2.0,
                                 y: rotatedSize.height / 2.0)
            context.translateBy(x: origin.x, y: origin.y)
            context.rotate(by: radians)
            draw(in: CGRect(x: -origin.y, y: -origin.x,
                            width: size.width, height: size.height))
            let rotatedImage = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            
            return rotatedImage ?? self
        }
        
        return self
    }
    
    var localizedImage: UIImage {
        if selected_language == .ar {
            return self.rotate(radians: .pi)
        }else {
            return self
        }
        
    }
    
}

extension UIImage {

    /// Extracts image name from a description.
    /// * Example description: `<UIImage:0x60000278ce10 named(main: ic_timeline_milestone_bluedot) {16, 16}>`
    /// * Example name: `ic_timeline_milestone_bluedot`
    /// - warning: For the debug use only.
    var get_name: String? {
        let description = self.description
        guard let regexp = try? NSRegularExpression(pattern: "\\(main: (.*)\\)", options: []) else { return nil }
        let range = NSRange(description)!
        guard let match = regexp.matches(in: description, options: [], range: range).first else { return nil}
        guard match.numberOfRanges > 0 else { return nil }
        let idx1 = description.index(description.startIndex, offsetBy: range.lowerBound)
        let idx2 = description.index(description.startIndex, offsetBy: range.upperBound)
        return String(description[idx1..<idx2])
    }
}
