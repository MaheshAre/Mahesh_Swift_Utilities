
func findDistanceTime(pi_lat: String,pi_lon: String,dr_lat: String,dr_lon: String) {
    
   
    var urlStr : String = "\(Const.GOOGLE_MATRIX_URL)\(Const.Params.ORIGINS)=\(pi_lat),\(pi_lon)&\(Const.Params.DESTINATION)=\(dr_lat),\(dr_lon)&\(Const.Params.MODE)=driving&\(Const.Params.LANGUAGE)=en-EN&\(Const.Params.SENSOR)=false&key=\(Const.PLACES_AUTOCOMPLETE_API_KEY)"
    
    // https://maps.googleapis.com/maps/api/distancematrix/json?origins=18.6822824,78.1075388&destinations=18.7006313,78.0480644&mode=driving&language=en-EN&sensor=false&key=YOUR_KEY
    // https://maps.googleapis.com/maps/api/distancematrix/json?origins=18.6822824,78.1075388&destinations=18.7006313,78.0480644&mode=driving&language=en-EN&sensor=false&key=AIzaSyDzIzURgT9ejynj5GGvsSg-sUlwDAxGj0A
    
    urlStr = urlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
           
    API.googlePlaceAPICall(with: urlStr){ responseObject, error in

        if let error = error {
            self.hideLoader()
           
        }else {
           
            if responseObject == nil {
                
                return
            }
            if let resData = responseObject {
                let json = self.jsonParser.jsonParser(dicData: resData)
               
                if let dic = json["rows"].array, dic.count > 0 {
                    if let value = dic[0]["elements"].array {
                       
                        let distance_dict = value[0]["distance"].dictionary
                        if let dist : Int = distance_dict?["value"]?.int {
                            self.distance = Double(dist) * 0.001
                           
                        }
                        
                        let duration_dict = value[0]["duration"].dictionary
                        if let duration : Int = duration_dict?["value"]?.int {
                            self.totaltime = duration
                        }
                        
                        if let distance = self.distance, let time = self.totaltime {
                            
                            let dist = String(format:"%0.2f", distance)
                            let tot_time = String(format:"%d", time)
                            
                            self.providerServiceCompleted(distance:  dist, duration: tot_time);
                        }
                        
                    }
                }
            }
        }
    }
}
