//
//  MapsVC.swift

import UIKit
import GoogleMaps
import GooglePlacePicker

 protocol AddressDelegate {
    
    func getAddress(address: AddressStruct)
}

class MapsVC: UIViewController {
    
    var delegate: AddressDelegate?
    
    @IBOutlet weak var mapView: GMSMapView!
    @IBOutlet weak var lbl_address: UILabel!
    @IBOutlet weak var view_addressLabel: UIView!
    @IBOutlet weak var btn_submit: UIButton!
    
    @IBOutlet weak var TF_locationSearch: UITextField!
    
    var commingFrom = ""
    
    var addressStruct = AddressStruct()
    
    var locationManager = CLLocationManager()
    var marker = GMSMarker()
    
    //MARK:- ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.delegateSpecify()
        

        self.view_addressLabel.shadowApply(cornerRadiues: 8, shadowOpacityes: 1, shadowColors: UIColor.darkGray, shadowOffset: CGSize.zero)
        self.btn_submit.cornerRadius(radius: 8, bwidth: nil, bColor: nil)
        
        self.TF_locationSearch.cornerRadiusHeightByTwo(bwidth: 0, bColor: nil)
    }
    
    //MARK:- Buttons Actions
    
    @IBAction func btn_backAction(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
    @IBAction func btn_googleAutoPlacePickerAction(_ sender: Any) {
        
        let acController = GMSAutocompleteViewController()
        acController.delegate = self
        self.navigationController?.present(acController, animated: false, completion: nil)
        //        present(acController, animated: true, completion: nil)
    }
    @IBAction func btn_submitAction(_ sender: Any) {
        
        let india_country = "india"
        
        let countryResult = india_country.compare(self.addressStruct.country, options: .caseInsensitive, range: nil, locale: nil)
        if countryResult != .orderedSame {
            self.showToastSwift(msg: "Please select in India Only")
            return
        }
        
        if self.commingFrom == "selectLocation" {
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ManualLocationVC") as! ManualLocationVC
            vc.addressStuct = self.addressStruct
            self.navigationController?.pushViewController(vc, animated: false)
            
        }else if commingFrom == "pickUpAddress" {
            
            self.delegate?.getAddress(address: self.addressStruct)
            
            /*
            let viewcontrollers = self.navigationController?.viewControllers
            
            viewcontrollers?.forEach({ (vc) in
                if let addPickAddress = vc as? AddPickAddressVC {
                    
                    self.delegate?.getAddress(address: self.addressStruct)
//                    addPickAddress.addressStruct = self.addressStruct
//                    self.delegate?.getAddress(address: self.addressStruct)
                    self.navigationController!.popToViewController(addPickAddress, animated: true)
                }
            })
            
            */
            
            
        }
        
    }
}

extension MapsVC: CLLocationManagerDelegate {
    
    func delegateSpecify() {
        
        //        var locationManager = CLLocationManager()
        //        var marker = GMSMarker()
        
        self.locationManager.delegate = self
        self.mapView.delegate = self
        self.locationManager.startUpdatingLocation()
        locationManager.requestWhenInUseAuthorization()
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        // 3
        guard status == .authorizedWhenInUse else {
            return
        }
        // 4
        locationManager.startUpdatingLocation()
    }
    
    // 6
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first else {
            return
        }
        
        // 7
        mapView.camera = GMSCameraPosition(target: location.coordinate, zoom: 15, bearing: 0, viewingAngle: 0)
        
        self.getAddress(coordinates: location.coordinate)
        //        self.getAdressName(coords: locationManager)
        
        mapView.isMyLocationEnabled = true
        mapView.settings.myLocationButton = true
        mapView.padding = UIEdgeInsets(top: 0, left: 0, bottom: 130, right: 20)
        
        // 8
        locationManager.stopUpdatingLocation()
    }
    
    
    func getAddress(coordinates: CLLocationCoordinate2D) {
        
        let geoCoder = CLGeocoder()
        let location = CLLocation(latitude: coordinates.latitude, longitude: coordinates.longitude)
        //selectedLat and selectedLon are double values set by the app in a previous process
        
        geoCoder.reverseGeocodeLocation(location, completionHandler: { (placemarks, error) -> Void in
            if error != nil {
                print("Hay un error")
            } else {
                
                /// Place details
                var place: CLPlacemark!
                place = placemarks?.last
                
                 /*
                 print(place)
                 print(place.thoroughfare!)
                 print(place.subLocality!)
                 print(place.locality!)
                 print(place.addressDictionary!)
                 print(place.location!)
                 print(place.subLocality!)
                 print(place.description)
                 print(place.administrativeArea!)
                 print(place.addressDictionary!["FormattedAddressLines"]!)
                 */
                
                var addressString : String = ""
                
                if place.subThoroughfare != nil {
                    addressString = addressString + place.subThoroughfare! + ", "
//                    print("Sub-Through -> \(String(describing: place.subThoroughfare))")
                    self.addressStruct.flat =  place.subThoroughfare!
                }
                
                if place.subLocality != nil {
                    addressString = addressString + place.subLocality! + ", "
//                    print("Sub_Loc -> \(String(describing: place.subLocality))")
                    self.addressStruct.colony =  place.subLocality!
                    self.marker.title = self.addressStruct.colony
                }
                if place.thoroughfare != nil {
                    addressString = addressString + place.thoroughfare! + ", "
//                    print("Through -> \(String(describing: place.thoroughfare))")
                    self.addressStruct.landmark =  place.thoroughfare!
                    self.marker.title = self.addressStruct.landmark
                }
                
                if place.locality != nil {
                    addressString = addressString + place.locality! + ", "
//                    print("locality -> \(String(describing: place.locality))")
                    self.addressStruct.city =  place.locality!
                }
                
                if place.administrativeArea != nil {
                    addressString = addressString + place.administrativeArea! + ", "
//                    print("AdministrativeArea -> \(String(describing: place.administrativeArea))")
                    self.addressStruct.state = place.administrativeArea!
                }
               
                if place.country != nil {
                    addressString = addressString + place.country! + ", "
//                    print("country -> \(String(describing: place.country))")
                    self.addressStruct.country = place.country!
                }
                if place.postalCode != nil {
                    addressString = addressString + place.postalCode! + " "
//                    print("postalCode -> \(String(describing: place.postalCode))")
                    self.addressStruct.pincode = place.postalCode!
                }
                
                self.addressStruct.lat = coordinates.latitude
                self.addressStruct.long = coordinates.longitude
               
                print("Struct --> \(self.addressStruct)")
                
                
                self.marker.position = CLLocationCoordinate2DMake(coordinates.latitude, coordinates.longitude)
                self.marker.icon = UIImage(named: "icon_pin_color")//GMSMarker.markerImage(with: UIColor.green)
                self.marker.appearAnimation = GMSMarkerAnimation.pop
                self.marker.map = self.mapView
                
                self.lbl_address.text = addressString
                self.addressStruct.completeAddress = addressString
            }
            
        })
        
    }
    
}

extension MapsVC: GMSMapViewDelegate {
    
    func mapView(_ mapView: GMSMapView, didLongPressAt coordinate: CLLocationCoordinate2D) {
        
        let marker = GMSMarker(position: coordinate)
        marker.title = "Hello World"
        marker.map = mapView
    }
    
    func mapView(_ mapView: GMSMapView, didTapAt coordinate: CLLocationCoordinate2D) {
                
        GetCurrentLocation.shared.getAddress(coordinates: coordinate) { (address_struct, isSuccess) in
            
            self.mapView.clear()
            if isSuccess {
                
                let marker = GMSMarker(position: coordinate)
                marker.title = address_struct?.completeAddress
                marker.map = mapView
                marker.icon = #imageLiteral(resourceName: "symbole")
                
                from_address_struct = address_struct!
                self.tf_from.text = address_struct!.completeAddress
                //                    from_lat = address_struct!.lat
                //                    from_long = address_struct!.long
            }
            
        }
    }
    
}

extension MapsVC: GMSAutocompleteViewControllerDelegate {
    
    func viewController(_ viewController: GMSAutocompleteViewController, didAutocompleteWith place: GMSPlace) {
        // Get the place name from 'GMSAutocompleteViewController'

        //        self.selectedPlace = place
//        self.TF_locationSearch.text = place.formattedAddress
                self.lbl_address.text = place.formattedAddress
        
        self.getAddress(coordinates: place.coordinate)
        
        
        let camera = GMSCameraPosition(target: place.coordinate, zoom: 15, bearing: 0, viewingAngle: 0)
        self.mapView.camera = camera
        
        self.navigationController?.dismiss(animated: false, completion: nil)
        //        dismiss(animated: true, completion: nil)
        /*
         self.locationDelegate?.displaySelectedLocation(location: addressName)
         */
        
    }
    func viewController(_ viewController: GMSAutocompleteViewController, didFailAutocompleteWithError error: Error) {
        // Handle the error
        print("Error: ", error.localizedDescription)
    }
    func wasCancelled(_ viewController: GMSAutocompleteViewController) {
        // Dismiss when the user canceled the action
        dismiss(animated: true, completion: nil)
    }
    
}


struct AddressStruct {

    var flat = ""
    var landmark = ""
    var colony = ""
    var city = ""
    var state = ""
    var pincode = ""
    var country = ""
    var lat = 0.0
    var long = 0.0
    var completeAddress = ""
    
    var formattedAddress = ""
    
}


// Generic Type
//func getAddress<T: AddressStruct>(address: T)
