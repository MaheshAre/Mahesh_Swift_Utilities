//
//  SelectVehicleAndTimeVC.swift


import UIKit
import GoogleMaps
import GooglePlaces

let google_apiKey = "AIzaSyDnZrTUOlgqLttgeBSOy0nShYL3Q6_4wv4"

class GoogleMapsWithRoute: UIViewController,UITextFieldDelegate {
        
    @IBOutlet weak var gmapView: GMSMapView!
    
    
    var marker = GMSMarker()
    
    //MARK:- ViewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.service_get_serviceTypes()
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.navigationBar.isHidden = true
        
        self.getGoogleMap()
        
        GoogleMapsWithRoute.shared.get_polyLine_GMSMapView(from: CLLocationCoordinate2D(latitude: from_address_struct.lat, longitude: from_address_struct.long), to: CLLocationCoordinate2D(latitude: to_address_struct.lat, longitude: to_address_struct.long), gmap: self.gmapView)
    }
    
    func getGoogleMap() {
            
            self.gmapView.mapType = .normal
            
            let camera = GMSCameraPosition.camera(withLatitude: lat, longitude: long, zoom: 16)
            self.gmapView.camera = camera
            
            let pickMarker = DisplayMarker(lat: from_address_struct.lat, long: from_address_struct.long, display_icon: #imageLiteral(resourceName: "symbole"))
            pickMarker.map = self.gmapView
            let destMarker = DisplayMarker(lat: to_address_struct.lat, long: to_address_struct.long, display_icon: #imageLiteral(resourceName: "greenLoc"))
            destMarker.map = self.gmapView
            
            /*
         
         self.gmapView.settings.myLocationButton = true
         self.gmapView.settings.compassButton = true
         self.gmapView.padding = UIEdgeInsets(top: 0, left: 0, bottom: 200, right: 20)
         
         
            view.sendSubviewToBack(self.gmapView)
            let camera = GMSCameraPosition.camera(withLatitude: lat, longitude: long, zoom: 16) // 16
            //        print("\(lat)---\(long)")
            self.gmapView.camera = camera
            self.gmapView.settings.myLocationButton = true
            let zoomCamera = GMSCameraUpdate.zoomIn()
            self.gmapView.animate(with: zoomCamera)
            self.gmapView.mapType = GMSMapViewType.normal
            self.gmapView.isIndoorEnabled = true
            self.gmapView.isMyLocationEnabled = true
            marker.position = CLLocationCoordinate2DMake(lat, long)
            //marker.icon = UIImage(named: "marker")
            marker.map = self.gmapView
    //        self.gmapView.delegate = self
            
            */
        }
    
}

class GoogleMapsWithRoute: UIViewController {
    
    static let shared = GoogleMapsWithRoute()
    
    func get_polyLine_GMSMapView(from source: CLLocationCoordinate2D, to destination: CLLocationCoordinate2D, gmap: GMSMapView) {

        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)

        let url = URL(string: "https://maps.googleapis.com/maps/api/directions/json?origin=\(source.latitude),\(source.longitude)&destination=\(destination.latitude),\(destination.longitude)&sensor=true&mode=driving&key=\(google_apiKey)")!

        let task = session.dataTask(with: url, completionHandler: {
            (data, response, error) in
            
            if error != nil {
                print(error!.localizedDescription)
                
            }else {
                do {
                    if let json : [String:Any] = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]{

                        guard let routes = json["routes"] as? NSArray else {
                            
                            return
                        }

                        if (routes.count > 0) {
                            let overview_polyline = routes[0] as? NSDictionary
                            let dictPolyline = overview_polyline?["overview_polyline"] as? NSDictionary

                            let points = dictPolyline?.object(forKey: "points") as? String
                            
                            self.showPath_GMSMapView(polyStr: points!, gmap: gmap)

                            DispatchQueue.main.async {

                                let bounds = GMSCoordinateBounds(coordinate: source, coordinate: destination)
                                let update = GMSCameraUpdate.fit(bounds, with: UIEdgeInsets(top: 170, left: 30, bottom: 30, right: 30))
                                gmap.moveCamera(update)
                            }
                        }
                    }
                }catch {
                    print("error in JSONSerialization")
                }
            }
        })
        task.resume()
    }
    
    func showPath_GMSMapView(polyStr :String, gmap: GMSMapView) {
        
        let path = GMSPath(fromEncodedPath: polyStr)
        let polyline = GMSPolyline(path: path)
        polyline.strokeWidth = 3.0
        polyline.strokeColor = .black
        polyline.map = gmap // Your map view
    }
    
}

class DisplayMarker: GMSMarker {
    
    override init() {
        super.init()
    }
    
    init(lat: Double, long: Double, display_icon: UIImage?) {
        
        super.init()
        
        self.isTappable = true
        position = CLLocationCoordinate2DMake(lat,long)
        groundAnchor = CGPoint(x: 0.5, y: 1)
        appearAnimation = GMSMarkerAnimation.none
        icon = display_icon
        
        GetCurrentLocation.shared.getAddress(coordinates: CLLocationCoordinate2D(latitude: lat, longitude: long)) { (address_struct, isSuccess) in
            
            if isSuccess {
                self.title = address_struct?.completeAddress
            }
            
        }
        
//        icon = UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "GreenTrack")!, to: CGSize.init(width: 34, height: 64))
    }
}

extension HomeVC: GMSMapViewDelegate {
    
//    func mapView(_ mapView: GMSMapView, didLongPressAt coordinate: CLLocationCoordinate2D) {
//
//        let marker = GMSMarker(position: coordinate)
//        marker.title = "Hello World"
//        marker.map = mapView
//    }
    
    func mapView(_ mapView: GMSMapView, didTapAt coordinate: CLLocationCoordinate2D) {
        
        self.gmap.clear()
                
        GetCurrentLocation.shared.getAddress(coordinates: coordinate) { (address_struct, isSuccess) in
            
            if isSuccess {
//                print(address_struct!)
                let marker = GMSMarker(position: coordinate)
                marker.title = address_struct?.completeAddress
                marker.map = mapView
                marker.icon = #imageLiteral(resourceName: "symbole")
                
                from_address_struct = address_struct!
                self.tf_from.text = address_struct!.completeAddress
                //                    from_lat = address_struct!.lat
                //                    from_long = address_struct!.long
            }
            
        }
    }
    
}
