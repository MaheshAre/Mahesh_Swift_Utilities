//
//  OnBoardingVC.swift
//

import UIKit
import Kingfisher

class OnBoardingVC: UIViewController {
    
    @IBOutlet weak var bannerCollection: UICollectionView!
    @IBOutlet weak var nextBtn: UIButton!
    @IBOutlet weak var pageControl: UIPageControl!
    
    var indexCell: Int = 0
    
//    var arrTittle = ["Make Your Profile","Find Your Partner","Spread Your Love"]
//    var imagesArr = [UIImage(named: "Mask Group 3"),UIImage(named: "Mask Group 4"),UIImage(named: "Mask Group 5")]
    
    var boarding_array = [OnboardResp]()
    
    //MARK:- ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.service_getOnboards()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.isNavigationBarHidden = true
    }

    override func viewWillDisappear(_ animated: Bool) {
        
        self.navigationController?.isNavigationBarHidden = false
        
    }
    
    //MARK:- Buttons Actions
    
    @IBAction func nextBtnTap(sender: UIButton){
        
        let indexOfScrolledCell : NSInteger!
        
        indexOfScrolledCell = indexCell
        
        if sender.currentTitle == "START"{
            
            let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            self.navigationController?.pushViewController(vc, animated: true)
            
        }else{
            if indexCell < 3 {
                let path = IndexPath(row: indexOfScrolledCell + 1, section: 0)
                bannerCollection.scrollToItem(at: path, at: .right, animated: true)
                pageControl.currentPage = path.row
                
            }
        }
        
    }
    
    @IBAction func skipBtnTap(sender: UIButton){
        
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    //MARK:- Functions
    
    func service_getOnboards() {
        
        API_Handler.shared.requestGETURL(api_onboarding, params: nil, headers: nil, success: { (response) in
            
            do {
                let jsonData = try JSONDecoder().decode(Model_Onboard.self, from: (response?.data)!)
                if jsonData.status == 1 {
                    self.boarding_array = jsonData.boardings!
                    self.pageControl.numberOfPages = self.boarding_array.count
                    self.bannerCollection.reloadData()
                }
            }catch {
                print(error)
            }
            
        }) { (msg) in
            self.showToastSwift(msg: msg)
        }
    }
    
}
//MARK:- COLLECTIONVIEW DELEGATES & DATA SOURCE METHODS
extension OnBoardingVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.boarding_array.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.bannerCollection.dequeueReusableCell(withReuseIdentifier: "OnBoardCollectionViewCell", for: indexPath) as! OnBoardCollectionViewCell
        
        let data = self.boarding_array[indexPath.row]
        
        if let image = data.image {
            cell.onboardImageView.kf.indicatorType = .activity
            cell.onboardImageView.kf.setImage(with: URL(string: Base_ImageURL+image))
        }
        cell.Title_lbl.text = data.title
        cell.description_lbl.text = data.description
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: bannerCollection.frame.size.width, height: bannerCollection.frame.size.height)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        
        let sectionInset = UIEdgeInsets(top: -44, left: 0, bottom: 0, right: 0)
        return sectionInset
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
           let pageWidth = scrollView.frame.size.width
           let page = Int(floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1)
           self.pageControl.currentPage = page
       }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
           let pageWidth: CGFloat = scrollView.frame.size.width
           let fractionalPage = Float(scrollView.contentOffset.x / pageWidth)
           let page: Int = lround(Double(fractionalPage))
          pageControl.currentPage = page
           
        if page == self.boarding_array.count - 1{
               self.nextBtn.setTitle( "START", for: .normal)
    
           }else{
               self.nextBtn.setTitle( "NEXT", for: .normal)
    
           }
       }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
           
           indexCell = indexPath.index(after: indexPath.item - 1)
       }
}
