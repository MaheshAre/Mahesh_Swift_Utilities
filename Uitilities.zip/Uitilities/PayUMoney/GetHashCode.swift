//
//  GetHashCode.swift


import Foundation
import UIKit

import PlugNPlay
import CommonCrypto

struct GetHashCode {
    
    static let shared = GetHashCode()
    private init() { }
    
    func getHashForPaymentParams(_ txnParam: PUMTxnParam?, _ sa: String?) -> String? {
        let salt = sa
        var hashSequence: String? = nil
        if let key = txnParam?.key, let txnID = txnParam?.txnID, let amount = txnParam?.amount, let productInfo = txnParam?.productInfo, let firstname = txnParam?.firstname, let email = txnParam?.email, let udf1 = txnParam?.udf1, let udf2 = txnParam?.udf2, let udf3 = txnParam?.udf3, let udf4 = txnParam?.udf4, let udf5 = txnParam?.udf5, let udf6 = txnParam?.udf6, let udf7 = txnParam?.udf7, let udf8 = txnParam?.udf8, let udf9 = txnParam?.udf9, let udf10 = txnParam?.udf10 {
            hashSequence = "\(key)|\(txnID)|\(amount)|\(productInfo)|\(firstname)|\(email)|\(udf1)|\(udf2)|\(udf3)|\(udf4)|\(udf5)|\(udf6)|\(udf7)|\(udf8)|\(udf9)|\(udf10)|\(salt ?? "")"
        }
        
        let data = hashSequence?.sha512()
        
        return data
    }
}


extension String {
    
    func sha512() -> String {
        let data = self.data(using: .utf8)!
        var digest = [UInt8](repeating: 0, count: Int(CC_SHA512_DIGEST_LENGTH))
        data.withUnsafeBytes({
            _ = CC_SHA512($0, CC_LONG(data.count), &digest)
        })
        return digest.map({ String(format: "%02hhx", $0) }).joined(separator: "")
    }
    
}

/** PayU Money setup
 
 call setUp_PayU functions in your class
 
 import PayUMoneyCoreSDK
 import PlugNPlay
 
 */

/*
 
 var payUResp = PayUResponse()

func setUp_PayU() {
    
    let txnParam = PUMTxnParam()
    
    //PUMTxnParam *txnParam= [[PUMTxnParam alloc] init];
    //Set the parameters
    
    let kMerchantSalt = "xT0BB7K95v"
    let kMerchantKey = "DMAlGYM5"
    let kMerchantID = "6709950"
    
    txnParam.phone = user_Defaults.value(forKey: Enum_UserData.mobile.rawValue)! as? String;
    txnParam.email = user_Defaults.value(forKey: Enum_UserData.email_id.rawValue)! as? String//"mahesh.g@iprismtech.com";
    
    txnParam.amount = "01" //self.amount
    txnParam.environment = .test
    
    txnParam.firstname = user_Defaults.value(forKey: Enum_UserData.name.rawValue)! as? String
    txnParam.key = "\(kMerchantKey)"
    txnParam.merchantid = "\(kMerchantID)"
    
    txnParam.txnID = "123"
    txnParam.surl = "https://www.payumoney.com/mobileapp/payumoney/success.php";
    txnParam.furl = "https://www.payumoney.com/mobileapp/payumoney/failure.php";
    txnParam.productInfo = appTitle;
    txnParam.udf1 = "";
    txnParam.udf2 = "";
    txnParam.udf3 = "";
    txnParam.udf4 = "";
    txnParam.udf5 = "";
    txnParam.udf6 = "";
    txnParam.udf7 = "";
    txnParam.udf8 = "";
    txnParam.udf9 = "";
    txnParam.udf10 = "";
    let hash = GetHashCode.shared.getHashForPaymentParams(txnParam, kMerchantSalt)
    //        print(hash!)
    txnParam.hashValue = hash
    print("hash from txn \(txnParam.hashValue!)")
    
    
    PlugNPlay.presentPaymentViewController(withTxnParams: txnParam, on: self) { (response, error, data) in
        
        if response != nil {
            
            let resp = response?["result"]
            self.payUResp = PayUResponse(resp as! [String : Any])
            
            self.showToastSwift(msg: self.payUResp.status)
            
            if self.payUResp.status == "success" {
                
                // Update Payment Service Call
                self.service_updatePayment()
            }else {
                
            }
            
        }
        if error != nil {
            let errorStr = "\(String(describing: error))".components(separatedBy: "\"")
            print(errorStr)
            self.showToastSwift(msg: errorStr[1])
            
            print(error as Any)
        }
    }
}

 
 struct PayUResponse {
     
     var status = String()
     var amount = ""
     var paymentId = 0
     var dateOfPay = ""
     
     init() {
     }
     
     init(_ dict: [String: Any]) {
         
         self.status = dict["status"] as! String
         self.amount = dict["amount"] as! String
         self.paymentId = dict["paymentId"] as! Int
         self.dateOfPay = dict["addedon"] as! String
     }
     
 }
*/
