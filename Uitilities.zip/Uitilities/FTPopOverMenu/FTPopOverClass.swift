
//
//  FTPopOverClass.swift


import Foundation
import UIKit


struct FTPopOverClass {
    
    static var shared = FTPopOverClass()
    private init() { }
    
    func showPopOver(_ sender: UIView, width: CGFloat, dataArray: [String], imagesArray: [String]?, onSelected: @escaping(Int) -> Void) {
        
        let config = FTConfiguration.shared
        config.backgoundTintColor = UIColor(white: 0.97, alpha: 1)
        config.menuWidth = width //sender.frame.width
        
        let cellConfi = FTCellConfiguration()
        cellConfi.textColor = UIColor.black
        cellConfi.textAlignment = .left
        
        cellConfi.textFont = UIFont.systemFont(ofSize: 14)
        let cellConfis = Array(repeating: cellConfi, count: dataArray.count)
        
        FTPopOverMenu.showForSender(sender: sender, with: dataArray, menuImageArray: imagesArray, cellConfigurationArray: cellConfis, done: { (selectedIndex) in
//            print(selectedIndex)
            
            onSelected(selectedIndex)
            
            onSelected(selectedIndex)
        }) {
            print("cancel")
        }
    }
    
    
}
