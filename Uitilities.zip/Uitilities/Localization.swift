
/*
 
 1. Create String file "Localizable"
 2. Goto Project setting info Localization add language select only Localizable string file only deselect StoryBoard and Launch storyboard
 
 3. AppDelegate:
    
    import LanguageManager_iOS
 
    LanguageManager.shared.defaultLanguage = .en
    LanguageManager.shared.setLanguage(language: .en)
 
 4. Language Selection Controller:
    
    import LanguageManager_iOS
    
    @IBAction func btn_engAction(_ sender: Any) {
     
        LanguageManager.shared.setLanguage(language: .en, for: nil, viewControllerFactory: { (title) -> UIViewController in
 
 selected_language = .ar
 user_Defaults.set(selected_language.rawValue, forKey: Enum_UserData.language.rawValue)
 
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            return storyboard.instantiateInitialViewController()!
        }, animation: nil)
        
    }
    
    @IBAction func btn_arabicAction(_ sender: Any) {
        
        LanguageManager.shared.setLanguage(language: .ar, for: nil, viewControllerFactory: { (title) -> UIViewController in
 
 selected_language = .ar
 user_Defaults.set(selected_language.rawValue, forKey: Enum_UserData.language.rawValue)
 
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            return storyboard.instantiateInitialViewController()!
        }, animation: nil)
    }
 
 5. Display: self.lbl_welcome.text = "Welcome".localiz()
 
 6. var selected_language: Languages = .en // take Globally or save userdefaults
 7. for SWReveal side menu take one copy and change storyboard ID same class name, segue identyfier is sw_right
    rightrevealviewcontroller and revealviewcontroller to get menus
*/
// AppDelegate
