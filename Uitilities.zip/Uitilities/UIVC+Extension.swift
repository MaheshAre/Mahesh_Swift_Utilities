//
//  UIViewController+Extension.swift


import Foundation
import UIKit
import UserNotifications

//MARK:-  UIViewController

extension UIViewController {
    
    func badge_tabBarItem(itemIndex: Int, badgeValue: String) {
        DispatchQueue.main.async {
            if let tabItems = self.tabBarController?.tabBar.items {
                tabItems[itemIndex].badgeValue = "\(badgeValue)"
            }
        }
    }
    
    func hideNavigationBar(isHide: Bool) {
        self.navigationController?.navigationBar.isHidden = isHide
    }
    
    func check_LoggedInOrNot(message msg: String, oneAction: Bool) -> Bool {
        
        if user_Defaults.value(forKey: Enum_UserDetails.id.rawValue) == nil {
            
            DispatchQueue.global(qos: .userInteractive).async {
                
                let alertCtrl = UIAlertController(title: appTitle, message: msg, preferredStyle: .alert)
                let action_cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
                let action_ok = UIAlertAction(title: "Ok", style: .default) { (okAction) in
                    
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                
                if oneAction == false {
                    alertCtrl.addAction(action_cancel)
                }
                
                alertCtrl.addAction(action_ok)
                self.present(alertCtrl, animated: true, completion: nil)
            }
            
            return false
            
        }else {
            return true
        }
    }
    
}


extension UIViewController {
    
    func stopEditing() {
        self.view.endEditing(true)
    }
    
    func showToastSwift(msg: String)  {
        self.view.makeToast(msg)
    }
    
    func alertController(title: String = "", message: String = "", okBtnTitle: String = "Ok", cancelBtnTitle: String = "Cancel", okCompletion: (()->())?, cancelCompletion: (()->())?) {
        
        DispatchQueue.main.async {
            
            let alertCtrl = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            
            let action_ok = UIAlertAction(title: okBtnTitle, style: .default) { (okAction) in
                okCompletion?()
            }
            
            let action_cancel = UIAlertAction(title: cancelBtnTitle, style: .cancel) { (cancelAction) in
                cancelCompletion?()
            }
            
            if cancelBtnTitle != "" {
                alertCtrl.addAction(action_cancel)
            }
            alertCtrl.addAction(action_ok)
            self.present(alertCtrl, animated: true, completion: nil)
        }
    }
    
    func addChildVC(_ child: UIViewController) {
        addChild(child)
        view.addSubview(child.view)
        child.didMove(toParent: self)
    }
    
    func embed(_ viewController:UIViewController){
        
        viewController.willMove(toParent: self)
        viewController.view.frame = self.view.bounds
        self.view.addSubview(viewController.view)
        self.addChild(viewController)
        viewController.didMove(toParent: self)
        viewController.view.alpha = 0
        UIView.animate(withDuration: 0.5) {
            viewController.view.alpha = 1.0
        }
    }
    
    /// It removes the child view controller from the parent.
    func removeChildVC() {
        guard parent != nil else {
            return
        }
        
        self.willMove(toParent: nil)
        self.removeFromParent()
        self.view.removeFromSuperview()
        
    }
    
    
    func setUpNoDataFound(msg: String?, canShow: Bool) -> UILabel {
        
        let lbl_msg = UILabel()
        
        lbl_msg.frame = CGRect(x: 15, y: (self.view.frame.height/2)-100, width: self.view.frame.width - 30, height: 200)
        lbl_msg.text = msg ?? "No Data Found"
        lbl_msg.textAlignment = .center
        lbl_msg.font = UIFont(name: "Segoe UI", size: 17.0)
        if canShow {
            self.view.addSubview(lbl_msg)
        }else {
            lbl_msg.removeFromSuperview()
            lbl_msg.text = ""
            /*
             DispatchQueue.main.async {
             lbl_msg.removeFromSuperview()
             lbl_msg.isHidden = true
             }
             */
            
        }
        
        return lbl_msg
        
    }
    
    /**
     Disable swipe backe gesture for UIViewController
     */
    func disableSwipeBack_vc() {
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
    }
    
    func get_appVersion() -> String {
        
        guard let info = Bundle.main.infoDictionary,
            let currentVersion = info["CFBundleShortVersionString"] as? String,
            let identifier = info["CFBundleIdentifier"] as? String else {
                return ""
        }
        
        return currentVersion
    }
    
    func get_bundleID() -> String {
        return Bundle.main.bundleIdentifier!
    }
    
    func clear_pushNotifications() {
        
        let center = UNUserNotificationCenter.current()
        center.removeAllDeliveredNotifications() // To remove all delivered notifications
        center.removeAllPendingNotificationRequests() // To remove all pending notifications which are not delivered yet but scheduled.
    }
    
    
    //MARK:- Update Constraints
    func update_constraints() {
        
        self.view.setNeedsUpdateConstraints()
        self.view.setNeedsLayout()
        self.view.layoutIfNeeded()
    }
}

//MARK:- UINavigation Controller

extension UINavigationController {
    /**
     Disable swipe backe gesture for NavigationController
     Call this Function in ViewDidAppear()
    */
    func disableSwipeBack() {
        self.interactivePopGestureRecognizer?.isEnabled = false
    }
}

//MARK:- UINavigationBar
extension UINavigationBar {
    
    func setUp_navigationBar(bgColor: UIColor? = UIColor().color_orange(),
                             itemColor: UIColor? = .white,
                             titleColor: UIColor? = .white) {
        
        self.tintColor = itemColor // Items color
        self.barTintColor = bgColor // BackGround Color
        // default bg Color UIColor(red: 0.969, green: 0.969, blue: 0.969, alpha: 1.0)
        self.titleTextAttributes = [.foregroundColor: titleColor!] // Title Color
        self.isTranslucent = false
        
        //        self.topItem?.leftBarButtonItem?.tintColor = UIColor.white
    }
}

//MARK:- Notifications Permission Alert
extension UIViewController {
    
    func show_NotificationsPermissionAlert() {
        
        let alert = UIAlertController(title: "WARNING", message: "Please enable access to Notifications in the Settings app.", preferredStyle: .alert)
        let settingsAction = UIAlertAction(title: "Settings", style: .default) {[weak self] (alertAction) in
            
            self?.gotoAppSettings()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        alert.addAction(settingsAction)
        alert.addAction(cancelAction)
        DispatchQueue.main.async {
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func gotoAppSettings() {
        guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
            return
        }
        
        OpenApps.shared.openLink(linkStr: "\(settingsUrl)")
    }
}

//MARK:- Check Update

var latest_version = ""

extension AppDelegate {
    
    func isUpdateAvailable() throws -> Bool {
        
        guard let info = Bundle.main.infoDictionary,
            let currentVersion = info["CFBundleShortVersionString"] as? String,
            let identifier = info["CFBundleIdentifier"] as? String,
            let url = URL(string: "http://itunes.apple.com/lookup?bundleId=\(identifier)") else {
                throw VersionError.invalidBundleInfo
        }
        
        let data = try Data(contentsOf: url)

        guard let json = try JSONSerialization.jsonObject(with: data, options: [.allowFragments]) as? [String: Any] else {
            throw VersionError.invalidResponse
        }
        if let result = (json["results"] as? [Any])?.first as? [String: Any], let version = result["version"] as? String {
            latest_version = version
            print("Xcode version", currentVersion);
            print("Apptore Version -> ", version)
            return version != currentVersion
        }
        throw VersionError.invalidResponse
    }
    
    
    enum VersionError: Error {
        case invalidResponse, invalidBundleInfo
    }
    
}

extension UIViewController {
    
    func force_update() {
        
        DispatchQueue.main.async {
            
            do {
             let update = try AppDelegate.getDelegate().isUpdateAvailable()
                
                DispatchQueue.main.async {
                    if update{
                        self.update_alert()
                    }
                    
                }
            } catch {
                print(error)
            }
        }
               
    }
    
    func update_alert(){
        
        let alertMessage = "A new version of \(appTitle) Application is available,Please update to \(latest_version) version ";
        let alert = UIAlertController(title: "New Version Available", message: alertMessage, preferredStyle: UIAlertController.Style.alert)
        
        let okBtn = UIAlertAction(title: "Update", style: .default, handler: {(_ action: UIAlertAction) -> Void in
            
            let appStore_Link = "https://apps.apple.com/app/id1517776431" // Apple ID from Appstore Connect
            // "http://appstore.com/MouKai"
            OpenApps.shared.openLink(linkStr: appStore_Link)
            
        })
        let noBtn = UIAlertAction(title:"Skip this Version" , style: .destructive, handler: {(_ action: UIAlertAction) -> Void in
        })
        alert.addAction(okBtn)
        alert.addAction(noBtn)
        self.present(alert, animated: true, completion: nil)
        
    }
}

struct Custom_UserDefaults {
    
    static let shared = Custom_UserDefaults()
    private init() { }
    
    func removeAllTheDataInDefauls() {
        
        let domain = Bundle.main.bundleIdentifier!
        UserDefaults.standard.removePersistentDomain(forName: domain)
        UserDefaults.standard.synchronize()
        print(Array(UserDefaults.standard.dictionaryRepresentation().keys).count)
    }
}

//MARK:- Get TOP VViewController

extension UIApplication {

    class func getTopViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {

        if let nav = base as? UINavigationController {
            return getTopViewController(base: nav.visibleViewController)

        } else if let tab = base as? UITabBarController, let selected = tab.selectedViewController {
            return getTopViewController(base: selected)

        } else if let presented = base?.presentedViewController {
            return getTopViewController(base: presented)
        }
        return base
    }
}
