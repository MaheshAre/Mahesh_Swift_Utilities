//
//  CustomRating.swift


import Foundation

import Cosmos

struct CustomRating {
    
    static let shared = CustomRating()
    private init() { }
    
    func ratingDisplay(view: CosmosView, rating: String, updateEnable: Bool) -> CosmosView {
        
        view.rating = Double(rating)!
        view.settings.fillMode = .precise
        view.settings.updateOnTouch = updateEnable
        
        return view
    }
    
    func updateRating(view: CosmosView) -> Double {
        
        view.settings.fillMode = .precise
        view.settings.updateOnTouch = true
        
        // Receive user input
        view.didTouchCosmos = { rating in }
        
        //let ratings = String(format: "%.1f", view.rating)
        
        return view.rating
    }
}

