//
//  Model_Common.swift

import Foundation

struct Model_Common: Decodable {
    
    var status = false
    var message = ""
    var response = ""
}

struct Model_MsgStatus: Decodable {
    var status = false
    var message = ""
}

/**
 This is for status is Bool but some times may get String, so converting to Bool.
 */

/*
 
 
   Model_Questions.swift
   Chooz
 
   Created by Apple on 30/10/20.
   Copyright © 2020 mappleBrain. All rights reserved.
 

 import Foundation

 struct Model_Questions: Decodable {
     
     var status: Int?
     var data: [QuestionsResp]?
     var last_question: String?
     var base_path: String?
 }

 struct QuestionsResp: Decodable {
     
     var question_id: String?
     var question: String?
     var category: String?
     var sub_category: String?
 //    var status: String?
 //    var created: String?
     var options: [OptionsResp]?
     
     // Attempted or not Answers
     var you: String?
 //    var you_score: String?
     var partner: String?
 //    var partner_scores: [String]?
     var deal_breaker: String?
     var mstatus: String?
         
     var preSelectedPartner: String?
     var preSelected_dealBreaker: String?
 //    var is_double_selectedPartner: Bool?
     var qID_int: Int?
     
     enum codingKeys: String, CodingKey {
         
         case question_id
         case question
         case category
         case sub_category
         //    case status: String?
         //    case created: String?
         case options
         
         // Attempted or not Answers
         case you
         //    var you_score: String?
         case partner
         //    var partner_scores: [String]?
         case deal_breaker
         case mstatus
         
         case preSelectedPartner
         case preSelected_dealBreaker
         
     }
     
     init() {
         
     }
     
     init(from decoder: Decoder) throws {
         
         let value = try decoder.container(keyedBy: codingKeys.self)
         
         self.question_id = try? value.decode(String.self, forKey: .question_id)
         self.question = try? value.decode(String.self, forKey: .question)
         self.category = try? value.decode(String.self, forKey: .category)
         self.sub_category = try? value.decode(String.self, forKey: .sub_category)
         self.options = try? value.decode([OptionsResp].self, forKey: .options)
         self.you = try? value.decode(String.self, forKey: .you)
         self.partner = try? value.decode(String.self, forKey: .partner)
         self.deal_breaker = try? value.decode(String.self, forKey: .deal_breaker)
         self.mstatus = try? value.decode(String.self, forKey: .mstatus)
         self.preSelectedPartner = try? value.decode(String.self, forKey: .preSelectedPartner)
         self.preSelected_dealBreaker = try? value.decode(String.self, forKey: .preSelected_dealBreaker)
 //        self.qID_int = Int(self.question_id)
     }
     
 }

 struct OptionsResp: Decodable {
     
 //    var id: String?
     var option_numbers: String?
     var question_id: String?
     var option_name: String?
     var created: String?
 }


 
 */

/*

 import Foundation

 struct Model_CommonMsgStatus: Decodable {
     var msg = ""
     var status = false
     
     private enum CodingKeys: String, CodingKey {
         case msg
         case status
     }

     
     init(from decoder: Decoder) throws {
         let container = try decoder.container(keyedBy: CodingKeys.self)
         
         self.msg = try container.decode(String.self, forKey: .msg)
         do {
             let statusStr = try container.decode(String.self, forKey: .status)
             if statusStr == "success" {
                 self.status = try Bool(container.decode(String.self, forKey: .status)) ?? true
             }else {
                 self.status = try Bool(container.decode(String.self, forKey: .status)) ?? false
             }
             
         }catch DecodingError.typeMismatch {
             self.status = try container.decode(Bool.self, forKey: .status)
         }
     }
 }

 */
