//
//  OpenApps.swift

import Foundation
import UIKit



struct OpenApps {
    
    static var shared = OpenApps()
    private init() { }
    
    func openDial(phoneNumber: String, viewController: UIViewController) {
        
        let mobileNumber = phoneNumber.replacingOccurrences(of: " ", with: "")
        
        if let url = URL(string: "tel://\(mobileNumber)") {
            
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }else {
            viewController.showToastSwift(msg: "Invalid Mobile Number")
        }
    }
    
    func open_whatsApp(mobileNumber: String) {
        
        if let url = URL(string: "https://api.whatsapp.com/send?phone=\(mobileNumber)") {
            
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
        
    }
    
    func openLink(linkStr: String) {
        
        if let url = URL(string: linkStr) {
            
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
    
    func openEmailApp(emailId: String)  {
        
//        let customURL = "googlegmail://\(emailId)"
        
//        self.openLink(linkStr: customURL)
        openLink(linkStr: "mailto:\(emailId)")
    }
    
    func ShareCode(viewController: UIViewController, shareItemArray: [String]) {
        
//            let activityViewController = UIActivityViewController(activityItems: ["shareContent"as NSString], applicationActivities: nil)
            // present(activityViewController, animated: true, completion: {})
            let shareItemArray = shareItemArray //["names"]
            let activityVC = UIActivityViewController(activityItems: shareItemArray,
                                                      applicationActivities: nil)
            activityVC.excludedActivityTypes = [
                .print,
                .copyToPasteboard,
                .assignToContact,
                .saveToCameraRoll,
                .airDrop
            ]
            DispatchQueue.main.async(execute: {
                viewController.present(activityVC, animated: true)
            })
    }
    
    func goTo_DirectionsInSafari(destinationLat: String, destinationLong: String) {
        
            let destLat = destinationLat
        //StaticShopOverViewData.shopData?.shop_details?.latitude
            let destLong = destinationLong
        //StaticShopOverViewData.shopData?.shop_details?.longitude
        
        
        let webSite = "https://www.google.com/maps?saddr=Current+Location&daddr=\(destLat),\(destLong)"
            // print("Directions URL --> \(webSite)")
            guard let webSiteUrl = URL.init(string: webSite) else { return }
        
        UIApplication.shared.open(webSiteUrl, options: [:], completionHandler: nil)
            // http://maps.google.com/maps?saddr=Current+Location&daddr=29.95,-85.42
    }
    
    func goTo_sourceToDestination_directionsInSafari(sourceLat: String, sourceLong: String, destinationLat: String, destinationLong: String) {
        
        let source_lat = sourceLat
        let source_long = sourceLong
        
        let destLat = destinationLat
        let destLong = destinationLong
        
        let directionsRequest = "https://www.google.com/maps?saddr=\(source_lat),\(source_long)&daddr=\(destLat),\(destLong)"
        
        guard let webSiteUrl = URL.init(string: directionsRequest) else { return }
        
        UIApplication.shared.open(webSiteUrl, options: [:], completionHandler: nil)
        // http://maps.google.com/maps?saddr=Current+Location&daddr=29.95,-85.42
    }
    
    func open_messageApplication(mobileNumber: String) {
        
        let sms: String = "sms:+\(mobileNumber)&body="
        let strURL: String = sms.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        UIApplication.shared.open(URL.init(string: strURL)!, options: [:], completionHandler: nil)
    }
}
