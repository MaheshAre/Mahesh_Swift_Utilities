//
//  NearByPlaces.swift
//  RoamEndUser
//
//  Created by Apple on 15/06/20.
//  Copyright © 2020 apple. All rights reserved.
//

import Foundation
import GooglePlaces

/*
 pod 'GoogleMaps'
 pod 'GooglePlaces'
 */

/*
 Usage:
 --------------------------------------
 In AppDelegate:
 
 import GoogleMaps
 import GooglePlaces
 
 GMSServices.provideAPIKey("AIzaSyDnZrTUOlgqLttgeBSOy0nShYL3Q6_4wv4")
 GMSPlacesClient.provideAPIKey("AIzaSyDnZrTUOlgqLttgeBSOy0nShYL3Q6_4wv4")
 ------------------------------------------
 
 In VC:
 import GooglePlaces
 
 Declaration
 var likeHoodList: GMSPlaceLikelihoodList?
 
 In ViewDidLoad
 -----
 NearByPlaces.shared.get_nearBy_places { (GMSPlacesListData) in
     if let data = GMSPlacesListData {
         self.likeHoodList = data
         
         self.tv_TripDetails.reloadData()
     }
 }
 // CellForItem at Indexpath
 
 let data = self.likeHoodList?.likelihoods[indexPath.row].place
 cell.lbl_PopularPlaces.text = data?.name
 */

struct NearByPlaces {
    
    static let shared = NearByPlaces()
    private init() { }
    
    func get_nearBy_places(onCompletion: @escaping(_ data: GMSPlaceLikelihoodList?)->Void) {
        
        let placesClient: GMSPlacesClient = GMSPlacesClient()
//        var likeHoodList: GMSPlaceLikelihoodList?
        
        placesClient.currentPlace(callback: { (placeLikelihoodList, error) -> Void in
            if let error = error {
                print("Pick Place error: \(error.localizedDescription)")
                onCompletion(nil)
                return
            }

            if let placeLikelihoodList = placeLikelihoodList {
                onCompletion(placeLikelihoodList)
            }else {
                onCompletion(nil)
            }
        })
    }
}
