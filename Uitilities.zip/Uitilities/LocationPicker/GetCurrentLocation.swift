//
//  GetCurrentLocation.swift


import Foundation
import MapKit
import CoreLocation

struct GetCurrentLocation {
    
    var delegate: GPSLocationDelegate?
        
    static var shared = GetCurrentLocation()
    private init() { }
    
    func getGPSLocation(completion: (_ lat: Double, _ lng: Double) -> Void) {
        
        let locManager = CLLocationManager()
        var currentLocation: CLLocation!
        locManager.desiredAccuracy = kCLLocationAccuracyBest
        
        if (CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedWhenInUse || CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedAlways) {
            
            currentLocation = locManager.location
            
            guard let currLoc = currentLocation else {
                return
            }
            
            let latitude = currLoc.coordinate.latitude //String(format: "%.7f", currentLocation.coordinate.latitude)
            let longitude = currLoc.coordinate.longitude //String(format: "%.7f", currentLocation.coordinate.longitude)
            let location = CLLocation(latitude: currLoc.coordinate.latitude, longitude: currLoc.coordinate.longitude)
            
            fetchCountryAndCity(location: location, completion: { countryCode, city in
                self.delegate?.fetchedLocationDetails(location: location, countryCode: countryCode, city: city)
            }) { self.delegate?.failedFetchingLocationDetails(error: $0) }
            
            //        debugPrint("Latitude:", latitude)
            //        debugPrint("Longitude:", longitude)
            
            completion(latitude, longitude)  // your block of code you passed to this function will run in this way
            
        }else {
            print("Not Granted permissions")
        }
        
    }
    
    func fetchCountryAndCity(location: CLLocation, completion: @escaping (String, String) -> (), errorHandler: @escaping (Error) -> ()) {
        CLGeocoder().reverseGeocodeLocation(location) { placemarks, error in
            if let error = error {
                debugPrint(error)
                errorHandler(error)
            } else if let countryCode = placemarks?.first?.isoCountryCode,
                let city = placemarks?.first?.locality {
                completion(countryCode, city)
            }
        }
    }
    
    func getAddress(coordinates: CLLocationCoordinate2D, onCompletion: @escaping(_ addressStruct: AddressStruct?, _ success: Bool)->Void) {
        
        var addressStruct = AddressStruct()
            
            let geoCoder = CLGeocoder()
            let location = CLLocation(latitude: coordinates.latitude, longitude: coordinates.longitude)
            //selectedLat and selectedLon are double values set by the app in a previous process
            
            geoCoder.reverseGeocodeLocation(location, completionHandler: { (placemarks, error) -> Void in
                if error != nil {
                    print("Hay un error")
                    onCompletion(nil, false)
                } else {
                    
                    /// Place details
                    var place: CLPlacemark!
                    place = placemarks?.last
                    
                    /*
                     print(place)
                     print(place.thoroughfare!)
                     print(place.subLocality!)
                     print(place.locality!)
                     print(place.addressDictionary!)
                     print(place.location!)
                     print(place.subLocality!)
                     print(place.description)
                     print(place.administrativeArea!)
                     print(place.addressDictionary!["FormattedAddressLines"]!)
                     */
                    
                    var addressString : String = ""
                    
                    if place.subThoroughfare != nil {
                        addressString = addressString + place.subThoroughfare! + ", "
                        //                    print("Sub-Through -> \(String(describing: place.subThoroughfare))")
                        addressStruct.flat =  place.subThoroughfare!
                    }
                    
                    if place.subLocality != nil {
                        addressString = addressString + place.subLocality! + ", "
                        //                    print("Sub_Loc -> \(String(describing: place.subLocality))")
                        addressStruct.colony =  place.subLocality!
    //                    self.marker.title = self.addressStruct.colony
                    }
                    if place.thoroughfare != nil {
                        addressString = addressString + place.thoroughfare! + ", "
                        //                    print("Through -> \(String(describing: place.thoroughfare))")
                        addressStruct.landmark =  place.thoroughfare!
    //                    self.marker.title = self.addressStruct.landmark
                    }
                    
                    if place.locality != nil {
                        addressString = addressString + place.locality! + ", "
                        //                    print("locality -> \(String(describing: place.locality))")
                        addressStruct.city =  place.locality!
                    }
                    
                    if place.administrativeArea != nil {
                        addressString = addressString + place.administrativeArea! + ", "
                        //                    print("AdministrativeArea -> \(String(describing: place.administrativeArea))")
                        addressStruct.state = place.administrativeArea!
                    }
                    
                    if place.country != nil {
                        addressString = addressString + place.country! + ", "
                        //                    print("country -> \(String(describing: place.country))")
                        addressStruct.country = place.country!
                    }
                    if place.postalCode != nil {
                        addressString = addressString + place.postalCode! + " "
                        //                    print("postalCode -> \(String(describing: place.postalCode))")
                        addressStruct.pincode = place.postalCode!
                    }
                    
                    addressStruct.lat = coordinates.latitude
                    addressStruct.long = coordinates.longitude
                    
    //                print("Struct --> \(self.addressStruct)")
                    
                    
    //                self.marker.position = CLLocationCoordinate2DMake(coordinates.latitude, coordinates.longitude)
    //                self.marker.icon = UIImage(named: "icon_pin_color")//GMSMarker.markerImage(with: UIColor.green)
    //                self.marker.appearAnimation = GMSMarkerAnimation.pop
    //                self.marker.map = self.mapView
                    
    //                self.lbl_address.text = addressString
                    addressStruct.completeAddress = addressString
                    
                    onCompletion(addressStruct, true)
                }
                
            })
            
        }
}

protocol GPSLocationDelegate {
    func fetchedLocationDetails(location: CLLocation, countryCode: String, city: String)
    func failedFetchingLocationDetails(error: Error)
}



struct LocationPermissions {
    
    static func enableLocationPermission(viewController: UIViewController) {
        
        if CLLocationManager.locationServicesEnabled() {
            
            switch CLLocationManager.authorizationStatus() {
                
            case .notDetermined, .restricted, .denied:
                
                let alertController = UIAlertController (title: "Location Permission Denied", message: "To re-enable, please go to Settings and turn on Location Service for this app. Based On Location Only You will Get Business Address,So User Can Compulsory Enable Location Services for this App.", preferredStyle: .alert)
                
                let settingsAction = UIAlertAction(title: "Ok", style: .default) { (_) -> Void in
                    
                    guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
                        return
                    }
                    
                    if UIApplication.shared.canOpenURL(settingsUrl) {
                        UIApplication.shared.open(settingsUrl, options: [:], completionHandler: nil)
                    }
                }
                alertController.addAction(settingsAction)
                let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
                alertController.addAction(cancelAction)
                
                viewController.present(alertController, animated: true, completion: nil)
                
            case .authorizedAlways, .authorizedWhenInUse:
                print("Access")
            @unknown default:
                break
            }
        } else {
            //                print("Location services are not enabled")
        }
    }
}

struct AddressStruct {
    
    var flat = ""
    var landmark = ""
    var colony = ""
    var city = ""
    var state = ""
    var pincode = ""
    var country = ""
    var lat = 0.0
    var long = 0.0
    var completeAddress = ""
    
    var formattedAddress = ""
    
}

extension CLPlacemark {
    
    var title: String {
        return name ?? ""
    }

//    var compactAddress: String? {
//        if let name = name {
//            var result = name
//
//            if let street = thoroughfare {
//                result += ", \(street)"
//            }
//
//            if let city = locality {
//                result += ", \(city)"
//            }
//
//            if let country = country {
//                result += ", \(country)"
//            }
//
//            return result
//        }
//
//        return nil
//    }

}


//MARK:- Show Route on MKMapView

/*
 
 func set_RegionForCoordinates(mapView: MKMapView,coords: CLLocationCoordinate2D) {

     let span = MKCoordinateSpan(latitudeDelta: 12, longitudeDelta: 12) // 0.003, 0.003
     let region = MKCoordinateRegion(center: coords, span: span)
     mapView.setRegion(region, animated: true)
 }
 
 func show_annotation(mapView: MKMapView, coordinates: CLLocationCoordinate2D) {
     
    self.mapView.removeAnnotations(self.mapView.annotations)
 
     let annotation = MKPointAnnotation()
     //                    annotation.title = "D"
     annotation.coordinate = CLLocationCoordinate2D(latitude: coordinates.latitude, longitude: coordinates.longitude)
     mapView.addAnnotation(annotation)
     
     mapView.addAnnotation(annotation)
     self.set_RegionForCoordinates(mapView: mapView, coords: coordinates)
 }
 
 func show_annotations(mapView: MKMapView, coordinates_array: [CLLocationCoordinate2D]) {
     
     var annotatiosn_array = [MKPointAnnotation]()
     var coordinates = CLLocationCoordinate2D()
     
     for location in coordinates_array {
         
         coordinates = CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude)
         
         let annotation = MKPointAnnotation()
         //                    annotation.title = "D"
         annotation.coordinate = CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude)
         mapView.addAnnotation(annotation)
         annotatiosn_array.append(annotation)
     }
     
     mapView.addAnnotations(annotatiosn_array)
     self.set_RegionForCoordinates(mapView: mapView, coords: coordinates)
 }

extension CompleteTripVC: MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView, regionWillChangeAnimated animated: Bool) {
        
    }
    
    func showRouteOnMap(pickupCoordinate: CLLocationCoordinate2D, destinationCoordinate: CLLocationCoordinate2D) {

            let sourcePlacemark = MKPlacemark(coordinate: pickupCoordinate, addressDictionary: nil)
            let destinationPlacemark = MKPlacemark(coordinate: destinationCoordinate, addressDictionary: nil)

            let sourceMapItem = MKMapItem(placemark: sourcePlacemark)
            let destinationMapItem = MKMapItem(placemark: destinationPlacemark)

    //        let sourceAnnotation = MKPointAnnotation()
    //
    //        if let location = sourcePlacemark.location {
    //            sourceAnnotation.coordinate = location.coordinate
    //        }
    //
    //        let destinationAnnotation = MKPointAnnotation()
    //
    //        if let location = destinationPlacemark.location {
    //            destinationAnnotation.coordinate = location.coordinate
    //        }
    //
    //        self.mapkitView.showAnnotations([sourceAnnotation,destinationAnnotation], animated: true )

            let directionRequest = MKDirections.Request()
            directionRequest.source = sourceMapItem
            directionRequest.destination = destinationMapItem
            directionRequest.transportType = .automobile

            // Calculate the direction
            let directions = MKDirections(request: directionRequest)

            directions.calculate {
                (response, error) -> Void in

                guard let response = response else {
                    if let error = error {
                        print("Error: \(error)")
                    }

                    return
                }

                let route = response.routes[0]

                self.mapkitView.addOverlay((route.polyline), level: MKOverlayLevel.aboveRoads)

                let span = MKCoordinateSpan(latitudeDelta: 0.07, longitudeDelta: 0.07)
                let region = MKCoordinateRegion(center: pickupCoordinate, span: span)
                self.mapkitView.setRegion(region, animated: true)
                self.mapkitView.showsUserLocation = true
                
                // For Images
                let info1 = CustomPointAnnotation()
                info1.coordinate = pickupCoordinate
 // CLLocationCoordinate2DMake(self.from_lat, self.from_long)
    //            info1.title = "Info1"
    //            info1.subtitle = "Subtitle"
                info1.image = #imageLiteral(resourceName: "icon_location_pin_black")
                
                let info2 = CustomPointAnnotation()
                info2.coordinate = destinationCoordinate
 // CLLocationCoordinate2DMake(self.to_lat, self.to_long)
    //            info2.title = "Info2"
    //            info2.subtitle = "Subtitle"
                info2.image = #imageLiteral(resourceName: "icon_location")
                
                self.mapkitView.addAnnotation(info1)
                self.mapkitView.addAnnotation(info2)
                
    //            let rect = route.polyline.boundingMapRect
    //            self.mapkitView.setRegion(MKCoordinateRegion(rect), animated: true)

            }
        }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        
        if !(annotation is CustomPointAnnotation) {
            return nil
        }
        
        let reuseId = "test"
        
        var anView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId)
        if anView == nil {
            anView = MKAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            anView!.canShowCallout = true
        }
        else {
            anView!.annotation = annotation
        }
        
        //Set annotation-specific properties **AFTER**
        //the view is dequeued or created...
        
        let cpa = annotation as! CustomPointAnnotation
        anView!.image = cpa.image //UIImage(named:cpa.imageName)
        
        return anView!
    }
    
    // MARK: - MKMapViewDelegate
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        
        let renderer = MKPolylineRenderer(overlay: overlay)
        
        renderer.strokeColor = UIColor(red: 17.0/255.0, green: 147.0/255.0, blue: 255.0/255.0, alpha: 1)
        
        renderer.lineWidth = 3.0
        
        return renderer
    }
}

 class CustomPointAnnotation: MKPointAnnotation {
     var image: UIImage!
 }

*/


/*
 Get Current location at Home Screen/ Starting Screen
 */
/*
extension HomeVC: CLLocationManagerDelegate {
    
    // declare in Home Screen
    // var locationManager = CLLocationManager()
    // var addressStruct = AddressStruct()
    
    /*
     Call this Function in ViewDidLoad
     */
    func delegateSpecify() {
        
        self.locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        self.locationManager.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        
        if (CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedWhenInUse || CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedAlways) {
            
        }else {
            LocationPermissions.enableLocationPermission(viewController: self)
        }
//
//        guard status == .authorizedWhenInUse else {
//            return
//        }

        locationManager.startUpdatingLocation()
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard locations.first != nil else {
            return
        }
        
        GetCurrentLocation.shared.getAddress(coordinates: locations.first!.coordinate) { (address_struct, isSuccess) in
            if isSuccess {
                
                self.addressStruct = address_struct!
                self.address_display() // Display address where you want
                print(address_struct)
            }
 
        }
 
 self.show_annotation(mapView: self.mapView, coordinates: locations.first!.coordinate)
        
        locationManager.stopUpdatingLocation()
    }
    
}

*/
