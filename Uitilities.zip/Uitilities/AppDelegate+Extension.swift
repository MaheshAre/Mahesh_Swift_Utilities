//
//  AppDelegate+Extension.swift



/*
 
GMSServices.provideAPIKey("AIzaSyDnZrTUOlgqLttgeBSOy0nShYL3Q6_4wv4")
GMSPlacesClient.provideAPIKey("AIzaSyDnZrTUOlgqLttgeBSOy0nShYL3Q6_4wv4")
 
GMSServices.provideAPIKey("AIzaSyDAub648ZuMc6Sbnbg1fOzSoaDbEWUsi3U")
GMSPlacesClient.provideAPIKey("AIzaSyDAub648ZuMc6Sbnbg1fOzSoaDbEWUsi3U")
 
 // CIAO Rides
 GMSServices.provideAPIKey("AIzaSyBSaSzEI417kuNqInU-19QL1JhIr3nNX3M")
 GMSPlacesClient.provideAPIKey("AIzaSyBSaSzEI417kuNqInU-19QL1JhIr3nNX3M")
*/

import Foundation
import UIKit

import GoogleMaps
import GooglePlaces

import Firebase
import FirebaseInstanceID
import FirebaseMessaging
import UserNotifications

// Push Notofications
/*
import Firebase
import FirebaseInstanceID
import FirebaseMessaging
import UserNotifications
 
 
 pod 'Firebase/Analytics'
 pod 'Firebase/Core'
 pod 'Firebase/Messaging'
 pod 'Firebase/Auth'
 pod 'Firebase/Firestore'
 
*/

var notificationData = NotificationDataStruct()
var notification_default = Notification_defaultStruct()

var isUpdate_available = false

extension AppDelegate {
    
    static func getDelegate() -> AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }
    
    var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    func statusBackgroundColor(color: UIColor) {
    
        
        if #available(iOS 13.0, *) {
            
            /*
             let app = UIApplication.shared
             let statusBarHeight: CGFloat = app.statusBarFrame.size.height
             
             let statusbarView = UIView()
             statusbarView.backgroundColor = color
             let view = self.window?.rootViewController?.view
             view!.addSubview(statusbarView)
             
             statusbarView.translatesAutoresizingMaskIntoConstraints = false
             statusbarView.heightAnchor
             .constraint(equalToConstant: statusBarHeight).isActive = true
             statusbarView.widthAnchor
             .constraint(equalTo: view!.widthAnchor, multiplier: 1.0).isActive = true
             statusbarView.topAnchor
             .constraint(equalTo: view!.topAnchor).isActive = true
             statusbarView.centerXAnchor
             .constraint(equalTo: view!.centerXAnchor).isActive = true
             
             */
            
            let statusBar = UIView(frame: UIApplication.shared.keyWindow?.windowScene?.statusBarManager?.statusBarFrame ?? CGRect.zero)
            statusBar.backgroundColor = color
            UIApplication.shared.keyWindow?.addSubview(statusBar)
            
        }else {
            let statusBar = UIApplication.shared.value(forKeyPath: "statusBarWindow.statusBar") as? UIView
            statusBar?.backgroundColor = color
        }
         
    }
    
    func removeBackTextFromNavigationBar() {
        UIBarButtonItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.clear], for: .normal)
    }
    
    func navigationBarBackgroundColor(color: UIColor) {
        
        UINavigationBar.appearance().barTintColor = color
    }
    
    func navigationTitleColor(color: UIColor) {
        
        UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor : color]
        UINavigationBar.appearance().tintColor = color
    }
    
    
    func alertController(title: String, message: String) {
        
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default) {
            UIAlertAction in
            
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
            self.navigationView(viewObj: vc)
        }
        
        alertController.addAction(okAction)
        
        self.window?.rootViewController?.present(alertController, animated: true, completion: nil)
    }
    
    //MARK:- Screen Rotation

    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {

        if let navigationController = self.window?.rootViewController as? UINavigationController {

            // If the visible view controller is the
            // view controller you'd like to rotate, allow
            // that window to support all orientations
            if navigationController.visibleViewController is PlayVideoVC {
                return UIInterfaceOrientationMask.all
            }else {
                return UIInterfaceOrientationMask.portrait
            }
        }
        return UIInterfaceOrientationMask.portrait
    }
    
}


//MARK:- Push Notifications

extension AppDelegate {
    
    // Call this Function in AppDelegate
    
    func pushNotificationsConfigure(_ application: UIApplication) {
        
        FirebaseApp.configure()
        Messaging.messaging().delegate = self
        
        
        if #available(iOS 10.0, *) {
            // For iOS 10 display notification (sent via APNS)
            UNUserNotificationCenter.current().delegate = self
            let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
            UNUserNotificationCenter.current().requestAuthorization(
                options: authOptions,
                completionHandler: {_, _ in })
            // For iOS 10 data message (sent via FCM
            Messaging.messaging().delegate = self
            
            // Messaging.messaging().remoteMessageDelegate = self
        } else {
            let settings: UIUserNotificationSettings =
                UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
            application.registerUserNotificationSettings(settings)
        }
        
        FirebaseConfiguration().setLoggerLevel(FirebaseLoggerLevel.min)
        application.registerForRemoteNotifications()
        
        
    }
    
    func showPermissionAlert() {
        
        let alert = UIAlertController(title: "WARNING", message: "Please enable access to Notifications in the Settings app.", preferredStyle: .alert)
        let settingsAction = UIAlertAction(title: "Settings", style: .default) {[weak self] (alertAction) in
            
            self?.gotoAppSettings()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        alert.addAction(settingsAction)
        alert.addAction(cancelAction)
        DispatchQueue.main.async {
            self.window?.rootViewController?.present(alert, animated: true, completion: nil)
        }
    }
    
    func gotoAppSettings() {
        guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
            return
        }
        if UIApplication.shared.canOpenURL(settingsUrl) {
            // UIApplication.shared.openURL(settingsUrl)
            UIApplication.shared.canOpenURL(settingsUrl)
        }
    }
    
    
    func navigationView(viewObj:UIViewController){
        
        let vc = UIApplication.getTopViewController()
        vc?.navigationController?.pushViewController(viewObj, animated: true)
        
        
        /*
         let storyboard = UIStoryboard(name: "Main", bundle: nil)
         let optionObj = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController // HomeViewController
         let rearViewController = storyboard.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
         let frontNavigationController = UINavigationController(rootViewController: optionObj)
         frontNavigationController.disableSwipeBack()
         let revealController = storyboard.instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
         revealController.rearViewController = rearViewController
         revealController.frontViewController = frontNavigationController
         self.window?.rootViewController = revealController
         frontNavigationController.pushViewController(viewObj, animated: true)
         
         */
        
        /*
         
         let storyboard = UIStoryboard(name: "Main", bundle: nil)
         
         let tabBar:UITabBarController = self.window?.rootViewController as! HomeTabBarVC //or whatever your way of getting reference is
         let navInTab:UINavigationController = tabBar.viewControllers?[3] as! UINavigationController
         let destinationViewController = viewObj
         navInTab.pushViewController(destinationViewController, animated: true)
         
         */
        
        //        let optionObj = storyboard.instantiateViewController(withIdentifier: "HomeTabBarVC") as! HomeTabBarVC // HomeViewController
        //        optionObj.selectedIndex = 3
        //        let navVC = UINavigationController(rootViewController: optionObj)
        //        self.window?.rootViewController = optionObj
        //        navVC.pushViewController(viewObj, animated: true)
    }
    
    
    /**
     Add in URL Schems in Xcode Project
     */
    
    func get_deepLink(dataStr: String, isOpenVCFor: Enum_ComingFrom?) -> URL? {
            
            let openVC = (isOpenVCFor?.rawValue)!
            let path = "\(appTitle)://\(openVC)?\(dataStr)"
            var deepLinkUrl: URL?
            
            if let appUrl = URL(string: path) {
    //            let application = UIApplication.shared
    //            if application.canOpenURL(appUrl) {
    //                application.open(appUrl, options: [:], completionHandler: nil)
    //                print(appUrl)
    //            }
                deepLinkUrl = appUrl
                
            }
            
            return deepLinkUrl
        }
        
        /*
         Call This Function in Open URL in AppDelegate
         In Scene Delegate -> openURLContexts in func
         */
        func open_deepLink(url: URL) {
            
            print(url)
            let urlComponents = URLComponents(url: url, resolvingAgainstBaseURL: true)
            /*
                // is if we pass any data after the :// we can get as host For Ex: chooz://openProfile?user_id=465
             in that host is -> openProfile
             // ?user_id=465
             */
            let host = urlComponents?.host
            print(host)
            if host == Enum_ComingFrom.forProfileDetails.rawValue {
                
                let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "NotificationVC") as! NotificationVC
                UIApplication.getTopViewController()?.navigationController?.pushViewController(vc, animated: true)
            }else {
                
            }
            
        }

}

extension AppDelegate: UNUserNotificationCenterDelegate, MessagingDelegate {
    
    func registerForPushNotifications() {
        if #available(iOS 10.0, *) {
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) {
                [weak self] (granted, error) in
                print("Permission granted: \(granted)")
                guard granted else {
                    print("Please enable \"Notifications\" from App Settings.")
                    
                    self?.showPermissionAlert()
                    return
                }
                self?.getNotificationSettings()
            }
        } else {
            let settings = UIUserNotificationSettings(types: [.alert, .sound, .badge], categories: nil)
            UIApplication.shared.registerUserNotificationSettings(settings)
            UIApplication.shared.registerForRemoteNotifications()
        }
    }
    
    @available(iOS 10.0, *)
    func getNotificationSettings() {
        UNUserNotificationCenter.current().getNotificationSettings { (settings) in
            print("Notification settings: \(settings)")
            guard settings.authorizationStatus == .authorized else { return }
            
            DispatchQueue.main.async {
                UIApplication.shared.registerForRemoteNotifications()
            }
        }
    }
    
    /*
    
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        
        let tokenParts = deviceToken.map { data -> String in
            
            return String(format: "%02.2hhx", data)
        }
        let token = tokenParts.joined()
        
        print("Device Token: \(token)")
        
        let udid = Custom_UDID.get_UDID()
        
        print("UDID -> ", UIDevice.current.identifierForVendor!.uuidString)
        UserDefaults.standard.set(token, forKey: Enum_Device.device_token.rawValue)
        UserDefaults.standard.set(udid, forKey: Enum_Device.UDID.rawValue)
        
        
        Messaging.messaging().apnsToken = deviceToken
        
        InstanceID.instanceID().instanceID { (result, error) in
            
            if let error = error {
                
                print("Error fetching remote instange ID: \(error)")
                
            }else if let result = result {
                
                print("FCM Remote instance ID token: \(result.token)")
                user_Defaults.set(result.token, forKey: Enum_Device.FCM_token.rawValue)
            }
        }
        
    }
    
    */
    
    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String) {

        print("FCM Token: \(fcmToken)")
        
        let udid = Custom_UDID.get_UDID()
        
        print("UDID -> ", UIDevice.current.identifierForVendor!.uuidString)
        UserDefaults.standard.set(udid, forKey: Enum_Device.UDID.rawValue)

        user_Defaults.set(fcmToken, forKey: Enum_Device.FCM_token.rawValue)

        let dataDict:[String: String] = ["token": fcmToken]

        NotificationCenter.default.post(name: Notification.Name("FCMToken"), object: nil, userInfo: dataDict)

        // TODO: If necessary send token to application server.

        // Note: This callback is fired at each app startup and whenever a new token is generated.

    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        
        print("Failed to register: \(error)")
        
    }
    
    func application(application: UIApplication, didReceiveRemoteNotification userInfo: [NSObject : AnyObject], fetchCompletionHandler completionHandler: (UIBackgroundFetchResult) -> Void) {
        
        print(userInfo)
        
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any]) {
        
        // If your app was running and in the foreground
        
        // Or
        
        // If your app was running or suspended in the background and the user brings it to the foreground by tapping the push notification
        
        print("didReceiveRemoteNotification \(userInfo)")
                
        //        guard let dict = userInfo["aps"]  as? [String: Any], let msg = dict ["alert"] as? String
        //        else {
        //            print("Notification Parsing Error")
        //            return
        //        }
        //            let storyboard = UIStoryboard(name: "Main", bundle: nil)
        //
        //            let destinationController = storyboard.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
        //
        //            //  destinationController.booikingId = (userInfo ["alert"] as? String)!
        //
        //            navigationView(viewObj: destinationController)
        
    }
    
    @available(iOS 10.0, *)
    
    func userNotificationCenter(_ center: UNUserNotificationCenter,  willPresent notification: UNNotification, withCompletionHandler   completionHandler: @escaping (_ options:   UNNotificationPresentationOptions) -> Void) {
        
        //Called when a notification is delivered to a foreground app.
        
        completionHandler([.alert, .badge, .sound])
        
        let userInfo = notification.request.content.userInfo as? [String: Any]
        
        print("userinfo dict is \(String(describing: userInfo))")
        
        // cancel_user
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let userInfo = response.notification.request.content.userInfo as? [String: Any]
        
        self.notificationDataAssignToStruct(dict: userInfo)
        
        print("type --> \(String(describing: notificationData.type))")
        
        if notificationData.type == "new_request" {
            
            PlaySong.shared.playSound(songName: "Ring_Reggae", type: "mp3")
            
        }else if notificationData.type == "open_payment_screen" {
            
            let optionObj = storyboard.instantiateViewController(withIdentifier: "PickPaymentOptionVC") as! PickPaymentOptionVC
            optionObj.order_id = notificationData.order_id!
            optionObj.rider_id = notificationData.rider_id!
            self.navigationView(viewObj: optionObj)
        }else if notificationData.type == "accepted_request" {
            
            let optionObj = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
            self.navigationView(viewObj: optionObj)
        }else if notificationData.type == "cancel_user" || notificationData.type == "user_cancel_ride" {
            
            self.alertController(title: notification_default.title!, message: notification_default.body!)
        }
                
        // notificationData.type == "user_cancel_ride"
    }
    
    @available(iOS 10.0, *)
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        
        
        // Called to let your app know which action was selected by the user for a given notification.
        
        UIApplication.shared.applicationIconBadgeNumber = 0
        
        let userInfo = response.notification.request.content.userInfo as? [String: Any]
        
        self.notificationDataAssignToStruct(dict: userInfo)
        
        /*
         print(PushNotificationStruct(userInfo).title)
         print(PushNotificationStruct(userInfo).body)
         
         */
        
        let type = ""

        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        if notificationData.type == "new_request" {
//            PlaySong.shared.playSound(songName: "Ring_Reggae", type: "mp3")
            player?.stop()

//            PlaySong.shared.playSound(songName: "Ring_Reggae", type: "mp3")
            
            let optionObj = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
            optionObj.isCommingFrom_newRequest = true
            optionObj.order_id = notificationData.order_id!
            self.navigationView(viewObj: optionObj)
            
        }else if notificationData.type == "open_payment_screen" {
            
            let optionObj = storyboard.instantiateViewController(withIdentifier: "PickPaymentOptionVC") as! PickPaymentOptionVC
            optionObj.order_id = notificationData.order_id!
            optionObj.rider_id = notificationData.rider_id!
            self.navigationView(viewObj: optionObj)
        }
       
        print("type -->\(type)")
        // open_payment_screen
        /*
        
        let optionObj = storyboard.instantiateViewController(withIdentifier: "SelectLoactionVC") as! SelectLoactionVC // HomeViewController
        self.navigationView(viewObj: optionObj)
        
        */
    }
    
    func notificationDataAssignToStruct(dict: [String: Any]?) {
        
        if let data = dict {
            
            notificationData.user_id = data[BaseKey_pushNotification+"."+Enum_NotificationKeys.user_id.rawValue] as? String
            notificationData.message_id = data[BaseKey_pushNotification+"."+Enum_NotificationKeys.message_id.rawValue] as? String
            notificationData.amount = data[BaseKey_pushNotification+"."+Enum_NotificationKeys.amount.rawValue] as? String
            notificationData.type = data[BaseKey_pushNotification+"."+Enum_NotificationKeys.type.rawValue] as? String
            notificationData.order_id = data[BaseKey_pushNotification+"."+Enum_NotificationKeys.order_id.rawValue] as? String
            notificationData.rider_id = data[BaseKey_pushNotification+"."+Enum_NotificationKeys.rider_id.rawValue] as? String
            
            let aps = data["aps"] as? [String: Any]
            let alertDict = aps!["alert"] as? [String: Any]
            notification_default.title = alertDict!["title"] as? String
            notification_default.body = alertDict!["body"] as? String
        }
    }
}

//MARK:- Local Notification

extension AppDelegate {
    
    let notificationCenter = UNUserNotificationCenter.current()
    
    func set_localNotification(title: String, bodyMessage: String) {
        
        let content = UNMutableNotificationContent()
        let userActions = "User Actions"
        
        content.title = title
        content.body = bodyMessage
        content.sound = UNNotificationSound.default
//        content.badge = 1
        content.categoryIdentifier = userActions
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        let identifier = "Local Notification"
        let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
        
        notificationCenter.add(request) { (error) in
            if let error = error {
                print("Error \(error.localizedDescription)")
            }
        }
        let accept_action = UNNotificationAction(identifier: "Accept", title: "Accept", options: [.authenticationRequired])
        let reject_action = UNNotificationAction(identifier: "Reject", title: "Reject", options: [.destructive])
        let category = UNNotificationCategory(identifier: userActions, actions: [accept_action, reject_action], intentIdentifiers: [], options: [])
        
        // notificationCenter.setNotificationCategories([category])
    }
}

enum Enum_Device: String {
    case device_token
    case FCM_token
    case UDID
}

struct Notification_defaultStruct {
    
    var title: String?
    var body: String?
}

struct NotificationDataStruct {
    
    var user_id: String?
    var message_id: String?
    var amount: String?
    var type: String?
    var order_id: String?
    var rider_id: String?
}

var BaseKey_pushNotification = "gcm.notification"

enum Enum_NotificationKeys: String {
    
    case user_id
    case message_id
    case amount
    case type
    case order_id
    case rider_id
}

struct Device {
    static func get_UDID() -> String {
        return UIDevice.current.identifierForVendor!.uuidString
    }
    static func get_FCM_token() -> String {
        if let fcmToken = user_Defaults.value(forKey: Enum_Device.FCM_token.rawValue) as? String {
            return fcmToken
        }else {
            return "123"
        }
    }
}

extension UIApplication {

    class func getTopViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {

        if let nav = base as? UINavigationController {
            return getTopViewController(base: nav.visibleViewController)

        } else if let tab = base as? UITabBarController, let selected = tab.selectedViewController {
            return getTopViewController(base: selected)

        } else if let presented = base?.presentedViewController {
            return getTopViewController(base: presented)
        }
        return base
    }
}
