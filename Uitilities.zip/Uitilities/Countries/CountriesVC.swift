//
//  ViewController.swift
//  ADCountryPicker
//
//  Created by Amila on 21/4/17.
//  Copyright © 2017 Amila Diman. All rights reserved.
//

import UIKit

/*
    
 This is Samle class to use Country codes feature
 
 */

class CountriesVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func show_countriesPicker() {
        
        let picker = ADCountryPicker(style: .grouped)
                // delegate
                picker.delegate = self

                // Display calling codes
                picker.showCallingCodes = true

                // or closure
                picker.didSelectCountryClosure = { name, code in
                    _ = picker.navigationController?.popToRootViewController(animated: true)
                    print(code)
                }
                
                
        //        Use this below code to present the picker
                
                let pickerNavigationController = UINavigationController(rootViewController: picker)
                self.present(pickerNavigationController, animated: true, completion: nil)
    }
}

extension CountriesVC: ADCountryPickerDelegate {
    
    func countryPicker(_ picker: ADCountryPicker, didSelectCountryWithName name: String, code: String, dialCode: String) {
        
        _ = picker.navigationController?.popToRootViewController(animated: true)
        self.dismiss(animated: true, completion: nil)
//        countryNameLabel.text = name
//        countryCodeLabel.text = code
//        countryCallingCodeLabel.text = dialCode
        
       let img =  picker.getFlag(countryCode: code)
       let name =  picker.getCountryName(countryCode: code)
       let dial_code =  picker.getDialCode(countryCode: code)
    }
}

