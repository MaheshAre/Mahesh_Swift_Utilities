//
//  PlayVideoVC.swift


import UIKit
import BMPlayer

class PlayVideoVC: UIViewController {
    
    @IBOutlet weak var player: BMCustomPlayer!
    //    @IBOutlet weak var player: BMPlayer!
//    var player: BMPlayer!
    
    var videoPath = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let urlStr = BaseURL_Image+self.videoPath
        
        setupPlayerManager()
        setupPlayerResource()

        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    func setupPlayerManager(){
        
        BMPlayerConf.topBarShowInCase = .none
        BMPlayerConf.shouldAutoPlay = false
    }

    func setupPlayerResource() {
        // "https://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4"
        
        player.backBlock = { [unowned self] (isFullScreen) in
            if isFullScreen == true { return }
            let _ = self.navigationController?.popViewController(animated: true)
        }
        
        let url = URL(string: BaseURL_Image+self.videoPath)!
        let title_array = self.videoPath.components(separatedBy: "/")
        let asset = BMPlayerResource(name: title_array.last!,
                                     definitions: [BMPlayerResourceDefinition(url: url, definition: "")],
                                     cover: nil,
                                     subtitles: nil
        )
        player.panGesture.isEnabled = false
        player.setVideo(resource: asset)
    }
    
    override func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        
        switch UIDevice.current.orientation{
        case .portrait:
            self.navigationController?.setNavigationBarHidden(false, animated: true)
        case .portraitUpsideDown:
            self.navigationController?.setNavigationBarHidden(true, animated: true)
        case .landscapeLeft:
            self.navigationController?.setNavigationBarHidden(true, animated: true)
        case .landscapeRight:
            self.navigationController?.setNavigationBarHidden(true, animated: true)
        default:
            self.navigationController?.setNavigationBarHidden(true, animated: true)
        }
    }
   
}
