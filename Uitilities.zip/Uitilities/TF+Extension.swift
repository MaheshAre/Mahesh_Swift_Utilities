//
//  TF+Extension.swift


import Foundation
import UIKit

extension UITextField {
    
    func leftPadding(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    
    func rightPadding(_ amount:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.rightView = paddingView
        self.rightViewMode = .always
    }
    
    func allow_MaxCharacters(limit: Int, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let charsLimit = limit
        
        let startingLength = self.text!.count //testField.text?.characters.count ?? 0
        let lengthToAdd = string.count
        let lengthToReplace =  range.length
        let newLength = startingLength + lengthToAdd - lengthToReplace
        
        return newLength <= charsLimit
    }
    
    func allow_Alphabets(shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let set = NSCharacterSet(charactersIn: "ABCDEFGHIJKLMONPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ").inverted
        return string.rangeOfCharacter(from: set) == nil
    }
    
    func allow_MobileNumber_withREGEX(text: String) -> Bool {
        
        let isBackSpace = strcmp(text, "\\b")
        if (isBackSpace == -92) {
            return true
        }
        if self.text?.count == 0 {
            if text == "6" || text == "7" || text == "8" || text == "9" {
                return true
            }else {
                return false
            }
        }else if self.text!.count > 9 {
            return false
        }
        return true
    }
    
    func isValidEmail() -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9-]+\\.{1}[A-Za-z]{2,64}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: self.text)
    }
    
    func isValidMobile(setCount: Int) -> Bool {
        
        if (self.text?.count)! >= setCount {
            return true
        }else{
            return false
        }
    }
    
    func isValidTF() -> Bool {
        
        if self.text != nil && self.text != "" {
            return true
        }else{
            return false
        }
    }
    
    func isValidPassword_Regex(minChars: Int, isUppercase: Bool, isLowerCase: Bool, isDigit: Bool, isSymbol: Bool) -> Bool {
        // least one uppercase,
        // least one lowercase
        // least one digit
        // least one symbol
        //  min characters total
        
        let password = self.text!.trimmingCharacters(in: CharacterSet.whitespaces)
        var passwordRegx = ""
        //        passwordRegx = "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&<>*~:`-]).{\(minChars),}$"
        if isUppercase {
            passwordRegx += "(?=.*?[A-Z])"
        }
        if isLowerCase {
            passwordRegx += "(?=.*?[a-z])"
        }
        if isDigit {
            passwordRegx += "(?=.*?[0-9])"
        }
        if isSymbol {
            passwordRegx += "(?=.*?[#?!@$%^&<>*~:`-])"
        }
        
        passwordRegx += ".{\(minChars),}$"
        
        let passwordCheck = NSPredicate(format: "SELF MATCHES %@",passwordRegx)
        return passwordCheck.evaluate(with: password)
        
    }
    
    func getExactString(range: NSRange, string: String) -> String {
        
        if let text = self.text, let textRange = Range(range, in: text) {
           let updatedText = text.replacingCharacters(in: textRange,
                                                      with: string)
            return updatedText
        }else {
            return ""
        }
    }
    
    func allow_below_IntAmount(string: String, amount: Int) -> Bool {
        
        let totalText = self.text!+string
        if let total = Int(totalText) {
            if total <= 100 {
                return true
            }else {
                return false
            }
        }else {
            return false
        }
    }
    
    
}

extension UITextField{
    @IBInspectable var placeHolderColor: UIColor? {
        get {
            return self.placeHolderColor
        }
        set {
            self.attributedPlaceholder = NSAttributedString(string:self.placeholder != nil ? self.placeholder! : "", attributes:[NSAttributedString.Key.foregroundColor: newValue!])
        }
    }
}


/*
 
 /**
 Search TF
 */
   var reviewQuestuons_array = [Review_Questions]()

     var search_reviewQuestuons_array = [Review_Questions]()



 @IBAction func TF_searchQuestions(_ sender: UITextField) {

         

         // Editing Changed
         

         self.search_reviewQuestuons_array.removeAll()

         if sender.text?.count != 0 {

             self.search_reviewQuestuons_array = self.reviewQuestuons_array.filter({ (response) ->
         Bool in

                 let searchKey = response.question!


         //filPatient.first_name!+filPatient.last_name!+filPatient.umr_no!+filPatient.patient_id!



         return (searchKey.lowercased().contains(sender.text!.lowercased()))

         })

         /*

              for dicData in self.categoryResponse! {

              let isMachingWorker : NSString = (dicData.title!) as NSString

              let range = isMachingWorker.lowercased.range(of: textField.text!, options:

              NSString.CompareOptions.caseInsensitive, range: nil, locale: nil)

              if range != nil {
              self.search_categoryResponse?.append(dicData)
              }

              }

         */

         } else {

         self.search_reviewQuestuons_array = self.reviewQuestuons_array
         }

         self.TV_QuestionList.reloadData()

     }
 
 */

//MARK:- Expiry Date & Card Number Format

extension String {
    
    func grouping(every groupSize: String.IndexDistance, with separator: Character) -> String {
       let cleanedUpCopy = replacingOccurrences(of: String(separator), with: "")
       return String(cleanedUpCopy.enumerated().map() {
            $0.offset % groupSize == 0 ? [separator, $0.element] : [$0.element]
       }.joined().dropFirst())
    }
}

extension PaymentScreenVC: UITextFieldDelegate {
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        guard let currentText = (textField.text as NSString?)?.replacingCharacters(in: range, with: string) else { return true }
        
        if textField == self.TF_expiry {
            
            if textField.allow_MaxCharacters(limit: 9, shouldChangeCharactersIn: range, replacementString: currentText) {
                textField.text = currentText.grouping(every: 2, with: "/")
                return false
            }else {
                return false
            }
            
        }else if textField == self.TF_cardNumber {
            
            
            textField.text = currentText.grouping(every: 4, with: " ")
            return false
        }

        return true
    }
    
    /*
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let oldText = textField.text, let r = Range(range, in: oldText) else {
            return true
        }
        let updatedText = oldText.replacingCharacters(in: r, with: string)

        if string == "" {
            if updatedText.count == 2 {
                textField.text = "\(updatedText.prefix(1))"
                return false
            }
        } else if updatedText.count == 1 {
            if Int(updatedText)! > 12 {
                return false
            }
        } else if updatedText.count == 2 {
            if updatedText <= "12" { //Prevent user to not enter month more than 12
                textField.text = "\(updatedText)/" //This will add "/" when user enters 2nd digit of month
            }
            return false
        } else if updatedText.count == 5 {
            self.expDateValidation(dateStr: updatedText)
        } else if updatedText.count > 5 {
            return false
        }

        return true
    }
    
    func expDateValidation(dateStr:String) {

        let currentYear = Calendar.current.component(.year, from: Date()) % 100   // This will give you current year (i.e. if 2019 then it will be 19)
        let currentMonth = Calendar.current.component(.month, from: Date()) // This will give you current month (i.e if June then it will be 6)

        let enteredYear = Int(dateStr.suffix(2)) ?? 0 // get last two digit from entered string as year
        let enteredMonth = Int(dateStr.prefix(2)) ?? 0 // get first two digit from entered string as month
        print(dateStr) // This is MM/YY Entered by user

        if enteredYear > currentYear {
            if (1 ... 12).contains(enteredMonth) {
                print("Entered Date Is Right")
            } else {
                print("Entered Date Is Wrong")
            }
        } else if currentYear == enteredYear {
            if enteredMonth >= currentMonth {
                if (1 ... 12).contains(enteredMonth) {
                   print("Entered Date Is Right")
                } else {
                   print("Entered Date Is Wrong")
                }
            } else {
                print("Entered Date Is Wrong")
            }
        } else {
           print("Entered Date Is Wrong")
        }

    }
    
    */
}


