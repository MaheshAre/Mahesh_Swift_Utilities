//
//  UIColor+Extension.swift


import Foundation
import UIKit

extension UIColor {
    
    func color_theme() -> UIColor {
        return UIColor(red: 0.0392, green: 0.0157, blue: 0.2941, alpha: 1)
    }
    
    func color_groupedTV() -> UIColor {
        return UIColor(red: 0.9490, green: 0.9490, blue: 0.9490, alpha: 1)
    }
    
    func blue_Gradient_top() -> UIColor {
        
        return UIColor().get_UIColor_FromHex(hex: "02d6bb")
    }
    
    func blue_gradient_bottom() -> UIColor {
        return UIColor().get_UIColor_FromHex(hex: "0b56d1")
    }
    
    func orange_Gradient_top() -> UIColor {
        
        return UIColor().get_UIColor_FromHex(hex: "feb200")
    }
    
    func orange_gradient_bottom() -> UIColor {
        return UIColor().get_UIColor_FromHex(hex: "f67101")
    }
    
    func get_UIColor_FromHex (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt64 = 0
        Scanner(string: cString).scanHexInt64(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}
