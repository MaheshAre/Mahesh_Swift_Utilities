//
//  AppDelegate+Extension.swift

import Foundation
import UIKit

import NotificationCenter
import UserNotifications

var notificationData = NotificationDataStruct()
var notification_default = Notification_defaultStruct()

var device_token = ""

var notificationsGratnted = false

/*
 Call this Functions in DidFinish in AppDelegate
 
// UNUserNotificationCenterDelegate
 */




extension AppDelegate {
    
    static func getDelegate() -> AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }
    
}


//MARK:- APNS Push Notifications

extension AppDelegate {
    
    // Call this Function in AppDelegate
    
    func register_APNS() {
        
        UIApplication.shared.registerForRemoteNotifications()
        
        let center = UNUserNotificationCenter.current()
        center.delegate = self //DID NOT WORK WHEN self WAS MyOtherDelegateClass()
        
        center.requestAuthorization(options: [.alert, .sound, .badge]) {
            (granted, error) in
            // Enable or disable features based on authorization.
            if granted {
                // update application settings
                notificationsGratnted = true
            }else {
                print("Notifications Permission Not Granted")
                notificationsGratnted = false
            }
        }
        
        registerForPushNotifications()
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification data: [AnyHashable : Any]) {
        // Print notification payload data
       
        
        let aps = data[AnyHashable("aps")]!
        
        print(aps)
        
       
    }
    /*
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive: UNNotificationResponse,
                                withCompletionHandler: @escaping ()->()) {
      let actions = didReceive.actionIdentifier
      
      switch actions {
      case "Accept":
          print("Accept selected")
      default:
          break
      }
      
        withCompletionHandler()
    }
    */
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
         
    
      }
    
    /** Register for remote notifications to get an APNs token to use for registration to GCM */
    func registerForRemoteNotifications(_ application: UIApplication) {
        if #available(iOS 8.0, *) {
            let settings: UIUserNotificationSettings =
                UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
            application.registerUserNotificationSettings(settings)
            application.registerForRemoteNotifications()
        } else {
            // Fallback
            let types: UIRemoteNotificationType = [.alert, .badge, .sound]
            application.registerForRemoteNotifications(matching: types)
        }
        
        
        if #available(iOS 10.0, *) {
            // For iOS 10 display notification (sent via APNS)
            UNUserNotificationCenter.current().delegate = self
            
            let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
            UNUserNotificationCenter.current().requestAuthorization(
                options: authOptions,
                completionHandler: {_, _ in })
        } else {
            let settings: UIUserNotificationSettings =
                UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
            application.registerUserNotificationSettings(settings)
        }
        
        application.registerForRemoteNotifications()
        
    }
    
    func registerForPushNotifications() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) {
            (granted, error) in
           
            
            guard granted else { return }
            self.getNotificationSettings()
        }
    }
    
    func getNotificationSettings() {
        UNUserNotificationCenter.current().getNotificationSettings { (settings) in
         
            guard settings.authorizationStatus == .authorized else { return }
            DispatchQueue.main.async(execute: {
                UIApplication.shared.registerForRemoteNotifications()
            })
        }
    }
    
    func application(_ application: UIApplication,
                     didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        let tokenParts = deviceToken.map { data -> String in
            return String(format: "%02.2hhx", data)
        }
        
        device_token = tokenParts.joined()
        
        print("\n Device Token -> \(device_token) \n")
       
    }
    
    func application(_ application: UIApplication,
                     didFailToRegisterForRemoteNotificationsWithError error: Error) {
        
    }
    
    func showPermissionAlert() {
        
        let alert = UIAlertController(title: "WARNING", message: "Please enable access to Notifications in the Settings app.", preferredStyle: .alert)
        let settingsAction = UIAlertAction(title: "Settings", style: .default) {[weak self] (alertAction) in
            
            self?.gotoAppSettings()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        alert.addAction(settingsAction)
        alert.addAction(cancelAction)
        DispatchQueue.main.async {
            self.window?.rootViewController?.present(alert, animated: true, completion: nil)
        }
    }
    
    func gotoAppSettings() {
        guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
            return
        }
        if UIApplication.shared.canOpenURL(settingsUrl) {
            // UIApplication.shared.openURL(settingsUrl)
            UIApplication.shared.canOpenURL(settingsUrl)
        }
    }
    
    
    func navigationView(viewObj:UIViewController){
        
        let vc = UIApplication.getTopViewController()
        vc?.navigationController?.pushViewController(viewObj, animated: true)
        
        
        /*
         let storyboard = UIStoryboard(name: "Main", bundle: nil)
         let optionObj = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController // HomeViewController
         let rearViewController = storyboard.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
         let frontNavigationController = UINavigationController(rootViewController: optionObj)
         frontNavigationController.disableSwipeBack()
         let revealController = storyboard.instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
         revealController.rearViewController = rearViewController
         revealController.frontViewController = frontNavigationController
         self.window?.rootViewController = revealController
         frontNavigationController.pushViewController(viewObj, animated: true)
         
         */
        
        /*
         
         let storyboard = UIStoryboard(name: "Main", bundle: nil)
         
         let tabBar:UITabBarController = self.window?.rootViewController as! HomeTabBarVC //or whatever your way of getting reference is
         let navInTab:UINavigationController = tabBar.viewControllers?[3] as! UINavigationController
         let destinationViewController = viewObj
         navInTab.pushViewController(destinationViewController, animated: true)
         
         */
        
        //        let optionObj = storyboard.instantiateViewController(withIdentifier: "HomeTabBarVC") as! HomeTabBarVC // HomeViewController
        //        optionObj.selectedIndex = 3
        //        let navVC = UINavigationController(rootViewController: optionObj)
        //        self.window?.rootViewController = optionObj
        //        navVC.pushViewController(viewObj, animated: true)
    }

}

extension AppDelegate: UNUserNotificationCenterDelegate {
    
    /*
    
     func registerForPushNotifications() {
        if #available(iOS 10.0, *) {
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) {
                [weak self] (granted, error) in
                print("Permission granted: \(granted)")
                guard granted else {
                    print("Please enable \"Notifications\" from App Settings.")
                    
                    self?.showPermissionAlert()
                    return
                }
                self?.getNotificationSettings()
            }
        } else {
            let settings = UIUserNotificationSettings(types: [.alert, .sound, .badge], categories: nil)
            UIApplication.shared.registerUserNotificationSettings(settings)
            UIApplication.shared.registerForRemoteNotifications()
        }
    }
    
    @available(iOS 10.0, *)
    func getNotificationSettings() {
        UNUserNotificationCenter.current().getNotificationSettings { (settings) in
            print("Notification settings: \(settings)")
            guard settings.authorizationStatus == .authorized else { return }
            
            DispatchQueue.main.async {
                UIApplication.shared.registerForRemoteNotifications()
            }
        }
    }
    
    */
    func application(application: UIApplication, didReceiveRemoteNotification userInfo: [NSObject : AnyObject], fetchCompletionHandler completionHandler: (UIBackgroundFetchResult) -> Void) {
        
        print(userInfo)
        
    }
    
    
    @available(iOS 10.0, *)
    
    func userNotificationCenter(_ center: UNUserNotificationCenter,  willPresent notification: UNNotification, withCompletionHandler   completionHandler: @escaping (_ options:   UNNotificationPresentationOptions) -> Void) {
        
        //Called when a notification is delivered to a foreground app.
        completionHandler([.alert, .badge, .sound])
        
        let userInfo = notification.request.content.userInfo as? [String: Any]
        
        print("userinfo dict is \(String(describing: userInfo))")
        
        // cancel_user
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let userInfo = response.notification.request.content.userInfo as? [String: Any]
        
        self.notificationDataAssignToStruct(dict: userInfo)
        
        print("type --> \(String(describing: notificationData.type))")
        
        if notificationData.type == "new_request" {
            
//            PlaySong.shared.playSound(songName: "Ring_Reggae", type: "mp3")
            
        }
                
        // notificationData.type == "user_cancel_ride"
    }
    
    @available(iOS 10.0, *)
    
    internal func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        
        
        // Called to let your app know which action was selected by the user for a given notification.
        
        UIApplication.shared.applicationIconBadgeNumber = 0
                
        let userInfo = response.notification.request.content.userInfo as? [String: Any]
        
        self.notificationDataAssignToStruct(dict: userInfo)
        
        /*
         print(PushNotificationStruct(userInfo).title)
         print(PushNotificationStruct(userInfo).body)
         
         */
        
        let type = ""

        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        if notificationData.type == "new_request" {

            /*
            
            let optionObj = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
            optionObj.isCommingFrom_newRequest = true
            optionObj.order_id = notificationData.order_id!
            self.navigationView(viewObj: optionObj)
            
            */
            
        }
       
        print("type -->\(type)")
        // open_payment_screen
        /*
        
        let optionObj = storyboard.instantiateViewController(withIdentifier: "SelectLoactionVC") as! SelectLoactionVC // HomeViewController
        self.navigationView(viewObj: optionObj)
        
        */
    }
    
    func notificationDataAssignToStruct(dict: [String: Any]?) {
        
        if let data = dict {
            
            notificationData.user_id = data[BaseKey_pushNotification+"."+Enum_NotificationKeys.user_id.rawValue] as? String
            notificationData.message_id = data[BaseKey_pushNotification+"."+Enum_NotificationKeys.message_id.rawValue] as? String
            notificationData.amount = data[BaseKey_pushNotification+"."+Enum_NotificationKeys.amount.rawValue] as? String
            notificationData.type = data[BaseKey_pushNotification+"."+Enum_NotificationKeys.type.rawValue] as? String
            notificationData.order_id = data[BaseKey_pushNotification+"."+Enum_NotificationKeys.order_id.rawValue] as? String
            notificationData.rider_id = data[BaseKey_pushNotification+"."+Enum_NotificationKeys.rider_id.rawValue] as? String
            
            let aps = data["aps"] as? [String: Any]
            let alertDict = aps!["alert"] as? [String: Any]
            notification_default.title = alertDict!["title"] as? String
            notification_default.body = alertDict!["body"] as? String
        }
    }
}


enum Enum_Device: String {
    case device_token
    case FCM_token
    case UDID
}

struct Notification_defaultStruct {
    
    var title: String?
    var body: String?
}

struct NotificationDataStruct {
    
    var user_id: String?
    var message_id: String?
    var amount: String?
    var type: String?
    var order_id: String?
    var rider_id: String?
}

var BaseKey_pushNotification = "gcm.notification"

enum Enum_NotificationKeys: String {
    
    case user_id
    case message_id
    case amount
    case type
    case order_id
    case rider_id
}

struct Device {
    
    static func get_UDID() -> String {
        return UIDevice.current.identifierForVendor!.uuidString
    }
    static func get_FCM_token() -> String {
        if let fcmToken = user_Defaults.value(forKey: Enum_Device.FCM_token.rawValue) as? String {
            return fcmToken
        }else {
            return "123"
        }
    }
}
