//
//  HomeVC.swift
//  Chooz
//
//  Created by volivesolutions on 15/10/20.
//  Copyright © 2020 mappleBrain. All rights reserved.
//

/*

import UIKit
import SideMenu
import BubbleShowCase

var isFromFirstTime = true

class HomeVC: UIViewController {
    
    @IBOutlet weak var view_main: UIView!
    @IBOutlet weak var view_choozProfile: UIView!
    @IBOutlet weak var view_chozen: UIView!
    @IBOutlet weak var view_account: UIView!
        
//    @IBOutlet weak var lbl_contentProfile: UILabel!
//    @IBOutlet weak var lbl_contentChozen: UILabel!
//    @IBOutlet weak var lbl_contentAccount: UILabel!
    
    
        
    //MARK:- ViewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if isFromFirstTime {
            
            self.display_showCase()
        }
        
        
    }
}

extension HomeVC {
    
    func display_showCase() {
        
        let showCase_questions = self.get_showCase(showCase_setting: ShowCase_settings(view: self.view_choozProfile, title: "Questions", description: "You can submit the Questions"))
        let showCase_profiles = self.get_showCase(showCase_setting: ShowCase_settings(view: self.view_chozen, title: "Profiles", description: "You can get Profiles matched"))
        let showCase_account = self.get_showCase(showCase_setting: ShowCase_settings(view: self.view_account, title: "Acount", description: "You can go to Profile"))
        
        showCase_profiles.concat(bubbleShowCase: showCase_account)
        showCase_questions.concat(bubbleShowCase: showCase_profiles)
        showCase_questions.show()

    }
    
}

extension UIViewController {
    
    func get_showCase(showCase_setting: ShowCase_settings) -> BubbleShowCase {
        
        let showCase = BubbleShowCase(target: showCase_setting.view, arrowDirection: .down)
        showCase.titleText = showCase_setting.title
        showCase.descriptionText = showCase_setting.description
        //            showCase_main.show()
        
        return showCase
        
    }
    
}
 
 extension UICollectionViewCell {
     
     func get_showCase(showCase_setting: ShowCase_settings) -> BubbleShowCase {
         
         let showCase = BubbleShowCase(cell: self, target: nil, arrowDirection: .up)
         showCase.titleText = showCase_setting.title
         showCase.descriptionText = showCase_setting.description
         //            showCase_main.show()
         
         return showCase
         
         
     }
         
 }
 
 extension UITableViewCell {
     
     func get_showCase(showCase_setting: ShowCase_settings) -> BubbleShowCase {
         
         let showCase = BubbleShowCase(cell: self, target: nil, arrowDirection: .up)
         showCase.titleText = showCase_setting.title
         showCase.descriptionText = showCase_setting.description
         //            showCase_main.show()
         
         return showCase
         
     }
     
 }
 
 struct ShowCase_settings {
     
     var view = UIView()
     var title = ""
     var description = ""
 }

*/
