//
//  Date+Extension.swift


import Foundation

extension Date {
    
    func getDateStr_FromString(dateString: String, _ inputFormat: String = "yyyy-MM-dd HH:mm:ss", requiredFormat: String = "MMM-dd-YYYY, HH:mm a") -> String {
        
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = inputFormat
        let date = dateFormatter.date(from: dateString)
        
        dateFormatter.dateFormat = requiredFormat
        let convertedDateStr = dateFormatter.string(from: date!)
        
        return convertedDateStr
    }
    
    func getDate_FromString(dateString: String, _ inputFormat: String = "yyyy-MM-dd HH:mm:ss", requiredFormat: String = "yyyy-MM-dd HH:mm:ss") -> Date {
        
        var localTimeZoneAbbreviation: String {
            return TimeZone.current.abbreviation() ?? ""
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = inputFormat
        dateFormatter.timeZone = TimeZone.current
        var date = dateFormatter.date(from: dateString)
        
        var dateStr = dateFormatter.string(from: date!)
        date = dateFormatter.date(from: dateStr)
        
        dateFormatter.dateFormat = requiredFormat
        dateStr = dateFormatter.string(from: date!)
        let convertedDate = dateFormatter.date(from: dateStr)
        
        return convertedDate!
        
    }
    
    func getDate_FromDate(date: Date, _ inputFormat: String = "yyyy-MM-dd HH:mm:ss Z", requiredFormat: String = "MMM-dd-yyyy HH:mm:ss") -> Date {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = inputFormat
        dateFormatter.timeZone = TimeZone.current
        var dateStr = dateFormatter.string(from: date)
        let date = dateFormatter.date(from: dateStr)
        
        dateFormatter.dateFormat = requiredFormat
        dateStr = dateFormatter.string(from: date!)
        let convertedDate = dateFormatter.date(from: dateStr)
        
        return convertedDate!
    }
    
    func getDateStr_FromDate(date: Date, _ inputFormat: String = "yyyy-MM-dd HH:mm:ss Z", requiredFormat: String = "MMM-dd-yyyy hh:mm a") -> String {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = inputFormat
        dateFormatter.timeZone = TimeZone.current
        var dateStr = dateFormatter.string(from: date)
        let date = dateFormatter.date(from: dateStr)
        
        dateFormatter.dateFormat = requiredFormat
        dateStr = dateFormatter.string(from: date!)
        
        return dateStr
    }
    
    
    func get_CurrentDate() -> Date {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let timeZone = TimeZone.current
//        let timeZone = TimeZone(abbreviation: "GMT+5:30")
//        let timeZone = NSTimeZone(name: "UTC")
        dateFormatter.timeZone = timeZone
        let dateStr = dateFormatter.string(from: self)
        
        let date = self.getDate_FromString(dateString: dateStr, "yyyy-MM-dd HH:mm:ss", requiredFormat: "yyyy-MM-dd HH:mm:ss")
        
        return date
    }
    
    func dateByAddingYears(_ dYears: Int) -> Date {
        
        var dateComponents = DateComponents()
        dateComponents.year = dYears
        
        return Calendar.current.date(byAdding: dateComponents, to: self)!
    }
    
    func getYearAgeCalculation(from date: Date) -> Int {
        
        return Calendar.current.dateComponents([.year], from: date, to: self).year ?? 0
    }
    
    
    func interval(ofComponent comp: Calendar.Component, fromDate dateStr: String) -> Int {
        
        let dateFromatter = DateFormatter()
        let date = dateFromatter.date(from: dateStr)
        
        let currentCalendar = Calendar.current
        
        guard let start = currentCalendar.ordinality(of: comp, in: .era, for: date!) else { return 0 }
        guard let end = currentCalendar.ordinality(of: comp, in: .era, for: self) else { return 0 }
        
        return end - start
    }
    
    func minutesBetweenDates(_ oldDate: Date, _ newDate: Date) -> CGFloat {
        
        //get both times sinces refrenced date and divide by 60 to get minutes
        let newDateMinutes = newDate.timeIntervalSinceReferenceDate/60
        let oldDateMinutes = oldDate.timeIntervalSinceReferenceDate/60
        
        //then return the difference
        return CGFloat(newDateMinutes - oldDateMinutes)
    }
    
    func getDateDifference(fromDate: Date, toDate: Date) -> String {
        
        let formatter = DateComponentsFormatter()
        formatter.allowedUnits = [.hour, .minute, .second]
        let difference = formatter.string(from: fromDate, to: toDate)
        
        return difference ?? "0"
    }
    
    func get_timeSinceAgoDate(_ higherDate:Date,currentDate:Date, numericDates:Bool) -> String {
        
        let calendar = Calendar.current
        let now = currentDate
        let earliest = (now as NSDate).earlierDate(higherDate)
        let latest = (earliest == now) ? higherDate : now
        let components:DateComponents = (calendar as NSCalendar).components([NSCalendar.Unit.minute , NSCalendar.Unit.hour , NSCalendar.Unit.day , NSCalendar.Unit.weekOfYear , NSCalendar.Unit.month , NSCalendar.Unit.year , NSCalendar.Unit.second], from: earliest, to: latest, options: NSCalendar.Options())
        
        if (components.year! >= 2) {
            return "\(components.year!) years ago"
        } else if (components.year! >= 1){
            if (numericDates){
                return "1 \(Enum_Calendar.year.rawValue) ago"
            } else {
                return "Last \(Enum_Calendar.year.rawValue)"
            }
        } else if (components.month! >= 2) {
            return "\(components.month!) \(Enum_Calendar.months.rawValue)) ago"
        } else if (components.month! >= 1){
            if (numericDates){
                return "1 \(Enum_Calendar.month.rawValue) ago"
            } else {
                return "Last \(Enum_Calendar.month.rawValue)"
            }
        } else if (components.weekOfYear! >= 2) {
            return "\(components.weekOfYear!) \(Enum_Calendar.weeks.rawValue) ago"
        } else if (components.weekOfYear! >= 1){
            if (numericDates){
                return "1 \(Enum_Calendar.weeks.rawValue) ago"
            } else {
                return "Last \(Enum_Calendar.week.rawValue)"
            }
        } else if (components.day! >= 2) {
            return "\(components.day!) \(Enum_Calendar.days.rawValue) ago"
        } else if (components.day! >= 1){
            if (numericDates){
                return "1 \(Enum_Calendar.day.rawValue) ago"
            } else {
                return "Yesterday"
            }
        } else if (components.hour! >= 2) {
            return "\(components.hour!) \(Enum_Calendar.hours.rawValue) ago"
        } else if (components.hour! >= 1){
            if (numericDates){
                return "1 \(Enum_Calendar.hour.rawValue) ago"
            } else {
                return "An \(Enum_Calendar.hour.rawValue) ago"
            }
        } else if (components.minute! >= 2) {
            return "\(components.minute!) \(Enum_Calendar.minutes.rawValue) ago"
        } else if (components.minute! >= 1){
            if (numericDates){
                return "1 \(Enum_Calendar.minute.rawValue) ago"
            } else {
                return "A \(Enum_Calendar.minute.rawValue) ago"
            }
        } else if (components.second! >= 3) {
            return "\(components.second!) \(Enum_Calendar.seconds.rawValue) ago"
        } else {
            return "Just now"
        }
        
    }
}


enum Enum_Calendar: String {
    
    case year
    case month
    case months
    case weeks
    case week
    case days
    case day
    case hours
    case hour
    case minutes
    case minute
    case seconds
    
    case ago
    
}

extension String {
    
    func convert_toDate(withFormat format: String = "yyyy-MM-dd HH:mm:ss") -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        dateFormatter.timeZone = TimeZone.current
        guard let date = dateFormatter.date(from: self) else {
            preconditionFailure("Take a look to your format")
        }
        return date
    }
}

//MARK:- Dates Comparision

extension Date {
    
    func isEqualTo_currentData(_ date: Date) -> Bool {
        return self == date
    }
    
    func isEqualTo(_ date: Date, comparingDate: Date) -> Bool {
        return comparingDate == date
    }
    
    func isGreaterThan_currentDate(_ date: Date) -> Bool {
        return date > self
    }
    
    func isGreaterThan(_ date: Date, comparingDate: Date) -> Bool {
        return comparingDate > date
    }
    
    func isGreaterThanEqual_currentDate(_ date: Date) -> Bool {
        return date >= self
    }
    
    func isGreaterThanEqual(_ date: Date, comparingDate: Date) -> Bool {
        return comparingDate >= date
    }
    
    func isLessallerThan_currentDate(_ date: Date) -> Bool {
        return date < self
    }
    
    func isLessallerThan(_ date: Date, comparingDate: Date) -> Bool {
        return comparingDate < date
    }
    
    func isLessallerThanEqual_currentDate(_ date: Date) -> Bool {
        return date <= self
    }
    
    func isLessallerThanEqual(_ date: Date, comparingDate: Date) -> Bool {
        return comparingDate <= date
    }
    
    
}
