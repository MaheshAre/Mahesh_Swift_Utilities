//
//  Loader.swift


import Foundation
import UIKit

struct Loader {
    
    static var shared = Loader()
    private init() { }
    
    func showLoder() {
        ANLoader.showLoading("", disableUI: true)
    }
    
    func hideLoader() {
        ANLoader.hide()
    }
}
