//
//  PlayRingtone.swift


import Foundation
import AVFoundation

var player: AVAudioPlayer?

struct PlaySong {
        
    static var shared = PlaySong()
    private init() { }
    
    func playSound(songName: String, type: String) {
        
        let url = Bundle.main.url(forResource: songName, withExtension: type)!
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            guard let player = player else { return }
            
            player.prepareToPlay()
            player.play()
            
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+20) {
                // check if player is still playing
                if player.rate != 0 {
                    player.stop()
                }
            }
            
        } catch let error as NSError {
            print(error.description)
        }
    }
    
}
