//
//  Alert.swift

import Foundation
import UIKit

struct Alert {
    
    static let shared = Alert()
    private init() { }
    
    func showAlert(title: String, message: String, viewController: UIViewController)  {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
        alert.addAction(okAction)
        viewController.present(alert, animated: true, completion: nil)
    }
    
    
    func showAlert_twoActions(title: String, message: String, viewController: UIViewController)  {
     
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)

        let action_Ok = UIAlertAction(title: "Yes", style: .default) { (action) in
//            AppDelegate.getDelegate().gotoLoginVC()
        }
        let action_No = UIAlertAction.init(title: "No", style: .cancel, handler: nil)
     
        alert.addAction(action_No)
        alert.addAction(action_Ok)
        viewController.present(alert, animated: true, completion: nil)
    }
    

}

//struct Toast {
//
//    static let shared = Toast()
//    private init() { }
//
//    func ToastShort(message: String) {
//
////        let toast = MDToast(text: message, duration: TimeInterval(kMDToastDurationShort))
////        toast.show()
//    }
//}

