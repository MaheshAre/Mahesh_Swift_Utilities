//
//  ViewController.swift
//  ChartsDemo
//
//  Created by Apple on 30/03/20.
//  Copyright © 2020 Apple. All rights reserved.
//

import UIKit
import Charts

/*

pod 'Charts'

*/

class ViewController: UIViewController {
    
    @IBOutlet weak var chartView: PieChartView!
        
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.updateChartData()
        
    }
    
    
    func updateChartData()  {
            
            let title_array = ["Correct", "Wrong"]
            let values_array = [Double(self.testSubmit_resp.correct_percentage ?? "0.0"),
                                Double(self.testSubmit_resp.wrong_percentage ?? "0.0")]
            
    //        let chart = PieChartView(frame: self.chartView.frame)

            // 2. generate chart data entries
            
            var entries = [PieChartDataEntry]()
            for (index, value) in values_array.enumerated() {
                let entry = PieChartDataEntry()
                entry.y = value ?? 0.0
                entry.label = title_array[index]
                
                entries.append( entry)
            }
            
            // 3. chart setup
            let set = PieChartDataSet(entries: entries, label: "Total Performance")
            // this is custom extension method. Download the code for more details.
            let colors: [UIColor] = [.systemGreen, .systemRed]
            
            //        for _ in 0..<money.count {
            //            let red = Double(arc4random_uniform(256))
            //            let green = Double(arc4random_uniform(256))
            //            let blue = Double(arc4random_uniform(256))
            //            let color = UIColor(red: CGFloat(red/255), green: CGFloat(green/255), blue: CGFloat(blue/255), alpha: 1)
            //            colors.append(color)
            //        }
            
            
            set.colors = colors
            let data = PieChartData(dataSet: set)
            chartView.data = data
            chartView.noDataText = "No data available"
            // user interaction
            chartView.isUserInteractionEnabled = true
            
            let d = Description()
            d.text = ""
            chartView.chartDescription = d
            chartView.centerText = "Total Performance \n \(self.testSubmit_resp.correct_answer_count ?? 0)/\(self.total_questions_count)"
            
            chartView.holeRadiusPercent = 0.5
            chartView.transparentCircleColor = UIColor.clear
            
            
            let pFormatter = NumberFormatter()
            pFormatter.numberStyle = .percent
            pFormatter.maximumFractionDigits = 1
            pFormatter.multiplier = 1
            pFormatter.percentSymbol = " %"
            data.setValueFormatter(DefaultValueFormatter(formatter: pFormatter))
            
            data.setValueFont(.systemFont(ofSize: 14, weight: .semibold))
            data.setValueTextColor(.white)
            
            chartView.data = data
            chartView.highlightValues(nil)
            
            
    //        self.view.addSubview(chart)
            
        }
    
    override func viewDidAppear(_ animated: Bool) {
//        self.updateChartData()
    }

}
