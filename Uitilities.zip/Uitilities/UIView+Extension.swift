//
//  CustomView.swift


import Foundation
import UIKit


extension UIView {
    
    var getParentViewController: UIViewController? {
        var parentResponder: UIResponder? = self
        while parentResponder != nil {
            parentResponder = parentResponder!.next
            if let viewController = parentResponder as? UIViewController {
                return viewController
            }
        }
        return nil
    }
    
    /**
     Corner Radius
     */
    func cornerRadius(radius: CGFloat?, bwidth: CGFloat?, bColor: UIColor?) {
        
        self.layer.cornerRadius = radius ?? 0
        self.layer.masksToBounds = true
        self.layer.borderColor = bColor?.cgColor ?? UIColor.lightGray.cgColor
        layer.borderWidth = bwidth ?? 0
        
    }
    
    func cornerRadiusRound(bwidth: CGFloat?, bColor: UIColor?) {
        
        self.layer.cornerRadius = self.frame.size.width/2
        self.layer.masksToBounds = true
        self.layer.borderColor = bColor?.cgColor ?? UIColor.lightGray.cgColor
        layer.borderWidth = bwidth ?? 0
        
    }
    
    func cornerRadiusHeightByTwo(bwidth: CGFloat?, bColor: UIColor?) {
        
        self.layer.cornerRadius = self.frame.size.height/2
        self.layer.masksToBounds = true
        self.layer.borderColor = bColor?.cgColor ?? UIColor.lightGray.cgColor
        layer.borderWidth = bwidth ?? 0
        
    }
    
    func cornerRadiusWidthByTwo(bwidth: CGFloat?, bColor: UIColor?) {
        
        self.layer.cornerRadius = self.frame.size.width/2
        self.layer.masksToBounds = true
        self.layer.borderColor = bColor?.cgColor ?? UIColor.lightGray.cgColor
        layer.borderWidth = bwidth ?? 0
        
    }
    
    /**
     Call in this func viewWillLayoutSubviews()
     */
    
    func cornerRadius_usingSides(corners: UIRectCorner? = [.allCorners], radius: CGFloat) {
        
        let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners!, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        self.layer.mask = mask
    }
    
    func borderRadius(amount: Float) {
        return self.layer.borderWidth = CGFloat(amount)
    }
    
    func addBorder(_ edge: UIRectEdge, color: UIColor, thickness: CGFloat) {
        
        let subview = UIView()
        subview.translatesAutoresizingMaskIntoConstraints = false
        subview.backgroundColor = color
        self.addSubview(subview)
        
        switch edge {
        case .top, .bottom:
            subview.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 0).isActive = true
            subview.rightAnchor.constraint(equalTo: self.rightAnchor, constant: 0).isActive = true
            subview.heightAnchor.constraint(equalToConstant: thickness).isActive = true
            if edge == .top {
                subview.topAnchor.constraint(equalTo: self.topAnchor, constant: 0).isActive = true
            } else {
                subview.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 0).isActive = true
            }
        case .left, .right:
            subview.topAnchor.constraint(equalTo: self.topAnchor, constant: 0).isActive = true
            subview.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 0).isActive = true
            subview.widthAnchor.constraint(equalToConstant: thickness).isActive = true
            if edge == .left {
                subview.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 0).isActive = true
            } else {
                subview.rightAnchor.constraint(equalTo: self.rightAnchor, constant: 0).isActive = true
            }
        default:
            break
        }
    }
    
    //MARK:- Shadow
    //    func shadowSetup(shadowColor : UIColor?,shadowRadius : CGFloat) {
    //
    //        layer.masksToBounds = false
    //        if let shadowColor = shadowColor {
    //            layer.shadowColor = shadowColor.cgColor
    //        }else {
    //            layer.shadowColor = UIColor.lightGray.cgColor
    //        }
    //        layer.shadowOffset = CGSize(width: 0, height: 2.0)
    //        /*
    //             0 Left, Right Bottom
    //             1 Right & Bottom
    //             -1 Left & Bottom
    //            CGSize.zero for All Sides
    //        */
    //        layer.shadowOpacity = 1
    //        layer.shadowRadius = shadowRadius
    //
    //        // For View Radius
    //        self.layer.cornerRadius = shadowRadius
    //
    //    }
    
    
    func shadowApply(cornerRadiues: Float, shadowOpacityes: Float, shadowColors: UIColor?, shadowOffset: CGSize, borderWidth: Float? = 1.5){
        
        layer.masksToBounds = false
        self.layer.cornerRadius = CGFloat(cornerRadiues)
        
        self.layer.shadowOpacity = shadowOpacityes
        
        if let shadowColor = shadowColors {
            layer.shadowColor = shadowColor.cgColor
        }else {
            layer.shadowColor = UIColor.lightGray.cgColor
        }
        
        self.layer.shadowOffset = shadowOffset
    }
    
    func getConvertedPoint(_ targetView: UIView, baseView: UIView)->CGPoint{
        var pnt = targetView.frame.origin
        if nil == targetView.superview{
            return pnt
        }
        var superView = targetView.superview
        while superView != baseView{
            pnt = superView!.convert(pnt, to: superView!.superview)
            if nil == superView!.superview{
                break
            }else{
                superView = superView!.superview
            }
        }
        return superView!.convert(pnt, to: baseView)
    }
    
    func gradientColor_apply(firstColor: UIColor, secondColor: UIColor, isHorizontal: Bool) {
        
        let gradient: CAGradientLayer = CAGradientLayer()
        gradient.colors = [firstColor.cgColor, secondColor.cgColor]
        gradient.locations = [0.0 , 1.0]
        
        if isHorizontal {
            
            gradient.startPoint = CGPoint(x: 0.0, y: 1.0)
            gradient.endPoint = CGPoint(x: 1.0, y: 1.0)
        }else {
            
            gradient.startPoint = CGPoint(x: 0.0, y: 0.0)
            gradient.endPoint = CGPoint(x: 0.0, y: 1.0)
        }
        
        gradient.frame = CGRect(x: 0.0, y: 0.0, width: self.frame.size.width, height: self.frame.size.height)
        self.layer.addSublayer(gradient)
        //        self.layer.insertSublayer(gradient, below: gradient)
    }
    
    func addShadow(to edges: [UIRectEdge], radius: CGFloat = 3.0, opacity: Float? = 0.6, firstColor color: UIColor = .black, secondColor secColor: UIColor?) {
        
        let fromColor = color.cgColor
        let toColor = secColor ?? UIColor.clear //UIColor.clear.cgColor
        let viewFrame = self.frame
        
        for edge in edges {
            let gradientLayer = CAGradientLayer()
            gradientLayer.colors = [fromColor, toColor]
            gradientLayer.opacity = opacity ?? 0.6
            
            switch edge {
            case .top:
                gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
                gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
                gradientLayer.frame = CGRect(x: 0.0, y: 0.0, width: viewFrame.width, height: radius)
            case .bottom:
                gradientLayer.startPoint = CGPoint(x: 0.5, y: 1.0)
                gradientLayer.endPoint = CGPoint(x: 0.5, y: 0.0)
                gradientLayer.frame = CGRect(x: 0.0, y: viewFrame.height - radius, width: viewFrame.width, height: radius)
            case .left:
                gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
                gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
                gradientLayer.frame = CGRect(x: 0.0, y: 0.0, width: radius, height: viewFrame.height)
            case .right:
                gradientLayer.startPoint = CGPoint(x: 1.0, y: 0.5)
                gradientLayer.endPoint = CGPoint(x: 0.0, y: 0.5)
                gradientLayer.frame = CGRect(x: viewFrame.width - radius, y: 0.0, width: radius, height: viewFrame.height)
            default:
                break
            }
            self.layer.addSublayer(gradientLayer)
        }
    }
    
    func removeAllShadows() {
        if let sublayers = self.layer.sublayers, !sublayers.isEmpty {
            for sublayer in sublayers {
                sublayer.removeFromSuperlayer()
            }
        }
    }
    
    func rotate_view(angle: Float) {
        self.transform = CGAffineTransform(rotationAngle: CGFloat(angle))
    }
    
    func rotate360Degrees(duration: CFTimeInterval = 1.5) {
        
        let rotateAnimation = CABasicAnimation(keyPath: "transform.rotation")
        rotateAnimation.fromValue = 0.0
        rotateAnimation.toValue = CGFloat(Double.pi * 2)
        rotateAnimation.isRemovedOnCompletion = false
        rotateAnimation.duration = duration
        rotateAnimation.repeatCount=Float.infinity
        self.layer.add(rotateAnimation, forKey: nil)
    }
    
}

extension UIButton {
    
    func btn_enable(isEnable: Bool) {
        
        if isEnable {
            self.alpha = 1.0
            self.isEnabled = true
        }else {
            self.alpha = 0.5
            self.isEnabled = false
        }
    }
    func setAttributed_title(title: String, titleColor: UIColor) {
        
        let mySelectedAttributedTitle = NSAttributedString(string: title,
                                                           attributes: [NSAttributedString.Key.foregroundColor : titleColor,
                                                                        NSAttributedString.Key.underlineStyle: 1.0])
        self.setAttributedTitle(mySelectedAttributedTitle, for: .normal)
    }
}


@IBDesignable class SelCardView: UIView {

    @IBInspectable var BorderColor: UIColor? {
        set {
            layer.borderColor = (newValue?.cgColor)!
        }
        get {

            if let color = layer.borderColor {

                return UIColor(cgColor:color)

            }else {
                return nil
            }
        }

    }
    @IBInspectable var BorderWidth: CGFloat {

        set {
            layer.borderWidth = newValue

        }
        get {
            let width = layer.borderWidth

            if width != 0 {
                return width
            }else {
                return 0
            }
        }

    }

    @IBInspectable var ShadowColor: UIColor? {

        set {

            layer.borderColor = (newValue?.cgColor)!
            layer.shadowRadius = layer.shadowRadius == 0 ? 2 : layer.shadowRadius
            layer.shadowOffset = CGSize.zero
            layer.shadowOpacity = 0.3
        }

        get {
            if let color = layer.borderColor {
                return UIColor(cgColor:color)
            }else {

                return nil
            }
        }
    }

    @IBInspectable var ShadowRadius: CGFloat {

        set {
            layer.shadowRadius = newValue
            layer.shadowOffset = CGSize.zero
            if (layer.shadowColor == nil) {
                layer.shadowColor = UIColor.black.cgColor
            }
            layer.shadowOpacity = 0.25

        }

        get {
            return layer.shadowRadius
        }

    }

    @IBInspectable var CornerRadiusMulti: CGFloat {

        set {
            layer.cornerRadius = frame.height / newValue

        }
        get {
            return layer.cornerRadius
        }
    }

    @IBInspectable var CornerRadius: CGFloat {
        set {
            layer.cornerRadius = newValue
        }
        get {
            return layer.cornerRadius
        }
    }

    @IBInspectable var CornerRadiusFolLeft: CGFloat {
        set {
            layer.cornerRadius = newValue
        }
        get {
            return layer.cornerRadius
        }
    }
}
