//
//  Extensions.swift


import Foundation
import UIKit

extension String {
    
    func strikedStr() -> NSAttributedString {
        let attributeString =  NSMutableAttributedString(string: self)
        attributeString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: NSUnderlineStyle.single.rawValue, range: NSMakeRange(0,attributeString.length))
        return attributeString
    }
    
    func attributedStringColor(mainString: String, string_to_color: String, changeColor: UIColor) -> NSAttributedString{
        
        let range = (mainString as NSString).range(of: string_to_color)
        
        let attribute = NSMutableAttributedString.init(string: mainString)

        attribute.addAttribute(NSAttributedString.Key.foregroundColor, value: changeColor, range: range)
        
        return attribute
    }
    
    func compare_ignoreCase(string:String) -> Bool {
      return self.uppercased() == string.uppercased()
    }
    
    func randomString(length: Int) -> String {
        let letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return String((0..<length).map{ _ in letters.randomElement()! })
    }
    
    func estimatedFrame(font: UIFont = UIFont.boldSystemFont(ofSize: 18)) -> CGRect {
        let size = CGSize(width: 200, height: 1000) // temporary size
        let options = NSStringDrawingOptions.usesFontLeading.union(.usesLineFragmentOrigin)
        return NSString(string: self+"  ").boundingRect(with: size,
                                                   options: options,
                                                   attributes: [NSAttributedString.Key.font: font],
                                                   context: nil)
    }
    
    func labelSizeWithString(fontSize: CGFloat, maxWidth : CGFloat,numberOfLines: Int) -> CGRect{

        let font = UIFont.systemFont(ofSize: fontSize)//(name: "HelveticaNeue", size: fontSize)!
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: maxWidth, height: .greatestFiniteMagnitude))
        label.numberOfLines = numberOfLines
        label.font = font
        label.text = " " + self + " "

        label.sizeToFit()

        return label.frame
    }
    
    //MARK:- Sentence Case
    /*
    func capitalizingFirstLetter() -> String {
        return prefix(1).uppercased() + self.lowercased().dropFirst()
    }
    
    mutating func capitalizeFirstLetter() {
        self = self.capitalizingFirstLetter()
    }
    */
    
    //MARK:- Base64 Conversion
    
    func getBase64Str(image: UIImage) -> String {
        
        //Now use image to create into NSData format
        let imageData = image.pngData()
        if let imgData = imageData {
            let strBase64:String = imgData.base64EncodedString(options: .lineLength64Characters)
            return strBase64
        }
        //imageData.base64EncodedStringWithOptions(.Encoding64CharacterLineLength)
        return ""
    }

}

extension StringProtocol {
    var firstUppercased: String {
        return prefix(1).uppercased() + dropFirst()
    }
    var firstCapitalized: String {
        return String(prefix(1)).capitalized + dropFirst()
    }
}

extension NSAttributedString {
    
    func strikedStr(string: String){
        
        let attributeString: NSMutableAttributedString = NSMutableAttributedString(string: string); attributeString.addAttribute(NSAttributedString.Key.strikethroughStyle, value: 2, range: NSMakeRange(0, attributeString.length))
        
        //        return attributeString
    }
}

extension Data {
    var html2AttributedString: NSAttributedString? {
        do {
            return try NSAttributedString(data: self, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding: String.Encoding.utf8.rawValue], documentAttributes: nil)
        } catch {
            print("error:", error)
            return  nil
        }
    }
    var html2String: String {
        return html2AttributedString?.string ?? ""
    }
}

extension String {
    var html2AttributedString: NSAttributedString? {
        return Data(utf8).html2AttributedString
    }
    var html2String: String {
        return html2AttributedString?.string ?? ""
    }
}

//MARK:- Double Formatter
extension Double {
    
    func doubleFromat_str(format: String) -> String {
        return String(format: "%.\(format)f", self)
    }
    
    func doubleFormat_double(format: String) -> Double {
        let str = String(format: "%.\(format)f", self)
        let doubleValue = Double(str)
        return doubleValue ?? 0.0
    }
}


extension String {
    
    func convertStrToDictionary() -> [String: Any]? {
        if let data = self.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
}
