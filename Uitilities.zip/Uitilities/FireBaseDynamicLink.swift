//
//  FireBaseDynamicLink.swift
//  Chooz
//
//  Created by Apple on 12/11/20.
//  Copyright © 2020 mappleBrain. All rights reserved.
//

//MARK:- FireBase Dynamic Link

import Firebase
import FirebaseDynamicLinks

/*
 pod 'Firebase/Analytics'
 pod 'Firebase/DynamicLinks'
 
 Call In SceneDelegate
 FirebaseApp.configure()
 */

extension UIViewController {
    
    func fireBase_dynamicLinkGenerate(partner_userID: String, onCompletion: @escaping (_ urlString: String)->Void) {
        
        let firebase_link = "choozapp.page.link"
        
        var components = URLComponents()
        components.scheme = "https"
        components.host = firebase_link
        //components.path = "/"x
        
        let shareQueryItem = URLQueryItem(name: "user_id", value: partner_userID)
        components.queryItems=[shareQueryItem]
        
        guard let linkParams = components.url else {return}
        print("link Params: \(linkParams.absoluteString)")
        
        // create long dynamic link
        
        let shareLink = DynamicLinkComponents.init(link: linkParams, domainURIPrefix: "https://\(firebase_link)")
        
        let bundle_id = self.get_bundleID()
        
        shareLink?.iOSParameters = DynamicLinkIOSParameters(bundleID: bundle_id)
        /**
         Appstore Apple ID from Appstore Connect
         */
        shareLink?.iOSParameters?.appStoreID = "" //"1537059850"
        /**
         Android Package id
         */
        shareLink?.androidParameters = DynamicLinkAndroidParameters(packageName: "") // "com.zoconut.fitmantra"
        shareLink?.socialMetaTagParameters = DynamicLinkSocialMetaTagParameters()
        
        shareLink?.socialMetaTagParameters?.title = "Join \(appTitle)"
        shareLink?.socialMetaTagParameters?.descriptionText = "Chooz your Partner"
        shareLink?.socialMetaTagParameters?.imageURL = URL(string: "https://demomaplebrains.com/chooz_dev/assets/uploads/user_profiles/noimage.png") // Put Here Logo URL
        
        guard let longUrl = shareLink?.url else {
            return
        }
        
//        print("long url: \(longUrl)")
        
        CustomSKIndicator.shared.showSKIndicatorSpinner(statusMessage: "")
        
        shareLink?.shorten { (shortUrl, warns, err) in
            
            SKActivityIndicator.dismiss()
            
            if let errr = err{print(errr)}
            if let warnings = warns{
                print(warnings)
            }
            guard let smallUrl = shortUrl else{
                return
            }
//            print(smallUrl)

//            let share_str = "Hey,i am enjoying getting fit with \(clinic) Join me using my code: \(refCode) or Click link here: \n\n\(smallUrl)"
//            let avc = UIActivityViewController(activityItems: [share_str] as [Any], applicationActivities: nil)
//            self.present(avc, animated: true, completion: nil)
            
            onCompletion(smallUrl.absoluteString)
        }
    }
}


extension AppDelegate {
    
    
    func application(_ application: UIApplication, continue userActivity: NSUserActivity, restorationHandler: @escaping ([UIUserActivityRestoring]?) -> Void) -> Bool {
        if let urlLink = userActivity.webpageURL{
            print(urlLink)
            let linkHandle = DynamicLinks.dynamicLinks().handleUniversalLink(urlLink) { (dynamicLink, err) in
                guard err == nil else{
                    return
                }
                if let dynamicLink1 = dynamicLink {
                    self.handleDynamikLink(dLink: dynamicLink1)
                }
            }
            if linkHandle{return true}else{return false}
        }
        return true
       
    }
    
    
    /*
     
     // Call this Function in Appdelegate open URL
     
     if let dynamiLink = DynamicLinks.dynamicLinks().dynamicLink(fromCustomSchemeURL: url) {
         
         self.handleDynamikLink(dLink: dynamiLink)
     }
    
    */
    
    func handleDynamikLink(dLink: DynamicLink) {
        
        if let queryUrl = dLink.url{
            if let urlStr = queryUrl.query{
                print("queryURL : \(urlStr)")
                let urlStrArr = urlStr.split(separator: "=")
                print("User ID :\(urlStrArr[1])")
                
                deepLink_userID = String(urlStrArr[1])
                
                if let loginStatus = user_Defaults.value(forKey: Enum_UserData.isLoggedIn.rawValue) as? Bool {
                    if loginStatus {
                        
                        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailsVC") as! DetailsVC
                        vc.isFromComming = .forProfileDetails
                        UIApplication.getTopViewController()?.navigationController?.pushViewController(vc, animated: true)
                    }else {
                        
                        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
                        vc.isForComming = .forProfileDetails
                        UIApplication.getTopViewController()?.navigationController?.pushViewController(vc, animated: true)
                        //                let navVC = UINavigationController(rootViewController: vc)
                        //                navVC.disableSwipeBack()
                        //                self.window?.rootViewController = navVC
                        
                    }
                }
            }
        }
        
    }
}


extension SceneDelegate {
    
    @available(iOS 13.0, *)
    func scene(_ scene: UIScene, continue userActivity: NSUserActivity) {
        print("url: \(userActivity.webpageURL!)")
        
        if let urlLink = userActivity.webpageURL{
            print(urlLink)
            _ = DynamicLinks.dynamicLinks().handleUniversalLink(urlLink) { (dynamicLink, err) in
                guard err == nil else{
                    return
                }
                if let dynamicLink1 = dynamicLink {
                    AppDelegate.getDelegate().handleDynamikLink(dLink: dynamicLink1)
                }
            }
        }
    }
    
    @available(iOS 13.0, *)
    func call_FireBaseDynamicLinkIn_WillConnectSession(connectionOptions: UIScene.ConnectionOptions) {
        
        guard let userActivity = connectionOptions.userActivities.first(where: { $0.webpageURL != nil }) else { return }
        
        if let urlLink = userActivity.webpageURL{
            print(urlLink)
            _ = DynamicLinks.dynamicLinks().handleUniversalLink(urlLink) { (dynamicLink, err) in
                guard err == nil else{
                    return
                }
                if let dynamicLink1 = dynamicLink {
                    AppDelegate.getDelegate().handleDynamikLink(dLink: dynamicLink1)
                }
            }
        }
    }
    
    @available(iOS 13.0, *)
    func call_OpenURLFor_FireBaseDynamicLink(URLContexts: Set<UIOpenURLContext>) {
        
        var dynamicURL: URL?
        for context in URLContexts {
            dynamicURL = context.url.absoluteURL
        }
        
        if let dynamiLink = DynamicLinks.dynamicLinks().dynamicLink(fromCustomSchemeURL: dynamicURL!) {
            AppDelegate.getDelegate().handleDynamikLink(dLink: dynamiLink)
        }
    }
}
