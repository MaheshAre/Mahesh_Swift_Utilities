//
//  TableView+Extension.swift


import Foundation
import UIKit

extension UITableView {
    
    func reloadDataWithCompletion(completion: @escaping ()->()) {
        UIView.animate(withDuration: 0, animations: { self.reloadData() })
        { _ in completion() }
    }
}


extension UITableView {
    
    func set_noDataFound(message: String) {
        
        let messageLabel = UILabel(frame: CGRect(x: 0, y: 0, width: self.bounds.size.width, height: self.bounds.size.height))
        messageLabel.text = message
        messageLabel.textColor = .black
        messageLabel.numberOfLines = 0
        messageLabel.textAlignment = .center
        messageLabel.font = UIFont.boldSystemFont(ofSize: 18)
            //UIFont.systemFont(ofSize: 17) //UIFont(name: "HelveticaNeue-Regular", size: 17)
        messageLabel.sizeToFit()

        self.backgroundView = messageLabel
        self.separatorStyle = .none
    }
    
    func remove_noDataFound(needSeparator: Bool = true) {
        self.backgroundView = nil
        if needSeparator {
            self.separatorStyle = .singleLine
        }else {
            self.separatorStyle = .none
        }
        
    }
    
    func set_TableHeaderView(header: UIView) {
        
        header.autoresizingMask = .flexibleWidth
        header.translatesAutoresizingMaskIntoConstraints = true
        self.tableHeaderView = header
    }
}

/*
 
 DispatchQueue.main.async {
     
     self.TV_questions.reloadData()
 }
 
 
 func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {

     if indexPath.row == (tableView.indexPathsForVisibleRows!.last! as NSIndexPath).row {
         // End of loading
         let contentSize : CGSize = self.TV_questions.contentSize
         let height = self.TV_questions.contentSize.height

         self.height_TVQuestions.constant = height + 100
     }
 }
 */
