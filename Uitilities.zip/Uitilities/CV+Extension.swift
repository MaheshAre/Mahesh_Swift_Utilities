//
//  CV+Extension.swift


import Foundation

extension UICollectionView {
    
    func set_noDataFound(message: String) {
        
        let messageLabel = UILabel(frame: CGRect(x: 0, y: 0, width: self.bounds.size.width, height: self.bounds.size.height))
        messageLabel.text = message
        messageLabel.textColor = .black
        messageLabel.numberOfLines = 0
        messageLabel.textAlignment = .center
        messageLabel.font = UIFont.boldSystemFont(ofSize: 18)
            //UIFont.systemFont(ofSize: 17) //UIFont(name: "HelveticaNeue-Regular", size: 17)
        messageLabel.sizeToFit()

        self.backgroundView = messageLabel
    }
    
    func remove_noDataFound() {
        self.backgroundView = nil
    }
}




/*

For Flow Layout

extension CV_Extension: UICollectionViewDelegateFlowLayout {
    // Collection view flow layout setup
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: extension BannersTableViewCell: UICollectionViewDelegateFlowLayout {
        

        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            
            let frame = self.bannersCollection.frame
            let width = frame.width/1.5
            let height = frame.height

    // self.bannersCollection.frame.height-10
            return CGSize(width: width, height: height)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    
    // This is for space between cells in row
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    // This is for space between 1 row to another
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
}

*/


/*
 
 For Dynamic size of CV_Cell
 
 
 
 //MARK:- Functions
 
 func collectionViewFlowLayout(collectionView: UICollectionView) {
     
     let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
     layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
     layout.scrollDirection = .horizontal
     
     let frame = self.collectionView.frame
     let width = frame.width/1.5
     let height = frame.height
     //        let height = width
     //        layout.itemSize = UICollectionViewFlowLayout.automaticSize
     //        layout.estimatedItemSize = CGSize(width: (self.CV_items.frame.width/2)-5, height: 310)
     layout.itemSize = CGSize(width: width, height: height)
     layout.minimumInteritemSpacing = 0
     layout.minimumLineSpacing = 0
     
     collectionView.collectionViewLayout = layout
     
 }
 
     func collectionViewFlowLayout_Dynamic() {

         let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
         layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
 
         layout.itemSize = UICollectionViewFlowLayout.automaticSize
         layout.estimatedItemSize = CGSize(width: (self.CV_items.frame.width/2)-5, height: 310)
 

         self.CV_items.collectionViewLayout = layout

     }
 
 class CV_DynamicHeight: UICollectionViewCell {
     
     override func preferredLayoutAttributesFitting(_ layoutAttributes: UICollectionViewLayoutAttributes) -> UICollectionViewLayoutAttributes {
         setNeedsLayout()
         layoutIfNeeded()
         let size = contentView.systemLayoutSizeFitting(layoutAttributes.size)
         var newFrame = layoutAttributes.frame
         // note: don't change the width
         newFrame.size.height = ceil(size.height)
         layoutAttributes.frame = newFrame
         return layoutAttributes
     }

 }
 
 
 */


/**
 
 1. Assign this class to Collectionview in StoryBoard
 2. Take Collectionview Height and apply low priority
 3. In ViewWillAppear   self.CV.layoutIfNeeded()
 
 4. func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
       let text = self.driverImprovementsArr[indexPath.row]
      //  let customFont = UIFont(name: "Lato-Regular", size: 12.0)!
        //let cellWidth = text.size(withAttributes:[.font: UIFont.systemFont(ofSize:12.0)]).width + 30.0
     let cellWidth = text.size(withAttributes: [.font: UIFont(name: "Lato-Regular", size: 12.0)!]).width + 30.0
       return CGSize(width: cellWidth, height: 30.0)
 }
 
 
 */


class DynamicHeightCollectionView: UICollectionView {
    override func layoutSubviews() {
        super.layoutSubviews()
        if !__CGSizeEqualToSize(bounds.size, self.intrinsicContentSize) {
            self.invalidateIntrinsicContentSize()
        }
    }
    
    override var intrinsicContentSize: CGSize {
        return contentSize
    }
}
