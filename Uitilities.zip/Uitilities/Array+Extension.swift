//
//  Array+Extension.swift


import Foundation

extension Array {
    
    /**
     Get Unique Values from Custom Object
     
     Usage:
     self.userSubjectsArray = self.userSubjectsArray?.unique3(map: { $0.subjects })
    */
    
    func getUniqueValues<T:Hashable>(map: ((Element) -> (T)))  -> [Element] {
        
        var set = Set<T>() //the unique list kept in a Set for fast retrieval
        var arrayOrdered = [Element]() //keeping the unique list of elements but ordered
        for value in self {
            if !set.contains(map(value)) {
                set.insert(map(value))
                arrayOrdered.append(value)
            }
        }
        return arrayOrdered
    }
    
   
}


extension Array where Element : Hashable {
    
    /**
    
    This property is user get unique values from [String]
    */
    
    var unique: [Element] {
        return Array(Set(self))
    }
}
//MARK:- Joined by Comma
// let partnerAns = question.partner_scores!.joined(separator: ",")
