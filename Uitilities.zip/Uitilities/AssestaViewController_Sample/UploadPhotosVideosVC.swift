//
//  UploadPhotosVideosVC.swift


import UIKit
import Kingfisher
import AssetsPickerViewController
import Photos

class UploadPhotosVideosVC: UIViewController {
    
    @IBOutlet weak var lbl_photos: UILabel!
    @IBOutlet weak var lbl_videos: UILabel!
    @IBOutlet weak var btn_placeHolderPhotoView: UIButton!
    
    @IBOutlet weak var view_BG: UIView!
    @IBOutlet weak var CV_photos: UICollectionView!
    
    @IBOutlet weak var btn_upload: UIButton!
    
    var isSelectedPhotos = true
    var groupedPhotos_array = [GroupedPhotosResp]()
    
    var imagesToUpload = [ImageNameWithURL]()
    
    //MARK:- ViewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()
                
        self.service_getPhotos()

        self.btn_upload.cornerRadiusHeightByTwo(bwidth: 0, bColor: nil)
        
        self.lbl_photos.backgroundColor = UIColor().color_underLineYellow()
        self.lbl_videos.backgroundColor = .clear
        
        print("Teacher ID: ",UserDefaults.standard.value(forKey: Enum_UserDetails.teacher_id.rawValue)!)
         print("Branch ID: ",UserDefaults.standard.value(forKey: Enum_UserDetails.branch_id.rawValue)!)
        
        self.CV_photos.delegate = self
        self.CV_photos.dataSource = self
        self.collectionViewFlowLayout()
        
        self.view_BG.shadowApply(cornerRadiues: 10, shadowOpacityes: 1, shadowColors: nil, shadowOffset: .zero)
        
    }
    
    //MARK:- Buttons Actions
    
    @IBAction func btn_backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btn_selectPhotosAction(_ sender: Any) {
        
        self.isSelectedPhotos = true
        self.btn_upload.setBackgroundImage(#imageLiteral(resourceName: "HeaderBackGround"), for: .normal)
        self.imagesToUpload.removeAll()
        
        self.lbl_photos.backgroundColor = UIColor().color_underLineYellow()
        self.lbl_videos.backgroundColor = .clear
        
        self.collectionViewFlowLayout()
        
        self.service_getPhotos()
        
    }
    
    @IBAction func btn_selectedVideosAction(_ sender: Any) {
        
        self.isSelectedPhotos = false
        self.btn_upload.setBackgroundImage(#imageLiteral(resourceName: "gradient"), for: .normal)
        self.imagesToUpload.removeAll()
        
        self.lbl_videos.backgroundColor = UIColor().color_underLineYellow()
        self.lbl_photos.backgroundColor = .clear
        
        self.collectionViewFlowLayout()
        
        self.service_getPhotos(api: api_get_teacher_group_videos)
    }
    
    @IBAction func btn_placeHolderPhotoVideosAction(_ sender: Any) {
        if self.isSelectedPhotos {
            self.call_multipleImagesPicker(defaultType: .smartAlbumUserLibrary)
        }else {
            self.call_multipleImagesPicker(defaultType: .smartAlbumVideos)
        }
    }
    
    @IBAction func btn_uploadAction(_ sender: Any) {
        
        if self.isSelectedPhotos {
            self.call_multipleImagesPicker(defaultType: .smartAlbumUserLibrary)
        }else {
            self.call_multipleImagesPicker(defaultType: .smartAlbumVideos)
        }
    }
    
    @objc func btn_videoPlayAction(sender: UIButton) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PlayVideoVC") as! PlayVideoVC
        vc.videoPath = self.groupedPhotos_array[sender.tag].video!
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    //MARK:- Functions
    
    func call_multipleImagesPicker(defaultType: PHAssetCollectionSubtype)  {
        
        let picker = AssetsPickerViewController()
        picker.pickerDelegate = self
        AssetsManager.shared.pickerConfig.albumDefaultType = defaultType
        present(picker, animated: true, completion: nil)
    }
    
    func service_getPhotos(api: String = api_get_teacher_group_images) {
        
        self.groupedPhotos_array.removeAll()
        
        let params = ["teacher_id": UserDefaults.standard.value(forKey: Enum_UserDetails.teacher_id.rawValue)!,
                      "branch_id":  UserDefaults.standard.value(forKey: Enum_UserDetails.branch_id.rawValue)!]
        
        APIManager.shared.requestPOSTURL(api, params: params, headers: nil, success: { (resp) in
            
            do{
                
                let jsonData = try JSONDecoder().decode(Model_GroupedPhotos.self, from: resp.data!)
                if jsonData.status {
                    
                    self.groupedPhotos_array = jsonData.response!
                    if self.groupedPhotos_array.count == 0 {
                        self.noDataFound()
                    }
                    
                    self.CV_photos.reloadData()
                }else {
                    self.view.makeToast(jsonData.message)
                    self.noDataFound()
                }
                
            }catch {
                print(error)
            }
            
        }) { (msg) in
            self.view.makeToast(msg)
            self.noDataFound()
        }
    }
    
    func service_upload_Photos_Videos() {
        
        let params = ["teacher_id": UserDefaults.standard.value(forKey: Enum_UserDetails.teacher_id.rawValue)!,
                      "branch_id":  UserDefaults.standard.value(forKey: Enum_UserDetails.branch_id.rawValue)!,
                      "group_id": UserDefaults.standard.value(forKey: Enum_UserDetails.group_id.rawValue)!]
        
//        print("Parama --> ", params)
        
        var api = ""
        var fileKey = ""
        var mimeType = ""
        
        if self.isSelectedPhotos {
            api = api_upload_group_images
            fileKey = "user_images[]"
            mimeType = MimeTypes.jpg
        }else {
            api = api_upload_group_videos
            fileKey = "user_video"
            mimeType = MimeTypes.mp4
        }
        
        APIManager.shared.POSTDataUsingFormData(apiStr: api, parameters: params, image_array: [fileKey: self.imagesToUpload], imagesArray_key: fileKey, mimeType: mimeType, headers: nil, success: { (resp) in
            
            do {
                let jsonData = try JSONDecoder().decode(Model_MsgStatus.self, from: (resp.data)!)
                if jsonData.status {
                    self.view.makeToast(jsonData.message)
                    if self.isSelectedPhotos {
                        self.service_getPhotos()
                    }else {
                        self.service_getPhotos(api: api_get_teacher_group_videos)
                    }
                    
                }else {
                    self.view.makeToast(jsonData.message)
                }
            }catch {
                print(error)
            }
            self.imagesToUpload.removeAll()
            
        }) { (msg) in
            self.view.makeToast(msg)
        }
        
    }
    
    func noDataFound() {
        
        self.view_BG.isHidden = true
        self.btn_upload.isHidden = true
        
        if self.isSelectedPhotos {
            self.btn_placeHolderPhotoView.setBackgroundImage(#imageLiteral(resourceName: "icon_uploadImage"), for: .normal)
        }else {
            self.btn_placeHolderPhotoView.setBackgroundImage(#imageLiteral(resourceName: "icon_uploadVideo"), for: .normal)
        }
    }
    
    func collectionViewFlowLayout() {
        
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        
        var width = (self.CV_photos.frame.width/3)-5
        var height = width
        
        if self.isSelectedPhotos == false {
            width = (self.CV_photos.frame.width)-5
            height = width * 0.65
        }
        
        layout.itemSize = CGSize(width: width, height: height)
        layout.minimumInteritemSpacing = 5
        layout.minimumLineSpacing = 5
        self.CV_photos.collectionViewLayout = layout
    }
    
}

extension UploadPhotosVideosVC: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.groupedPhotos_array.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = self.CV_photos.dequeueReusableCell(withReuseIdentifier: "CVCell_GroupedImages", for: indexPath) as! CVCell_GroupedImages
        cell.contentView.cornerRadius(radius: 5, bwidth: 1, bColor: nil)
        
        if self.isSelectedPhotos {
            cell.btn_play.isHidden = true
            if let img = self.groupedPhotos_array[indexPath.row].image {
                cell.imageViewPhotos.kf.indicatorType = .activity
                cell.imageViewPhotos.kf.setImage(with: URL(string: BaseURL_Image+img), placeholder: nil)
            }
        }else {
            cell.btn_play.isHidden = false
            if let img = self.groupedPhotos_array[indexPath.row].thumbnail {
                cell.imageViewPhotos.kf.indicatorType = .activity
                cell.imageViewPhotos.kf.setImage(with: URL(string: BaseURL_Image+img), placeholder: nil)
            }
            cell.btn_play.tag = indexPath.item
            cell.btn_play.addTarget(self, action: #selector(btn_videoPlayAction(sender:)), for: .touchUpInside)
        }
        
        return cell
    }
    
}

extension UploadPhotosVideosVC: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        var width = (self.CV_photos.frame.width/3)-5 //(collectionView.frame.size.width/3)
        var height = width
        
        if self.isSelectedPhotos == false {
            width = (self.CV_photos.frame.width)-5
            height = width * 0.65
        }
        
        return CGSize(width: width, height: height)
    }
}

extension UploadPhotosVideosVC: AssetsPickerViewControllerDelegate {
    
    func assetsPickerCannotAccessPhotoLibrary(controller: AssetsPickerViewController) {}
    func assetsPickerDidCancel(controller: AssetsPickerViewController) {}
    func assetsPicker(controller: AssetsPickerViewController, selected assets: [PHAsset]) {
        // do your job with selected assets
        
//        var returnValue = false
        let group = DispatchGroup()
        DispatchQueue.global(qos: .userInteractive).async {
            
//        }
//        DispatchQueue.main.async {
            
            for asset in assets {
                
                asset.getFileType(onCompletion: { (type) in
                    
                    if self.isSelectedPhotos {
                        if type == .photo {
                            let img = asset.get_imageWithSize(width: 300, height: 300)
                            let name = asset.get_fileName
                            
                            self.imagesToUpload.append(ImageNameWithURL(name: name, image: img))
                        }else {
                            DispatchQueue.main.async {
                                self.view.makeToast("Please Select Photos only")
                                self.imagesToUpload.removeAll()
                            }
                        }
                    }else {
                        if type == .video {
                            group.enter()
                            
                            asset.get_video { (videoURL) in
                                let name = asset.get_fileName
                                DispatchQueue.main.async {
                                    
                                    let size = videoURL.get_size_MB(url: videoURL)
                                    if size > 200 {
                                        self.view.makeToast("Video size should be 200 MB")
                                        return
                                    }
                                    
                                    self.imagesToUpload.append(ImageNameWithURL(name: name, videoURL: videoURL))
                                    group.leave()
                                }
                                
                            }
                            
                        }else {
                            DispatchQueue.main.async {
                                self.view.makeToast("Please Select Video only")
                                self.imagesToUpload.removeAll()
                            }
                        }
                    }
                })
                
            }
            
            group.notify(queue: DispatchQueue.main) {
                
                if self.imagesToUpload.count > 0 {
                    self.service_upload_Photos_Videos()
                }else {
                    
                    DispatchQueue.main.async {
                        
                        if self.isSelectedPhotos {
                            self.view.makeToast("Please Select Photos only")
                        }else {
//                            self.view.makeToast("Please select Video")
                        }
                    }
                    
                }
            }
            
        }
        
        
        /*
        
        if self.imagesToUpload.count > 0 {
            self.service_upload_Photos_Videos()
        }else {
            if self.isSelectedPhotos {
                self.view.makeToast("Please Select Photos only")
            }else {
                self.view.makeToast("Please select Video")
            }
        }
        */
        
        
    }
    
    func assetsPicker(controller: AssetsPickerViewController, shouldSelect asset: PHAsset, at indexPath: IndexPath) -> Bool {
        
        if isSelectedPhotos {
            if controller.selectedAssets.count > 9 {
                return false
            }
        }else {
            if controller.selectedAssets.count > 0 {
                return false
            }
        }
        return true
    }
    func assetsPicker(controller: AssetsPickerViewController, didSelect asset: PHAsset, at indexPath: IndexPath) {}
    func assetsPicker(controller: AssetsPickerViewController, shouldDeselect asset: PHAsset, at indexPath: IndexPath) -> Bool {
        return true
    }
    func assetsPicker(controller: AssetsPickerViewController, didDeselect asset: PHAsset, at indexPath: IndexPath) {}
}


extension UIColor {
    
    func color_underLineYellow() -> UIColor {
        
        return UIColor(red: 255.0/255, green: 208.0/255, blue: 71.0/255, alpha: 1)
    }
}


extension URL {
    
    func get_size_MB(url: URL?) -> Double {
        
        guard let filePath = url?.path else {
            return 0.0
        }
        do {
            let attribute = try FileManager.default.attributesOfItem(atPath: filePath)
            if let size = attribute[FileAttributeKey.size] as? NSNumber {
                return size.doubleValue / 1000000.0
            }
        } catch {
            print("Error: \(error)")
        }
        return 0.0
    }
}
