//
//  CustomSKIndicator.swift


import Foundation
import UIKit

struct CustomSKIndicator {
    
    static let shared = CustomSKIndicator()
    private init() { }
    
    func showSKIndicatorSpinner(statusMessage: String) {
        
//        SKActivityIndicator.spinnerStyle(.defaultSpinner)
//        SKActivityIndicator.spinnerStyle(.spinningCircle)
//        SKActivityIndicator.spinnerStyle(.spinningHalfCircles)
//        SKActivityIndicator.spinnerStyle(.spinningFadeCircle)
        
        SKActivityIndicator.spinnerStyle(.spinningFadeCircle)
        SKActivityIndicator.show(statusMessage, userInteractionStatus: false)
    }
}
